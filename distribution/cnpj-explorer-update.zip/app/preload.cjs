"use strict";
const { contextBridge, ipcRenderer } = require("electron");
contextBridge.exposeInMainWorld("desktop", Object.freeze({
  isDesktop: true,
  connectionToken: () => ipcRenderer.invoke("local:connection-token"),
  pickFolder: sessionToken => ipcRenderer.invoke("local:pick-folder", sessionToken),
  ready: () => ipcRenderer.invoke("local:ui-ready"),
  checkUpdates: (sessionToken, manual = true) => ipcRenderer.invoke("local:updates", sessionToken, manual),
  rollback: sessionToken => ipcRenderer.invoke("local:rollback", sessionToken),
  onUpdates: callback => {
    const listener = () => callback();
    ipcRenderer.on("local:updates", listener);
    return () => ipcRenderer.removeListener("local:updates", listener);
  },
  onRollback: callback => {
    const listener = () => callback();
    ipcRenderer.on("local:rollback", listener);
    return () => ipcRenderer.removeListener("local:rollback", listener);
  },
  onLock: callback => {
    const listener = () => callback();
    ipcRenderer.on("local:lock", listener);
    return () => ipcRenderer.removeListener("local:lock", listener);
  },
}));
