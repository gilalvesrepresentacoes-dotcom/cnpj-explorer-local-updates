"use strict";
// This bootstrap protocol intentionally never touches settings, accounts or data.
const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");
const FORMAT = "sqlite-v1-accounts-v2";
const RUNTIME = "electron45-python313-win-x64";
const BOOTSTRAP = "1.2.0";
function version(v) {
  if (typeof v !== "string" || !/^(0|[1-9]\d{0,5})\.(0|[1-9]\d{0,5})\.(0|[1-9]\d{0,5})$/.test(v)) throw new Error("Versão inválida.");
  return v.split(".").map(Number);
}
function compare(a, b) {
  const aa = version(a), bb = version(b);
  for (let i = 0; i < 3; i++) if (aa[i] !== bb[i]) return Math.sign(aa[i] - bb[i]);
  return 0;
}
const digest = bytes => crypto.createHash("sha256").update(bytes).digest("hex");
function allowedFile(name) {
  return /^(backend\/[a-z_]+\.py|backend\/ui\/[a-z_-]+\.(js|html|css)|app\/(main\.cjs|preload\.cjs|updater\.cjs|release-core\.cjs|package\.json)|LEIA-ME-DESKTOP\.txt)$/.test(name);
}
function plainFile(file) {
  const stat = fs.lstatSync(file);
  if (!stat.isFile() || stat.isSymbolicLink() || stat.nlink !== 1) throw new Error("Arquivo de atualização inválido.");
}
function json(file, max = 262144) {
  plainFile(file);
  if (fs.statSync(file).size > max) throw new Error("Metadados muito grandes.");
  return JSON.parse(fs.readFileSync(file, "utf8"));
}
function atomic(file, value) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const tmp = file + "." + crypto.randomBytes(8).toString("hex") + ".tmp";
  const fd = fs.openSync(tmp, "wx", 0o600);
  try { fs.writeFileSync(fd, JSON.stringify(value)); fs.fsyncSync(fd); }
  finally { fs.closeSync(fd); }
  try { fs.renameSync(tmp, file); }
  catch (e) { fs.rmSync(tmp, { force: true }); throw e; }
}
function verifyBundle(dir, expectedHash, expectedVersion) {
  if (!/^[a-f0-9]{64}$/.test(expectedHash || "")) throw new Error("Referência de integridade ausente.");
  const stat = fs.lstatSync(dir);
  if (!stat.isDirectory() || stat.isSymbolicLink()) throw new Error("Pasta de atualização inválida.");
  const manifestFile = path.join(dir, "release.json");
  const m = json(manifestFile);
  if (digest(fs.readFileSync(manifestFile)) !== expectedHash) throw new Error("Integridade do manifesto não confere.");
  version(m.version);
  if (m.schema !== 1 || m.version !== expectedVersion || m.data_format !== FORMAT || m.runtime !== RUNTIME ||
      compare(m.minimum_bootstrap, BOOTSTRAP) > 0) throw new Error("Esta versão exige outro pacote inicial ou formato de dados.");
  if (!m.files || typeof m.files !== "object" || Array.isArray(m.files)) throw new Error("Lista de arquivos inválida.");
  const names = Object.keys(m.files);
  if (names.length < 5 || names.length > 200) throw new Error("Conjunto de atualização inválido.");
  for (const name of ["backend/app.py", "app/main.cjs", "app/preload.cjs", "app/updater.cjs", "app/package.json"]) {
    if (!names.includes(name)) throw new Error("Pacote incompleto: " + name);
  }
  let bytes = 0;
  for (const name of names) {
    if (!allowedFile(name) || !/^[a-f0-9]{64}$/.test(m.files[name])) throw new Error("Arquivo não permitido no pacote.");
    const file = path.join(dir, ...name.split("/"));
    let parent = path.dirname(file);
    while (parent !== dir) {
      const s = fs.lstatSync(parent);
      if (!s.isDirectory() || s.isSymbolicLink()) throw new Error("Atalho não permitido no pacote.");
      parent = path.dirname(parent);
    }
    plainFile(file);
    bytes += fs.statSync(file).size;
    if (bytes > 32 * 1024 * 1024 || digest(fs.readFileSync(file)) !== m.files[name]) throw new Error("Integridade de arquivo não confere.");
  }
  const pkg = json(path.join(dir, "app", "package.json"));
  if (pkg.version !== m.version) throw new Error("Versões do pacote não correspondem.");
  function visit(base, prefix = "") {
    for (const name of fs.readdirSync(base)) {
      const rel = prefix + name, file = path.join(base, name), s = fs.lstatSync(file);
      if (s.isSymbolicLink()) throw new Error("Atalho não permitido.");
      if (s.isDirectory()) visit(file, rel + "/");
      else if (!s.isFile() || (rel !== "release.json" && !names.includes(rel))) throw new Error("Arquivo extra no pacote.");
    }
  }
  visit(dir);
  return m;
}
class ReleaseState {
  constructor(userData, builtInVersion) {
    this.root = path.join(userData, "updates");
    this.file = path.join(this.root, "current.json");
    this.builtInVersion = builtInVersion;
  }
  read() {
    if (!fs.existsSync(this.file)) return { schema: 1, active: null, previous: null, pending: false };
    const s = json(this.file, 4096);
    if (s.schema !== 1 || typeof s.pending !== "boolean") throw new Error("Configuração de atualização inválida.");
    for (const ref of [s.active, s.previous]) {
      if (ref != null && (!ref.version || !/^[a-f0-9]{64}$/.test(ref.hash || ""))) throw new Error("Referência de atualização inválida.");
      if (ref) version(ref.version);
    }
    return s;
  }
  folder(ref) { return path.join(this.root, "versions", version(ref.version).join(".")); }
  verify(ref) { return verifyBundle(this.folder(ref), ref.hash, ref.version); }
  activate(ref) {
    this.verify(ref);
    const before = this.read();
    if (before.pending) throw new Error("A versão anterior ainda não confirmou sua inicialização.");
    atomic(this.file, { schema: 1, active: ref, previous: before.active, pending: true, attempted: false });
  }
  rollback(reason) {
    const s = this.read();
    if (!s.active) throw new Error("Não há atualização anterior para desfazer.");
    if (s.previous) this.verify(s.previous);
    atomic(this.file, { schema: 1, active: s.previous, previous: null, pending: false, notice: reason });
  }
  boot() {
    let s = this.read();
    if (s.active && compare(this.builtInVersion, s.active.version) > 0) {
      s = { schema: 1, active: null, previous: null, pending: false,
        notice: "Foi detectado um pacote inicial mais recente. O programa usará essa versão, preservando a base e as contas." };
      atomic(this.file, s);
    }
    if (s.pending && s.attempted) {
      this.rollback("A última atualização não confirmou a abertura. A versão anterior foi restaurada; a base não foi alterada pelo atualizador.");
      s = this.read();
    }
    if (s.active) {
      try { this.verify(s.active); }
      catch (e) {
        this.rollback("A integridade da atualização falhou. Foi restaurada a versão anterior.");
        s = this.read();
      }
    }
    if (s.pending) atomic(this.file, { ...s, attempted: true });
    const notice = s.notice || "";
    if (notice) atomic(this.file, { ...s, notice: "" });
    return { ref: s.active, notice };
  }
  healthy(ref) {
    const s = this.read();
    if (s.pending && s.active?.version === ref?.version && s.active?.hash === ref?.hash) {
      atomic(this.file, { ...s, pending: false, attempted: false });
    }
  }
}
module.exports = { FORMAT, RUNTIME, BOOTSTRAP, version, compare, digest, allowedFile, atomic, json, verifyBundle, ReleaseState };
