/* Native Windows shell. Renderer has no Node or filesystem access. */
"use strict";
const { app, BrowserWindow, dialog, ipcMain, Menu, shell } = require("electron");
const { spawn } = require("node:child_process");
const fs = require("node:fs");
const path = require("node:path");
const readline = require("node:readline");
const { Updater } = require("./updater.cjs");

module.exports = function launch(context) {
app.setName("CNPJ Explorer Local");
app.setAppUserModelId("br.cnpjexplorer.local");
app.commandLine.appendSwitch("disable-background-networking");
let backend, win, baseURL, token, closing = false, quitting = false;
let checkingUpdate = false;
const icon = path.join(context.bootstrapDir, "icon.ico");
const updater = new Updater({
  state: context.state, currentVersion: context.version,
  channel: JSON.parse(fs.readFileSync(path.join(context.bootstrapDir, "update-channel.json"), "utf8")),
  python: path.join(process.resourcesPath, "runtime", "python.exe"),
  extractor: path.join(process.resourcesPath, "backend", "update_extract.py"),
});
app.on("second-instance", () => { if (win) { if (win.isMinimized()) win.restore(); win.show(); win.focus(); } });
app.whenReady().then(start).catch(fatal);
function fatal(error) {
  dialog.showErrorBox("CNPJ Explorer Local", String(error.message || error));
  quitting = true;
  if (backend) backend.kill();
  app.quit();
}
async function request(route, data, sessionToken = "") {
  const response = await fetch(baseURL + route, {
    method: data === undefined ? "GET" : "POST",
    headers: { "X-Local-Token": token, "X-Local-Session": sessionToken, "Content-Type": "application/json" },
    ...(data === undefined ? {} : { body: JSON.stringify(data) }),
  });
  const value = await response.json();
  if (!response.ok) throw new Error(value.error || "Falha no serviço local.");
  return value;
}
async function start() {
  const settings = path.join(app.getPath("userData"), "settings.json");
  fs.mkdirSync(path.dirname(settings), { recursive: true });
  const python = path.join(process.resourcesPath, "runtime", "python.exe");
  const script = path.join(context.backendDir, "app.py");
  const launcher = path.join(process.resourcesPath, "backend", "desktop_launch.py");
  if (!fs.existsSync(python) || !fs.existsSync(script) || !fs.existsSync(launcher)) {
    throw new Error("Pacote incompleto. Extraia toda a pasta do ZIP, não apenas o arquivo .exe.");
  }
  backend = spawn(python, ["-I", "-B", launcher, context.backendDir, "--desktop", "--port", "0", "--settings", settings], {
    windowsHide: true, stdio: ["pipe", "pipe", "pipe"], cwd: path.dirname(script),
    env: { ...process.env, PYTHONIOENCODING: "utf-8" },
  });
  backend.stdin.on("error", () => {});
  const ready = await new Promise((resolve, reject) => {
    const timeout = setTimeout(() => reject(new Error("O serviço local não iniciou em 30 segundos.")), 30000);
    let diagnostics = "";
    backend.stderr.on("data", chunk => { diagnostics = (diagnostics + chunk.toString()).slice(-2500); });
    backend.once("error", reject);
    backend.once("exit", () => { clearTimeout(timeout); reject(new Error("Não foi possível iniciar o processamento local.\n" + diagnostics)); });
    const lines = readline.createInterface({ input: backend.stdout });
    lines.on("line", line => {
      try {
        const value = JSON.parse(line);
        if (value.ready && typeof value.url === "string") {
          clearTimeout(timeout); resolve(value.url);
        }
      } catch { /* Never print the session URL or token to logs. */ }
    });
  });
  const url = new URL(ready);
  if (url.protocol !== "http:" || url.hostname !== "127.0.0.1" || !url.port) throw new Error("Endereço do serviço local inválido.");
  baseURL = url.origin;
  token = new URLSearchParams(url.hash.slice(1)).get("token");
  if (!token) throw new Error("Sessão de inicialização ausente.");
  win = new BrowserWindow({
    title: "CNPJ Explorer Local", width: 1320, height: 900, minWidth: 760, minHeight: 620,
    backgroundColor: "#f7f4ee", icon, show: false,
    webPreferences: { preload: path.join(__dirname, "preload.cjs"), contextIsolation: true,
      sandbox: true, nodeIntegration: false, webviewTag: false, devTools: false },
  });
  const session = win.webContents.session;
  // Only explicit Copy buttons may write plain text; camera, microphone,
  // geolocation, notifications and clipboard reading remain denied.
  session.setPermissionRequestHandler((wc, permission, callback) => {
    callback(wc === win.webContents && permission === "clipboard-sanitized-write");
  });
  session.setPermissionCheckHandler((wc, permission, origin) =>
    wc === win.webContents && permission === "clipboard-sanitized-write" && origin === baseURL);
  session.webRequest.onBeforeRequest((details, callback) => {
    callback({ cancel: !details.url.startsWith(baseURL + "/") && !details.url.startsWith("data:") });
  });
  win.webContents.setWindowOpenHandler(() => ({ action: "deny" }));
  win.webContents.on("will-navigate", (event, target) => { if (new URL(target).origin !== baseURL) event.preventDefault(); });
  win.webContents.on("will-attach-webview", event => event.preventDefault());
  function trusted(event) {
    if (event.sender !== win.webContents || new URL(event.senderFrame.url).origin !== baseURL) throw new Error("Janela não autorizada.");
  }
  async function administrator(sessionToken) {
    if (typeof sessionToken !== "string" || !/^[a-zA-Z0-9_-]{43}$/.test(sessionToken)) throw new Error("Entre como administrador primeiro.");
    const s = await request("/api/auth/status", undefined, sessionToken);
    if (!s.authenticated || s.migration_required || s.must_change_password || s.user?.role !== "admin") throw new Error("Somente o administrador pode atualizar o programa.");
  }
  ipcMain.handle("local:ui-ready", async event => { trusted(event); context.healthy(); });
  // Bootstrap credential only for our isolated, same-origin renderer.
  // This does not replace the independently required account session.
  ipcMain.handle("local:connection-token", event => { trusted(event); return token; });
  ipcMain.handle("local:updates", async (event, sessionToken, manual = true) => {
    trusted(event);
    if (typeof manual !== "boolean") throw new Error("Solicitação inválida.");
    await administrator(sessionToken);
    if (checkingUpdate || closing) return;
    checkingUpdate = true;
    let prepared = false;
    try {
      const release = await updater.check(manual);
      if (!release) {
        if (manual) await dialog.showMessageBox(win, { message: "Nenhuma versão mais recente disponível.", detail: "Versão instalada: " + context.version });
        return;
      }
      const answer = await dialog.showMessageBox(win, {
        type: "info", message: "Nova versão " + release.version + " disponível",
        detail: release.notes.join("\n\n") + "\n\nO download contém somente o programa. A base, os usuários e as configurações ficam no computador.",
        buttons: ["Mais tarde", "Baixar atualização"], defaultId: 0, cancelId: 0,
      });
      if (answer.response !== 1) return;
      win.setProgressBar(2);
      const ref = await updater.stage(release);
      win.setProgressBar(-1);
      const restart = await dialog.showMessageBox(win, { type: "question", message: "Atualização pronta para instalar",
        detail: "Reiniciar o programa e usar a versão " + release.version + "? Se houver consulta, importação ou exportação em andamento, a troca será impedida. Você precisará entrar novamente.",
        buttons: ["Continuar usando", "Reiniciar e atualizar"], defaultId: 0, cancelId: 0 });
      if (restart.response !== 1) return;
      await administrator(sessionToken);
      const ready = await request("/api/admin/update-prepare", {}, sessionToken);
      if (!ready.ready) throw new Error(ready.reason || "Aguarde as operações em andamento antes de atualizar.");
      prepared = true;
      closing = true;
      win.hide();
      const stopped = new Promise((resolve, reject) => {
        const timer = setTimeout(() => reject(new Error("O processamento local não encerrou a tempo. Nenhuma atualização foi ativada; reabra o programa.")), 20000);
        backend.once("exit", code => { clearTimeout(timer); code === 0 ? resolve() : reject(new Error("O serviço local não encerrou normalmente. A atualização não foi ativada.")); });
      });
      backend.stdin.end("stop\n");
      await stopped;
      context.state.activate(ref);
      quitting = true;
      app.relaunch();
      win.destroy(); app.quit();
    } catch (e) {
      if (prepared) {
        // No update pointer changes before clean service exit. Keep the old version.
        dialog.showErrorBox("Atualização não instalada", e.message);
        quitting = true; win.destroy(); app.quit();
      } else if (manual || updater.latest) {
        await dialog.showMessageBox(win, { type: "warning", message: "Não foi possível atualizar", detail: e.message });
      }
    } finally { checkingUpdate = false; if (!quitting) win.setProgressBar(-1); }
  });
  ipcMain.handle("local:pick-folder", async (event, sessionToken) => {
    trusted(event);
    if (typeof sessionToken !== "string" || !/^[a-zA-Z0-9_-]{43}$/.test(sessionToken)) throw new Error("Entre com sua senha primeiro.");
    const state = await request("/api/auth/status", undefined, sessionToken);
    if (!state.authenticated || state.migration_required || state.must_change_password) throw new Error("Entre com sua senha e conclua seu cadastro primeiro.");
    const result = await dialog.showOpenDialog(win, { title: "Escolher pasta", properties: ["openDirectory", "createDirectory"] });
    return result.canceled ? null : result.filePaths[0];
  });
  Menu.setApplicationMenu(Menu.buildFromTemplate([
    { label: "Arquivo", submenu: [
      { label: "Bloquear acesso", accelerator: "CommandOrControl+L", click: () => win.webContents.send("local:lock") },
      { label: "Criar atalho na Área de Trabalho", click: () => {
        const ok = shell.writeShortcutLink(path.join(app.getPath("desktop"), "CNPJ Explorer Local.lnk"), {
          target: process.execPath, cwd: path.dirname(process.execPath), icon, iconIndex: 0,
          description: "CNPJ Explorer Local — consultas e planilhas no seu computador",
        });
        dialog.showMessageBox(win, { message: ok ? "Atalho criado na Área de Trabalho." : "Não foi possível criar o atalho." });
      }},
      { type: "separator" }, { label: "Sair", accelerator: "Alt+F4", click: () => win.close() },
    ]},
    { label: "Editar", submenu: [{ role: "undo" }, { role: "redo" }, { type: "separator" },
      { role: "cut" }, { role: "copy" }, { role: "paste" }, { role: "selectAll" }] },
    { label: "Visualizar", submenu: [{ role: "resetZoom" }, { role: "zoomIn" }, { role: "zoomOut" }, { role: "togglefullscreen" }] },
    { label: "Ajuda", submenu: [
      { label: "Verificar atualizações", click: () => win.webContents.send("local:updates") },
      { label: "Voltar à versão anterior", click: () => win.webContents.send("local:rollback") },
      { type: "separator" },
      { label: "Sobre o programa", click: () => dialog.showMessageBox(win, {
      message: "CNPJ Explorer Local", detail: "Versão " + context.version + "\nPrograma local para Windows. Atualizações consultam somente o canal público do programa; não enviam a base.\nA senha protege o acesso pelo programa, mas não criptografa o HD.\nLeia LEIA-ME-DESKTOP.txt, incluído no pacote.",
    }) }] },
  ]));
  ipcMain.handle("local:rollback", async (event, sessionToken) => {
    trusted(event); await administrator(sessionToken);
    if (checkingUpdate || closing) throw new Error("Aguarde a operação atual.");
    if (!context.state.read().active) throw new Error("Você já está usando a versão inicial deste pacote.");
    const answer = await dialog.showMessageBox(win, { type: "question", message: "Voltar à versão anterior do programa?",
      detail: "A base e as contas não serão restauradas ou apagadas. A troca exige que não haja operação em andamento.",
      buttons: ["Cancelar", "Reiniciar e voltar"], defaultId: 0, cancelId: 0 });
    if (answer.response !== 1) return;
    const ready = await request("/api/admin/update-prepare", {}, sessionToken);
    if (!ready.ready) throw new Error(ready.reason);
    closing = true; win.hide();
    const timer = setTimeout(() => { dialog.showErrorBox("Versão não alterada", "O serviço não encerrou a tempo. Reabra o programa."); quitting = true; win.destroy(); app.quit(); }, 20000);
    backend.once("exit", code => {
      clearTimeout(timer);
      try {
        if (code !== 0) throw new Error("O serviço não encerrou normalmente.");
        context.state.rollback("A versão anterior foi restaurada a pedido do administrador.");
        app.relaunch();
      } catch (e) { dialog.showErrorBox("Versão não alterada", e.message); }
      quitting = true; win.destroy(); app.quit();
    });
    backend.stdin.end("stop\n");
  });
  win.once("ready-to-show", () => win.show());
  backend.on("exit", () => { if (!closing && !quitting) fatal(new Error("O processamento local foi encerrado. Reabra o programa para continuar do ponto salvo.")); });
  win.on("close", async event => {
    if (quitting) return;
    event.preventDefault();
    if (closing) return;
    const answer = await dialog.showMessageBox(win, { type: "question",
      message: "Fechar o CNPJ Explorer Local?", detail: "Importações serão pausadas no ponto salvo. Exportações em andamento precisam ser refeitas. Downloads serão interrompidos; ZIPs já concluídos ficam preservados.",
      buttons: ["Continuar usando", "Pausar e fechar"], defaultId: 0, cancelId: 0 });
    if (answer.response !== 1) return;
    closing = true;
    win.hide();
    backend.stdin.end("stop\n");
    const timer = setTimeout(() => backend.kill(), 20000);
    backend.once("exit", () => { clearTimeout(timer); quitting = true; win.destroy(); app.quit(); });
  });
  await win.loadURL(ready);
  if (context.notice) await dialog.showMessageBox(win, { type: "warning", message: "Recuperação de atualização", detail: context.notice });
}
app.on("window-all-closed", () => { if (quitting) app.quit(); });
app.on("will-quit", () => { if (backend && backend.exitCode === null) backend.kill(); });
};
