"use strict";
const fs = require("node:fs");
const path = require("node:path");
const { execFile } = require("node:child_process");
const { promisify } = require("node:util");
const core = require("./release-core.cjs");
const exec = promisify(execFile);
const MAX_PACKAGE = 8 * 1024 * 1024;
function repository(value) {
  if (typeof value !== "string" || !/^[A-Za-z0-9][A-Za-z0-9-]{0,38}\/[A-Za-z0-9_.-]{1,100}$/.test(value) ||
      value.split("/")[1] === "." || value.split("/")[1] === "..") throw new Error("Canal de distribuição não configurado.");
  return value;
}
async function readRemote(url, max, fetcher = fetch, binary = false) {
  const original = new URL(url);
  const isAPI = original.hostname === "api.github.com";
  const isRaw = original.hostname === "raw.githubusercontent.com";
  const permitted = u => u.protocol === "https:" && !u.username && !u.password && !u.port &&
    (isAPI ? u.hostname === "api.github.com" : isRaw ? u.hostname === "raw.githubusercontent.com" :
      ["github.com", "release-assets.githubusercontent.com", "objects.githubusercontent.com"].includes(u.hostname));
  let current = original;
  if (!permitted(current)) throw new Error("Origem de atualização não permitida.");
  const abort = new AbortController(), timer = setTimeout(() => abort.abort(), 90000);
  try {
    for (let i = 0; i < 5; i++) {
      const r = await fetcher(current.href, { redirect: "manual", signal: abort.signal,
        headers: { "Accept": isAPI ? "application/vnd.github+json" : "application/octet-stream", "User-Agent": "CNPJ-Explorer-Local-Updater" } });
      if ([301, 302, 303, 307, 308].includes(r.status)) {
        await r.body?.cancel();
        current = new URL(r.headers.get("location") || "", current);
        if (!permitted(current)) throw new Error("Redirecionamento de atualização não permitido.");
        continue;
      }
      if (r.status === 404 && isAPI) return null;
      if (!r.ok) throw new Error(r.status === 403 || r.status === 429 ? "Limite de consultas do GitHub. Tente mais tarde." : "Servidor de atualizações indisponível.");
      const length = Number(r.headers.get("content-length") || 0);
      if (length > max) { await r.body?.cancel(); throw new Error("Arquivo de atualização muito grande."); }
      let size = 0; const chunks = [];
      for await (const chunk of r.body) {
        size += chunk.length;
        if (size > max) throw new Error("Arquivo excedeu o limite permitido.");
        chunks.push(Buffer.from(chunk));
      }
      const bytes = Buffer.concat(chunks);
      if (binary) return bytes;
      return JSON.parse(bytes.toString("utf8"));
    }
    throw new Error("Excesso de redirecionamentos.");
  } catch (e) {
    if (e.name === "AbortError") throw new Error("O servidor de atualizações demorou a responder. O programa continua na versão atual.");
    throw e;
  } finally { clearTimeout(timer); }
}
class Updater {
  constructor({ state, channel, currentVersion, python, extractor, fetcher = fetch }) {
    this.state = state; this.channel = channel; this.currentVersion = currentVersion;
    this.python = python; this.extractor = extractor; this.fetcher = fetcher;
    this.lastCheck = 0; this.latest = null; this.busy = false;
  }
  get configured() { try { repository(this.channel.repository); return true; } catch { return false; } }
  async check(manual = false) {
    if (!this.configured) throw new Error("Canal de atualizações ainda não ativado pelo responsável pelo programa.");
    const interval = manual ? 10000 : 6 * 60 * 60 * 1000;
    if (Date.now() - this.lastCheck < interval) return this.latest;
    if (this.busy) throw new Error("Já existe uma verificação ou download em andamento.");
    this.busy = true; this.lastCheck = Date.now();
    try {
      const repo = repository(this.channel.repository);
      const release = await readRemote(`https://api.github.com/repos/${repo}/releases/latest`, 262144, this.fetcher);
      if (!release) { this.latest = null; return null; }
      if (release.draft || release.prerelease || !/^v\d+\.\d+\.\d+$/.test(release.tag_name)) throw new Error("Versão publicada inválida.");
      const v = release.tag_name.slice(1);
      if (release.html_url !== `https://github.com/${repo}/releases/tag/v${v}`) throw new Error("Origem da versão não corresponde ao canal.");
      if (core.compare(v, this.currentVersion) <= 0) { this.latest = null; return null; }
      // Resolve the release tag once, then read ONLY from that immutable commit.
      // No token, mutable "main" download, or upload-host credentials in the app.
      const tag = await readRemote(`https://api.github.com/repos/${repo}/git/ref/tags/v${v}`, 65536, this.fetcher);
      let object = tag?.object;
      for (let depth = 0; object?.type === "tag" && depth < 3; depth++) {
        if (!/^[a-f0-9]{40,64}$/.test(object.sha || "")) throw new Error("Referência da versão inválida.");
        const annotated = await readRemote(`https://api.github.com/repos/${repo}/git/tags/${object.sha}`, 65536, this.fetcher);
        object = annotated?.object;
      }
      if (object?.type !== "commit" || !/^(?:[a-f0-9]{40}|[a-f0-9]{64})$/.test(object.sha || "")) throw new Error("Commit da versão não encontrado.");
      const prefix = `https://raw.githubusercontent.com/${repo}/${object.sha}/distribution/`;
      const m = await readRemote(prefix + "update.json", 65536, this.fetcher);
      if (m.schema !== 1 || m.version !== v || m.data_format !== core.FORMAT || m.runtime !== core.RUNTIME ||
          core.compare(m.minimum_bootstrap, core.BOOTSTRAP) > 0) throw new Error("Esta atualização exige um novo pacote completo; consulte o responsável.");
      if (!Array.isArray(m.notes) || m.notes.length > 20 || m.notes.some(x => typeof x !== "string" || x.length > 500)) throw new Error("Notas de versão inválidas.");
      if (!/^[a-f0-9]{64}$/.test(m.manifest_sha256 || "") ||
          m.payload?.name !== "cnpj-explorer-update.zip" || !/^[a-f0-9]{64}$/.test(m.payload.sha256 || "") ||
          !Number.isSafeInteger(m.payload.size) || m.payload.size < 1 || m.payload.size > MAX_PACKAGE) throw new Error("Metadados da atualização inválidos.");
      this.latest = { ...m, url: prefix + m.payload.name };
      return this.latest;
    } catch (e) {
      this.lastCheck = 0;
      throw e;
    } finally { this.busy = false; }
  }
  async stage(release) {
    if (this.busy) throw new Error("Aguarde o download atual.");
    if (release !== this.latest || core.compare(release.version, this.currentVersion) <= 0) throw new Error("Verifique a versão novamente.");
    this.busy = true;
    const ref = { version: release.version, hash: release.manifest_sha256 };
    let temp;
    try {
      const target = this.state.folder(ref);
      if (fs.existsSync(target)) {
        try { this.state.verify(ref); return ref; }
        catch {
          const s = this.state.read();
          if ([s.active?.version, s.previous?.version].includes(ref.version)) throw new Error("A versão preservada está danificada. Repare o pacote antes de atualizar.");
          fs.renameSync(target, target + ".damaged-" + Date.now());
        }
      }
      fs.mkdirSync(path.dirname(target), { recursive: true });
      temp = fs.mkdtempSync(path.join(this.state.root, "stage-"));
      const bytes = await readRemote(release.url, MAX_PACKAGE, this.fetcher, true);
      if (bytes.length !== release.payload.size || core.digest(bytes) !== release.payload.sha256) throw new Error("O arquivo recebido está incompleto ou com checksum divergente.");
      const archive = path.join(temp, "download.zip"), extracted = path.join(temp, "bundle");
      fs.writeFileSync(archive, bytes, { flag: "wx" }); fs.mkdirSync(extracted);
      await exec(this.python, ["-I", "-B", this.extractor, archive, extracted], { windowsHide: true, timeout: 30000, maxBuffer: 65536 });
      core.verifyBundle(extracted, ref.hash, ref.version);
      fs.renameSync(extracted, target);
      return ref;
    } finally {
      this.busy = false;
      if (temp) fs.rmSync(temp, { recursive: true, force: true });
    }
  }
}
module.exports = { Updater, repository, readRemote };
