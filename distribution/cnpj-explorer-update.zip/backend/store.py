"""Banco exclusivamente local. Nenhum cliente HTTP, nuvem ou telemetria."""
import json
import re
import sqlite3
import unicodedata
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path


def normalized(value):
    return "".join(c for c in unicodedata.normalize("NFD", str(value))
                   if not unicodedata.combining(c)).upper().strip()


def dumps(value):
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"))


def codes(value, width, name):
    if isinstance(value, str):
        value = [s.strip() for s in value.split(",") if s.strip()]
    if not isinstance(value, list) or len(value) > 1000:
        raise ValueError(f"{name}: informe uma lista de até 1.000 códigos.")
    result = sorted(set(str(s).strip() for s in value))
    if any(not re.fullmatch(rf"\d{{{width}}}", s) for s in result):
        raise ValueError(f"{name}: use códigos de {width} dígitos.")
    return result


class Store:
    def __init__(self, root):
        if Path(root).expanduser().is_file() or Path(root).suffix.lower() == ".zip":
            raise ValueError("A pasta de dados não pode ser um arquivo ZIP. Escolha uma pasta na unidade desejada, por exemplo E:\\CNPJ.")
        self.root = Path(root).expanduser()
        if not self.root.is_absolute():
            raise ValueError("Informe uma pasta absoluta, por exemplo E:\\CNPJ.")
        # Do not manufacture a missing Windows drive or fall back to another disk.
        if self.root.drive and not Path(self.root.anchor).is_dir():
            raise ValueError("A unidade escolhida não está conectada.")
        self.root.mkdir(parents=True, exist_ok=True)
        self.path = self.root / "cnpj-local.sqlite3"
        self._lock = (self.root / ".cnpj-local.lock").open("a+b")
        try:
            if __import__("os").name == "nt":
                import msvcrt
                self._lock.write(b"\0")
                self._lock.flush()
                self._lock.seek(0)
                msvcrt.locking(self._lock.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(self._lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError as error:
            self._lock.close()
            raise ValueError("Esta pasta já está aberta em outra execução do CNPJ Explorer Local.") from error
        with self.session() as db:
            db.executescript("""
                CREATE TABLE IF NOT EXISTS jobs(id TEXT PRIMARY KEY,payload TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS refs(job TEXT,kind TEXT,code TEXT,label TEXT,
                    PRIMARY KEY(job,kind,code));
                CREATE TABLE IF NOT EXISTS establishments(
                    job TEXT,cnpj TEXT,base TEXT,state TEXT,city TEXT,neighborhood TEXT,
                    cnae TEXT,status TEXT,trade_name TEXT,data TEXT, PRIMARY KEY(job,cnpj));
                CREATE INDEX IF NOT EXISTS est_base ON establishments(job,base);
                CREATE INDEX IF NOT EXISTS est_city ON establishments(job,state,city,cnpj);
                CREATE INDEX IF NOT EXISTS est_cnae ON establishments(job,cnae,cnpj);
                CREATE TABLE IF NOT EXISTS activities(job TEXT,cnpj TEXT,code TEXT,
                    PRIMARY KEY(job,cnpj,code));
                CREATE INDEX IF NOT EXISTS activities_search ON activities(job,code,cnpj);
                CREATE TABLE IF NOT EXISTS companies(job TEXT,base TEXT,name TEXT,data TEXT,
                    PRIMARY KEY(job,base));
                CREATE TABLE IF NOT EXISTS partners(job TEXT,source TEXT,row_number INTEGER,
                    base TEXT,data TEXT,PRIMARY KEY(job,source,row_number));
                CREATE INDEX IF NOT EXISTS partner_base ON partners(job,base);
                CREATE TABLE IF NOT EXISTS simples(job TEXT,base TEXT,data TEXT,PRIMARY KEY(job,base));
                CREATE TABLE IF NOT EXISTS exports(
                    id TEXT PRIMARY KEY,created_at TEXT,path TEXT,format TEXT,
                    companies INTEGER,rows INTEGER,job_id TEXT);
                CREATE TABLE IF NOT EXISTS export_items(
                    export_id TEXT,cnpj TEXT,PRIMARY KEY(export_id,cnpj));
                CREATE INDEX IF NOT EXISTS export_cnpj ON export_items(cnpj);
                CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT);
            """)
        from query_library import QueryLibrary
        self.library = QueryLibrary(self)

    def connect(self):
        if not self.root.is_dir():
            raise ValueError("Pasta de dados indisponível. Reconecte o HD externo.")
        db = sqlite3.connect(self.path, timeout=30)
        from query_filters import money_cents
        db.create_function("fold", 1, normalized, deterministic=True)
        db.create_function("money_cents", 1, money_cents, deterministic=True)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA journal_mode=WAL")
        db.execute("PRAGMA synchronous=FULL")
        db.execute("PRAGMA cache_size=-32768")
        db.execute("PRAGMA temp_store=FILE")
        return db

    @contextmanager
    def session(self):
        db = self.connect()
        try:
            with db:
                yield db
        finally:
            db.close()

    def close(self):
        self._lock.close()

    def job(self, ident, db=None):
        if db is None:
            with self.session() as conn:
                return self.job(ident, conn)
        row = db.execute("SELECT payload FROM jobs WHERE id=?", (ident,)).fetchone()
        if not row:
            raise ValueError("Base não encontrada nesta pasta.")
        return json.loads(row[0])

    def save(self, db, job):
        job["updated_at"] = datetime.now(timezone.utc).isoformat()
        # Registro de etapas limitado: salva na MESMA transação do cursor, não
        # é uma lista simulada de leituras nem uma nova gravação por linha.
        marker = [job.get("status"), job.get("file_index"), job.get("current_file", "")]
        events = job.setdefault("events", [])
        if not events or events[-1].get("marker") != marker:
            label = {"queued": "Importação criada", "running": "Processando",
                     "paused": "Processamento pausado", "failed": "Processamento interrompido",
                     "cancelled": "Processamento cancelado", "completed": "Importação concluída"}.get(job.get("status"), "Ponto salvo")
            events.append({"at": job["updated_at"], "marker": marker,
                           "message": label + (" — " + job["current_file"] if job.get("current_file") else ""),
                           "files": job.get("file_index", 0), "rows": job.get("rows_scanned", 0),
                           "kept": job.get("rows_kept", 0)})
            del events[:-100]
        db.execute("INSERT INTO jobs VALUES(?,?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload",
                   (job["id"], dumps(job)))

    def jobs(self):
        with self.session() as db:
            return [json.loads(row[0]) for row in db.execute("SELECT payload FROM jobs ORDER BY rowid DESC")]

    def recover(self):
        with self.session() as db:
            for row in db.execute("SELECT payload FROM jobs").fetchall():
                job = json.loads(row[0])
                if job["status"] in ("running", "queued"):
                    job.update(status="paused", error="Execução interrompida. Use Continuar para retomar do ponto salvo.")
                    self.save(db, job)
            # Pending export item sets have no public history entry. Never mark
            # a generated-but-unconfirmed export as completed after restart.
            db.execute("DELETE FROM export_items WHERE export_id NOT IN (SELECT id FROM exports)")

    def references(self, job_id):
        if job_id:
            self.job(job_id)
        with self.session() as db:
            if not job_id:
                row = db.execute("""SELECT j.id FROM jobs j WHERE EXISTS
                    (SELECT 1 FROM refs r WHERE r.job=j.id AND r.kind='Cnaes')
                    ORDER BY j.rowid DESC LIMIT 1""").fetchone()
                if not row:
                    return {"cnaes": [], "cities": []}
                job_id = row[0]
            return {key: [dict(r) for r in db.execute(
                "SELECT code,label FROM refs WHERE job=? AND kind=? ORDER BY label",
                (job_id, kind))] for key, kind in (("cnaes", "Cnaes"), ("cities", "Municipios"))}

    def conditions(self, job_id, filters, selected=None, skip=False):
        job = self.job(job_id)
        if job["status"] != "completed":
            raise ValueError("Esta base ainda não está concluída. Continue o processamento antes de consultar.")
        clauses, values = ["e.job=?"], [job_id]
        if filters.get("snapshot_id"):
            saved = self.library.get(filters["snapshot_id"], filters.get("_owner", ""))
            if saved["payload"]["job_id"] != job_id:
                raise ValueError("O resultado salvo pertence a outra base.")
            clauses.append("e.cnpj IN (SELECT qm.cnpj FROM query_members qm WHERE qm.saved_id=?)")
            values.append(saved["id"])
            # Membership is the saved result. Do not rerun its original filters.
            filters = {k: filters[k] for k in ("refine_cities", "refine_cnaes") if k in filters}
        for key, width, column in (("refine_cities", 4, "e.city"), ("refine_cnaes", 7, None)):
            refined = codes(filters.get(key, []), width, key)
            if refined:
                marks = ",".join("?" for _ in refined)
                clauses.append((column + " IN (" + marks + ")") if column else
                               "EXISTS(SELECT 1 FROM activities a WHERE a.job=e.job AND a.cnpj=e.cnpj AND a.code IN (" + marks + "))")
                values.extend(refined)
        if filters.get("state"):
            clauses.append("e.state=?")
            values.append(str(filters["state"]).upper())
        cities = codes(filters.get("cities", []), 4, "Municípios")
        cnaes = codes(filters.get("cnaes", []), 7, "CNAEs")
        if cities:
            clauses.append("e.city IN (" + ",".join("?" for _ in cities) + ")")
            values += cities
        if cnaes:
            clauses.append("EXISTS(SELECT 1 FROM activities a WHERE a.job=e.job AND a.cnpj=e.cnpj AND a.code IN (" +
                           ",".join("?" for _ in cnaes) + "))")
            values += cnaes
        if str(filters.get("active_only", "")).lower() in ("1", "true"):
            clauses.append("e.status='02'")
        if filters.get("neighborhood"):
            clauses.append("instr(e.neighborhood,?)>0")
            values.append(normalized(filters["neighborhood"]))
        if filters.get("search"):
            text = normalized(filters["search"])
            digits = re.sub(r"\D", "", text)
            if len(digits) >= 8 and re.fullmatch(r"[\d\s./-]+", text):
                clauses.append("e.cnpj LIKE ?")
                values.append(digits + "%")
            else:
                clauses.append("(instr(c.name,?)>0 OR instr(e.trade_name,?)>0)")
                values += [text, text]
        from query_filters import compile_rules
        extra, extra_values = compile_rules(filters.get("rules", []))
        clauses.extend("(" + clause + ")" for clause in extra)
        values.extend(extra_values)
        if selected:
            if not isinstance(selected, list) or len(selected) > 3000 or any(
                    not re.fullmatch(r"\d{14}", str(s)) for s in selected):
                raise ValueError("Selecione até 3.000 CNPJs válidos.")
            clauses.append("e.cnpj IN (" + ",".join("?" for _ in selected) + ")")
            values += selected
        if skip:
            clauses.append("NOT EXISTS(SELECT 1 FROM export_items x JOIN exports h ON h.id=x.export_id WHERE x.cnpj=e.cnpj)")
        return " AND ".join(clauses), values

    def search(self, params):
        job_id = params.get("job_id", "")
        where, values = self.conditions(job_id, params)
        after = params.get("after", "")
        if after:
            if not re.fullmatch(r"\d{14}", after):
                raise ValueError("Cursor de página inválido.")
            where += " AND e.cnpj>?"
            values.append(after)
        with self.session() as db:
            rows = db.execute("""SELECT e.*,c.data AS company_data,r.label AS city_name,
                EXISTS(SELECT 1 FROM export_items x JOIN exports h ON h.id=x.export_id WHERE x.cnpj=e.cnpj) AS exported
                FROM establishments e LEFT JOIN companies c ON c.job=e.job AND c.base=e.base
                LEFT JOIN simples s ON s.job=e.job AND s.base=e.base
                LEFT JOIN refs r ON r.job=e.job AND r.kind='Municipios' AND r.code=e.city
                WHERE """ + where + " ORDER BY e.cnpj LIMIT 51", values).fetchall()
        items = []
        for row in rows[:50]:
            data = json.loads(row["data"])
            company = json.loads(row["company_data"] or "{}")
            items.append({
                "cnpj": row["cnpj"], "name": company.get("RAZÃO SOCIAL", ""),
                "trade_name": data.get("NOME FANTASIA", ""), "city": row["city_name"] or row["city"],
                "city_code": row["city"], "state": row["state"],
                "neighborhood": data.get("BAIRRO", ""), "cnae": row["cnae"],
                "phone": " ".join(filter(None, [data.get("DDD 1"), data.get("TELEFONE 1")])),
                "email": data.get("EMAIL", ""), "status": row["status"], "exported": bool(row["exported"]),
            })
        return {"items": items, "next_after": items[-1]["cnpj"] if len(rows) > 50 else None}

    def open_export(self, ident):
        import os
        with self.session() as db:
            row = db.execute("SELECT path FROM exports WHERE id=?", (ident,)).fetchone()
        if not row:
            raise ValueError("Exportação concluída não encontrada.")
        file = Path(row[0])
        if file.suffix.lower() not in (".xlsx", ".csv") or not file.is_file():
            raise ValueError("A planilha não está disponível. Reconecte o HD ou confira se o arquivo foi movido.")
        if os.name != "nt":
            raise ValueError("Abrir planilha automaticamente é um recurso da versão Windows. O arquivo foi salvo no destino indicado.")
        try:
            os.startfile(str(file))
        except OSError as error:
            raise ValueError("Não foi possível abrir a planilha. Instale/associe Excel ou outro leitor de XLSX/CSV no Windows.") from error
        return {"opened": True}

    def enriched(self, db, job_id, row, include_partners=True, refs=None, period=None, partner_data=None):
        from fields import DESCRIPTIONS
        fields = json.loads(row["data"])
        fields.update(json.loads(row["company_data"] or "{}"))
        fields.update(json.loads(row["simple_data"] or "{}"))
        fields.update(CNPJ=row["cnpj"], **{"COMPETÊNCIA": period or self.job(job_id, db)["period"]})
        if refs is None:
            refs = {(r["kind"], r["code"]): r["label"]
                    for r in db.execute("SELECT kind,code,label FROM refs WHERE job=?", (job_id,))}

        def enrich(data):
            for field, (kind, label) in DESCRIPTIONS.items():
                if field in data:
                    data[label] = refs.get((kind, data[field]), "")
            if "CNAES SECUNDÁRIOS" in data:
                data["CNAES SECUNDÁRIOS DESCRIÇÃO"] = " | ".join(
                    refs.get(("Cnaes", code), code) for code in data["CNAES SECUNDÁRIOS"].split(",") if code)
            return data

        if include_partners and partner_data is None:
            partner_data = [r[0] for r in db.execute(
                "SELECT data FROM partners WHERE job=? AND base=? ORDER BY source,row_number", (job_id, row["base"]))]
        partners = [enrich(json.loads(data)) for data in partner_data] if include_partners else []
        return {"fields": enrich(fields), "partners": partners}

    def detail(self, params):
        job_id, cnpj = params.get("job_id", ""), params.get("cnpj", "")
        self.conditions(job_id, {})
        with self.session() as db:
            row = db.execute("""SELECT e.*,c.data AS company_data,s.data AS simple_data
                FROM establishments e LEFT JOIN companies c ON c.job=e.job AND c.base=e.base
                LEFT JOIN simples s ON s.job=e.job AND s.base=e.base
                WHERE e.job=? AND e.cnpj=?""", (job_id, cnpj)).fetchone()
            if not row:
                raise ValueError("CNPJ não encontrado nesta base.")
            return self.enriched(db, job_id, row)

    def history(self):
        with self.session() as db:
            return {"items": [dict(r) for r in db.execute("SELECT * FROM exports ORDER BY created_at DESC LIMIT 500")]}

    def export_status(self, cnpjs):
        if not isinstance(cnpjs, list) or len(cnpjs) > 500 or any(
                not re.fullmatch(r"\d{14}", str(cnpj)) for cnpj in cnpjs):
            raise ValueError("Consulte até 500 CNPJs válidos por lote.")
        if not cnpjs:
            return {"exported": []}
        with self.session() as db:
            rows = db.execute(
                "SELECT DISTINCT x.cnpj FROM export_items x JOIN exports h ON h.id=x.export_id WHERE x.cnpj IN (" +
                ",".join("?" for _ in cnpjs) + ")", cnpjs).fetchall()
            return {"exported": [r[0] for r in rows]}
