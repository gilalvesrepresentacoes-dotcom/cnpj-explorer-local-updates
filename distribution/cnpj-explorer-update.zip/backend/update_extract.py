"""Extrator restrito de versões do programa; nunca lê a base ou as contas."""
import json
from pathlib import Path
import re
import stat
import sys
import zipfile

ALLOWED = re.compile(
    r"(?:backend/[a-z_]+\.py|backend/ui/[a-z_-]+\.(?:js|html|css)|"
    r"app/(?:main\.cjs|preload\.cjs|updater\.cjs|release-core\.cjs|package\.json)|"
    r"LEIA-ME-DESKTOP\.txt|release\.json)"
)


def extract(archive, destination):
    destination = Path(destination)
    if destination.is_symlink() or not destination.is_dir() or any(destination.iterdir()):
        raise ValueError("Pasta temporária inválida ou não vazia.")
    with zipfile.ZipFile(archive) as z:
        items = z.infolist()
        names = [i.filename for i in items]
        if len(items) > 201 or len(set(names)) != len(names):
            raise ValueError("Pacote com arquivos duplicados ou em excesso.")
        total = 0
        for i in items:
            mode = i.external_attr >> 16
            total += i.file_size
            if (not ALLOWED.fullmatch(i.filename) or i.is_dir() or
                    (stat.S_IFMT(mode) not in (0, stat.S_IFREG)) or
                    i.file_size > 4 * 1024 * 1024 or total > 32 * 1024 * 1024):
                raise ValueError("Arquivo ou tamanho não permitido na atualização.")
        for i in items:
            target = destination.joinpath(*i.filename.split("/"))
            target.parent.mkdir(parents=True, exist_ok=True)
            with z.open(i) as src, target.open("xb") as dst:
                while chunk := src.read(65536):
                    dst.write(chunk)
    return {"ok": True, "files": len(items)}


if __name__ == "__main__":
    try:
        print(json.dumps(extract(sys.argv[1], sys.argv[2])))
    except Exception:
        print(json.dumps({"ok": False, "error": "O pacote de atualização não pôde ser extraído com segurança."}))
        raise SystemExit(1)
