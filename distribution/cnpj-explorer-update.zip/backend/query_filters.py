"""Filtros validados compartilhados por consultas e exportações."""
import datetime
import json
from decimal import Decimal, InvalidOperation

from fields import ESTABLISHMENT, COMPANY, PARTNER, SIMPLE
from store import normalized

CHOICES = {
    "MATRIZ/FILIAL": [("1", "Matriz"), ("2", "Filial")],
    "SITUAÇÃO CADASTRAL": [("01", "Nula"), ("02", "Ativa"), ("03", "Suspensa"), ("04", "Inapta"), ("08", "Baixada")],
    "PORTE": [("00", "Não informado"), ("01", "Microempresa"), ("03", "Empresa de pequeno porte"), ("05", "Demais")],
    "OPÇÃO SIMPLES": [("S", "Sim"), ("N", "Não")], "OPÇÃO MEI": [("S", "Sim"), ("N", "Não")],
    "IDENTIFICADOR SÓCIO": [("1", "Pessoa jurídica"), ("2", "Pessoa física"), ("3", "Estrangeiro")],
    "FAIXA ETÁRIA": [(str(i), label) for i, label in enumerate([
        "Não se aplica", "0 a 12 anos", "13 a 20 anos", "21 a 30 anos", "31 a 40 anos",
        "41 a 50 anos", "51 a 60 anos", "61 a 70 anos", "71 a 80 anos", "Acima de 80 anos"])],
}
TEXT_OPS = ["contains", "not_contains", "starts_with", "eq", "ne", "in", "not_in", "is_empty", "not_empty"]
RANGE_OPS = ["eq", "ne", "gte", "lte", "between", "is_empty", "not_empty"]
FIELDS = {}
for group, alias, names in (("Estabelecimento", "e", ESTABLISHMENT), ("Empresa", "c", COMPANY),
                            ("Simples e MEI", "s", SIMPLE), ("Sócio", "p", PARTNER)):
    for name in names:
        ident = alias + "." + name
        kind = "date" if name.startswith("DATA ") else "number" if name == "CAPITAL SOCIAL" else "text"
        FIELDS[ident] = {"id": ident, "label": name, "group": group, "type": kind,
                         "operators": RANGE_OPS if kind != "text" else TEXT_OPS}
        if name in CHOICES:
            FIELDS[ident]["choices"] = [{"value": value, "label": value + " — " + label}
                                       for value, label in CHOICES[name]]
for ident, label in (("exported", "Já exportada"), ("has_phone", "Possui telefone"),
                     ("has_email", "Possui e-mail"), ("has_partners", "Possui sócios")):
    FIELDS[ident] = {"id": ident, "label": label, "group": "Disponibilidade", "type": "boolean",
                     "operators": ["eq"], "choices": [{"value": "1", "label": "Sim"}, {"value": "0", "label": "Não"}]}
FIELDS["cnpj"] = {"id": "cnpj", "label": "CNPJ completo", "group": "Estabelecimento",
                   "type": "text", "operators": TEXT_OPS}


def money_cents(value):
    try:
        amount = Decimal(str(value).replace(",", "."))
        return int(amount * 100) if amount.is_finite() and abs(amount) <= Decimal("1e15") else None
    except (InvalidOperation, ValueError, OverflowError):
        return None


def sql_value(alias, name):
    # Identifiers and JSON paths come exclusively from the constant layout.
    path = '$."' + name + '"'
    return f"coalesce(json_extract({alias}.data,'{path}'),'')"


def compile_rules(raw):
    if isinstance(raw, str):
        try:
            raw = json.loads(raw)
        except (ValueError, TypeError):
            raise ValueError("Os filtros avançados não são um JSON válido.")
    if not isinstance(raw, list) or len(raw) > 40:
        raise ValueError("Use até 40 filtros avançados.")
    clauses, values, partner_clauses, partner_values = [], [], [], []
    for rule in raw:
        if not isinstance(rule, dict) or rule.get("field") not in FIELDS:
            raise ValueError("Campo de filtro desconhecido.")
        field = FIELDS[rule["field"]]
        op = rule.get("op")
        if op not in field["operators"]:
            raise ValueError("Operador inválido para " + field["label"])
        name = field["id"]
        if field["type"] == "boolean":
            value = str(rule.get("value"))
            if value not in ("0", "1"):
                raise ValueError("Escolha Sim ou Não.")
            expr = {
                "exported": "EXISTS(SELECT 1 FROM export_items x JOIN exports h ON h.id=x.export_id WHERE x.cnpj=e.cnpj)",
                "has_phone": "(" + " OR ".join(f"length(trim({sql_value('e', n)}))>0" for n in ("TELEFONE 1", "TELEFONE 2")) + ")",
                "has_email": f"length(trim({sql_value('e', 'EMAIL')}))>0",
                "has_partners": "EXISTS(SELECT 1 FROM partners p WHERE p.job=e.job AND p.base=e.base)",
            }[name]
            clauses.append("(" + expr + ")" + ("=1" if value == "1" else "=0"))
            continue
        alias, source_name = name.split(".", 1) if "." in name else ("e", "")
        expr = "e.cnpj" if name == "cnpj" else sql_value(alias, source_name)
        target = partner_clauses if alias == "p" else clauses
        args = partner_values if alias == "p" else values
        if op in ("is_empty", "not_empty"):
            target.append(f"trim({expr})" + (
                (" IN ('','00000000')" if op == "is_empty" else " NOT IN ('','00000000')")
                if field["type"] == "date" else ("=''" if op == "is_empty" else "<>''")))
            continue

        def convert(value):
            if not isinstance(value, str) or not value.strip() or len(value) > 256:
                raise ValueError("Preencha um valor de até 256 caracteres para " + field["label"])
            if field["type"] == "number":
                result = money_cents(value)
                if result is None or result < 0 or Decimal(value.replace(",", ".")) * 100 != result:
                    raise ValueError("Capital social inválido; use até duas casas decimais, sem separador de milhar.")
                return result
            if field["type"] == "date":
                try:
                    return datetime.date.fromisoformat(value.strip()).isoformat().replace("-", "")
                except ValueError:
                    raise ValueError("Data inválida. Use AAAA-MM-DD.")
            return normalized(value)

        if op in ("in", "not_in"):
            parts = rule.get("value", "")
            parts = parts.split(",") if isinstance(parts, str) else parts
            if not isinstance(parts, list) or not 1 <= len(parts) <= 100:
                raise ValueError("Use de 1 a 100 valores por lista.")
            converted = [convert(v) for v in parts]
        else:
            converted = [convert(rule.get("value"))]
        if field["type"] == "text":
            expr = "fold(" + expr + ")"
        elif field["type"] == "number":
            expr = "money_cents(" + expr + ")"
        else:
            expr = f"nullif(nullif({expr},''),'00000000')"
        if op in ("contains", "not_contains"):
            target.append(f"instr({expr},?)" + (">0" if op == "contains" else "=0"))
        elif op == "starts_with":
            target.append(f"substr({expr},1,length(?))=?")
            converted *= 2
        elif op in ("in", "not_in"):
            target.append(expr + (" NOT IN (" if op == "not_in" else " IN (") +
                          ",".join("?" for _ in converted) + ")")
        elif op == "between":
            second = convert(rule.get("value2"))
            if converted[0] > second:
                raise ValueError("O início do intervalo deve ser menor ou igual ao fim.")
            target.append(expr + " BETWEEN ? AND ?")
            converted.append(second)
        else:
            target.append(expr + {"eq": "=?", "ne": "<>?", "gte": ">=?", "lte": "<=?"}[op])
        args.extend(converted)
    if partner_clauses:
        clauses.append("EXISTS(SELECT 1 FROM partners p WHERE p.job=e.job AND p.base=e.base AND " +
                       " AND ".join("(" + c + ")" for c in partner_clauses) + ")")
        values.extend(partner_values)
    return clauses, values
