"""Exportação em fluxo para o disco local, com histórico independente."""
import csv
import json
import os
import re
import shutil
import uuid
import zipfile
from pathlib import Path
from xml.sax.saxutils import escape

from engine import MIN_FREE, Paused, now
from fields import EXPORT_FIELDS
from store import dumps

JOIN = """ FROM establishments e
 LEFT JOIN companies c ON c.job=e.job AND c.base=e.base
 LEFT JOIN simples s ON s.job=e.job AND s.base=e.base """


def column_name(number):
    result = ""
    while number:
        number, remainder = divmod(number - 1, 26)
        result = chr(65 + remainder) + result
    return result


class Xlsx:
    """Inline strings preserve CNPJ zeros and never execute spreadsheet formulas."""
    def __init__(self, path, headers):
        self.zip = zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED, allowZip64=True)
        self.headers, self.sheets, self.stream, self.row = headers, 0, None, 0
        try:
            self.new_sheet()
        except Exception:
            self.close(False)
            raise

    def new_sheet(self):
        if self.stream:
            self.stream.write(b"</sheetData></worksheet>")
            self.stream.close()
        self.sheets += 1
        self.row = 0
        self.stream = self.zip.open(f"xl/worksheets/sheet{self.sheets}.xml", "w", force_zip64=True)
        self.stream.write(b'<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>')
        self.write(self.headers)

    def write(self, values):
        if self.row >= 1048576:
            self.new_sheet()
        self.row += 1
        cells = []
        for i, value in enumerate(values, 1):
            value = str(value or "")
            if len(value) > 32767:
                raise ValueError("Um campo excede o limite de 32.767 caracteres do Excel. Exporte em CSV para preservar todos os dados.")
            value = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", "", value)
            cells.append(f'<c r="{column_name(i)}{self.row}" t="inlineStr"><is><t xml:space="preserve">{escape(value)}</t></is></c>')
        self.stream.write((f'<row r="{self.row}">' + "".join(cells) + "</row>").encode())

    def close(self, successful=True):
        if self.stream:
            self.stream.write(b"</sheetData></worksheet>")
            self.stream.close()
            self.stream = None
        if successful:
            self.zip.writestr("[Content_Types].xml",
                '<?xml version="1.0"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
                '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
                '<Default Extension="xml" ContentType="application/xml"/>'
                '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>' +
                "".join(f'<Override PartName="/xl/worksheets/sheet{i}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
                        for i in range(1, self.sheets + 1)) + "</Types>")
            self.zip.writestr("_rels/.rels", '<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>')
            self.zip.writestr("xl/workbook.xml",
                '<?xml version="1.0"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>' +
                "".join(f'<sheet name="Empresas {i}" sheetId="{i}" r:id="rId{i}"/>' for i in range(1, self.sheets + 1)) +
                "</sheets></workbook>")
            self.zip.writestr("xl/_rels/workbook.xml.rels",
                '<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' +
                "".join(f'<Relationship Id="rId{i}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet{i}.xml"/>'
                        for i in range(1, self.sheets + 1)) + "</Relationships>")
        self.zip.close()


def csv_safe(value):
    value = str(value or "")
    return "'" + value if value.lstrip().startswith(("=", "+", "-", "@", "\t", "\r")) else value


class Exporter:
    def __init__(self, store, engine):
        self.store, self.engine = store, engine

    def request(self, body):
        if self.engine.running:
            raise ValueError("Aguarde ou pause a tarefa em andamento.")
        job_id = body.get("job_id", "")
        selected = body.get("selected", [])
        if not isinstance(selected, list):
            raise ValueError("A seleção deve ser uma lista de CNPJs.")
        policy = body.get("duplicate_policy", "ask")
        if policy not in ("ask", "all", "skip"):
            raise ValueError("Escolha repetir ou ignorar empresas já exportadas.")
        filters = body.get("filters") or {}
        where, values = self.store.conditions(job_id, filters, selected, policy == "skip")
        with self.store.session() as db:
            counts = db.execute("""SELECT count(*) AS matching,
                coalesce(sum(EXISTS(SELECT 1 FROM export_items x JOIN exports h ON h.id=x.export_id WHERE x.cnpj=e.cnpj)),0) AS duplicates""" +
                JOIN + " WHERE " + where, values).fetchone()
        if policy == "ask":
            return dict(counts)
        if not counts["matching"]:
            raise ValueError("Nenhuma empresa disponível para esta exportação.")
        fmt = body.get("format")
        if fmt not in ("csv", "xlsx"):
            raise ValueError("Formato de exportação inválido.")
        directory = Path(body.get("output_dir") or self.store.root / "exportacoes").expanduser()
        if not directory.is_absolute():
            raise ValueError("Informe uma pasta de destino absoluta.")
        if directory.drive and not Path(directory.anchor).is_dir():
            raise ValueError("A unidade de exportação não está conectada.")
        directory.mkdir(parents=True, exist_ok=True)
        if shutil.disk_usage(directory).free < MIN_FREE:
            raise ValueError("A pasta de exportação tem menos de 512 MiB livres.")
        self.engine.launch("export", lambda: self.run(job_id, where, values, fmt,
                           bool(body.get("include_partners")), directory, counts["matching"]))
        return {"started": True}

    def run(self, job_id, where, values, fmt, include_partners, directory, total=None):
        ident = uuid.uuid4().hex
        period = self.store.job(job_id)["period"]
        final = directory / f"cnpj-{period}-{ident[:12]}.{fmt}"
        partial = final.with_suffix(final.suffix + ".partial")
        db = self.store.connect()
        writer = stream = None
        completed = False
        try:
            if total is None:
                total = db.execute("SELECT count(*)" + JOIN + " WHERE " + where, values).fetchone()[0]
            def report(done, phase):
                if self.engine.task is not None:
                    self.engine.task.update(progress={"basis": "export_companies", "done": done,
                        "total": total, "phase": phase},
                        message=f"Exportando {done:,} de {total:,} empresas…" if phase == "writing" else
                        "Finalizando e salvando a planilha…")
            report(0, "writing")
            headers = EXPORT_FIELDS + (["SÓCIOS (JSON)"] if include_partners else [])
            if fmt == "csv":
                stream = partial.open("w", encoding="utf-8-sig", newline="")
                writer = csv.writer(stream, delimiter=";")
                writer.writerow(headers)
            else:
                writer = Xlsx(partial, headers)
            refs = {(r["kind"], r["code"]): r["label"]
                    for r in db.execute("SELECT kind,code,label FROM refs WHERE job=?", (job_id,))}
            count, after = 0, ""
            # Only batches of 500 payloads are materialized in RAM. Completed
            # bases are immutable, and the engine serializes exports/imports.
            while True:
                rows = db.execute("SELECT e.*,c.data AS company_data,s.data AS simple_data" + JOIN +
                                  " WHERE " + where + " AND e.cnpj>? ORDER BY e.cnpj LIMIT 500", values + [after]).fetchall()
                if not rows:
                    break
                if self.engine.stop.is_set():
                    raise Paused()
                if shutil.disk_usage(directory).free < MIN_FREE:
                    raise ValueError("Espaço livre insuficiente. A exportação não foi concluída.")
                with db:
                    for row in rows:
                        item = self.store.enriched(db, job_id, row, include_partners, refs, period)
                        values_out = [item["fields"].get(key, "") for key in EXPORT_FIELDS]
                        if include_partners:
                            values_out.append(dumps(item["partners"]))
                        if fmt == "csv":
                            writer.writerow([csv_safe(v) for v in values_out])
                        else:
                            writer.write(values_out)
                        db.execute("INSERT INTO export_items VALUES(?,?)", (ident, row["cnpj"]))
                        count += 1
                        if count % 100 == 0:
                            report(count, "writing")
                    after = rows[-1]["cnpj"]
                report(count, "writing")
            report(count, "finalizing")
            if fmt == "xlsx":
                writer.close()
                writer = None
                with partial.open("rb") as saved:
                    os.fsync(saved.fileno())
            else:
                stream.flush()
                os.fsync(stream.fileno())
                stream.close()
                stream = None
            os.replace(partial, final)
            with db:
                db.execute("INSERT INTO exports VALUES(?,?,?,?,?,?,?)",
                           (ident, now(), str(final), fmt, count, count, job_id))
            completed = True
            return {"id": ident, "path": str(final), "format": fmt, "companies": count, "rows": count}
        finally:
            if fmt == "xlsx" and writer is not None:
                writer.close(False)
            if stream is not None:
                stream.close()
            if not completed:
                with db:
                    db.execute("DELETE FROM export_items WHERE export_id=?", (ident,))
                partial.unlink(missing_ok=True)
            db.close()
