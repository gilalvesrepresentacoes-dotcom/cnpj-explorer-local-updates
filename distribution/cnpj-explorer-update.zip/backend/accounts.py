"""Contas locais por instalação. Sessões separadas; redefinição nunca revela senha."""
import copy
import hashlib
import hmac
import json
import re
import secrets
import threading
import time
from pathlib import Path

from local_mail import LocalMailer, atomic_json, email_address
from passwords import ITERATIONS, SESSION_SECONDS, PasswordGate

RESET_SECONDS = 15 * 60


class AccessDenied(PermissionError):
    pass


class LoginThrottled(ValueError):
    def __init__(self, retry_after):
        self.retry_after = retry_after
        super().__init__("Muitas tentativas. Aguarde antes de tentar novamente.")


def timestamp():
    from datetime import datetime, timezone
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def public_user(user):
    return {key: user.get(key) for key in (
        "id", "email", "name", "role", "active", "must_change_password", "created_at", "last_login")}


def password_values(body):
    value = body.get("password")
    if not isinstance(value, str) or not 10 <= len(value) <= 128:
        raise ValueError("Use uma senha com 10 a 128 caracteres.")
    if value != body.get("confirmation"):
        raise ValueError("A confirmação da senha não confere.")
    salt = secrets.token_hex(16)
    return {"salt": salt, "iterations": ITERATIONS, "hash": PasswordGate.digest(value, salt, ITERATIONS)}


def check_password(user, value):
    if not isinstance(value, str) or len(value) > 128:
        return False
    return hmac.compare_digest(PasswordGate.digest(value, user["salt"], user["iterations"]), user["hash"])


def recovery_values():
    code = secrets.token_hex(20).upper()
    return "-".join(code[i:i+5] for i in range(0, 40, 5)), hashlib.sha256(code.encode()).hexdigest()


class Accounts:
    def __init__(self, path, mailer=None):
        self.path = Path(path)
        self.lock = threading.RLock()
        self.sessions = {}
        self.attempts = {}
        self.attempt_key = ""
        self.reset_requests = {}
        self.delivery_slots = threading.BoundedSemaphore(2)
        self.recovery_url = None
        self.mailer = mailer or LocalMailer(self.path.with_name("mail.json"))
        self.legacy = None
        self.record = {"version": 2, "users": [], "resets": [], "events": []}
        if self.path.exists():
            record = json.loads(self.path.read_text("utf-8"))
            if not isinstance(record, dict):
                raise ValueError("Arquivo de acesso inválido. As bases não foram apagadas.")
            if record.get("version") == 1:
                self.legacy = PasswordGate(self.path)
            else:
                self.validate(record)
                self.record = record

    @staticmethod
    def validate(record):
        def valid(condition):
            if not condition:
                raise ValueError("invalid")
        try:
            valid(record["version"] == 2 and isinstance(record["users"], list) and record["users"])
            ids, emails = set(), set()
            for user in record["users"]:
                valid(isinstance(user["id"], str) and user["id"] not in ids)
                valid(email_address(user["email"]) == user["email"] and user["email"] not in emails)
                valid(user["role"] in ("admin", "user") and type(user["active"]) is bool)
                valid(type(user["must_change_password"]) is bool and type(user["auth_version"]) is int and user["auth_version"] >= 1)
                valid(type(user["iterations"]) is int and 100_000 <= user["iterations"] <= 2_000_000)
                valid(len(bytes.fromhex(user["salt"])) == 16 and len(bytes.fromhex(user["hash"])) == 32)
                valid(user.get("recovery_hash") is None or len(bytes.fromhex(user["recovery_hash"])) == 32)
                ids.add(user["id"]); emails.add(user["email"])
            valid(any(u["active"] and u["role"] == "admin" for u in record["users"]))
            valid(isinstance(record["resets"], list) and isinstance(record["events"], list))
            for entry in record["resets"]:
                valid(entry["user_id"] in ids and len(bytes.fromhex(entry["hash"])) == 32)
                valid(isinstance(entry["expires"], (int, float)) and type(entry["version"]) is int)
        except (AssertionError, KeyError, TypeError, ValueError):
            raise ValueError("Arquivo de contas inválido. Restaure a configuração; não apague as bases.") from None

    def commit(self, record):
        atomic_json(self.path, record)
        self.record = record

    def user(self, user_id):
        return next((u for u in self.record["users"] if u["id"] == user_id), None)

    def session_user(self, session):
        value = self.sessions.get(session or "")
        if not value or value["expires"] <= time.monotonic():
            self.sessions.pop(session or "", None)
            return None
        if value["id"] == "legacy" and self.legacy:
            return {"id": "legacy", "role": "admin", "active": True, "email": "", "name": "Administrador",
                    "auth_version": 1, "must_change_password": False}
        user = self.user(value["id"])
        if not user or not user["active"] or user["auth_version"] != value["version"]:
            self.sessions.pop(session or "", None)
            return None
        return user

    def status(self, session=""):
        with self.lock:
            user = self.session_user(session)
            return {"configured": bool(self.legacy or self.record["users"]),
                    "authenticated": user is not None, "legacy": self.legacy is not None,
                    "migration_required": bool(user and self.legacy),
                    "must_change_password": bool(user and user["must_change_password"]),
                    "user": public_user(user) if user else None,
                    "email_recovery_available": bool(not self.legacy and self.mailer.available()),
                    "retry_after": self.retry("login:" + user["email"]) if user else 0}

    def retry(self, key):
        return max(0, int(self.attempts.get(key, (0, 0))[1] - time.monotonic() + .99))

    def require(self, session="", touch=False, allow_pending=False):
        with self.lock:
            user = self.session_user(session)
            if not user:
                raise PermissionError("Entre com seu e-mail e senha para acessar o programa.")
            if not allow_pending and (self.legacy or user["must_change_password"]):
                raise PermissionError("Conclua o cadastro ou troque a senha temporária antes de acessar os dados.")
            if touch:
                self.sessions[session]["expires"] = time.monotonic() + SESSION_SECONDS
            return user

    def admin(self, session):
        user = self.require(session, touch=True)
        if user["role"] != "admin":
            raise AccessDenied("Esta operação é exclusiva do administrador.")
        return user

    def signed_in(self, user, recovery=None):
        self.sessions = {k: v for k, v in self.sessions.items() if v["expires"] > time.monotonic()}
        token = secrets.token_urlsafe(32)
        self.sessions[token] = {"id": user["id"], "version": user["auth_version"],
                                "expires": time.monotonic() + SESSION_SECONDS}
        self.attempts.pop(self.attempt_key, None)
        self.attempts.pop("login:" + (user.get("email") or ""), None)
        result = {**self.status(token), "session_token": token}
        if recovery:
            result["recovery_code"] = recovery
        return result

    def failed(self):
        failures = self.attempts.get(self.attempt_key, (0, 0))[0] + 1
        self.attempts[self.attempt_key] = (failures, time.monotonic() + (
            min(300, 2 ** min(failures, 9)) if failures >= 5 else 0))
        if self.retry(self.attempt_key):
            raise LoginThrottled(self.retry(self.attempt_key))
        raise ValueError("E-mail, senha ou código de recuperação incorreto.")

    @staticmethod
    def identity(body):
        email = email_address(body.get("email"))
        name = str(body.get("name", "")).strip() or email.split("@")[0]
        if len(name) > 100 or any(ord(c) < 32 for c in name):
            raise ValueError("Nome inválido.")
        return email, name

    def new_user(self, body, credentials, role="admin", temporary=False):
        email, name = self.identity(body)
        if any(u["email"] == email for u in self.record["users"]):
            raise ValueError("Este e-mail já está cadastrado.")
        return {"id": secrets.token_hex(16), "email": email, "name": name, "role": role, "active": True,
                "must_change_password": temporary, "auth_version": 1, "created_at": timestamp(),
                "last_login": None, "recovery_hash": None, **credentials}

    @staticmethod
    def event(record, action, actor, target):
        record["events"] = (record["events"] + [{"at": timestamp(), "action": action,
                                               "actor": actor["email"], "target": target["email"]}])[-200:]

    @staticmethod
    def revoke(record, user):
        user["auth_version"] += 1
        record["resets"] = [r for r in record["resets"] if r["user_id"] != user["id"]]

    def handle(self, operation, body, session=""):
        if operation == "request-reset":
            return self.request_reset(body)
        with self.lock:
            if operation == "status":
                return self.status(session)
            if operation == "logout":
                self.sessions.pop(session or "", None)
                return {"authenticated": False}
            identity = body.get("email") or (self.session_user(session) or {}).get("email") or "local"
            self.attempt_key = operation + ":" + str(identity).strip().lower()[:254]
            if len(self.attempts) > 1000:
                self.attempts = {k: v for k, v in self.attempts.items() if v[1] > time.monotonic()}
            if self.retry(self.attempt_key):
                raise LoginThrottled(self.retry(self.attempt_key))
            if operation == "setup":
                if self.legacy or self.record["users"]:
                    raise ValueError("Já existe administrador. Entre ou recupere seu acesso.")
                credentials = password_values(body)
                user = self.new_user(body, credentials)
                code, user["recovery_hash"] = recovery_values()
                record = copy.deepcopy(self.record)
                record["users"].append(user)
                self.event(record, "primeiro administrador", user, user)
                self.commit(record)
                return self.signed_in(user, code)
            if self.legacy:
                return self.handle_legacy(operation, body, session)
            if operation == "login":
                try:
                    email = email_address(body.get("email"))
                except ValueError:
                    email = ""
                user = next((u for u in self.record["users"] if u["email"] == email), None)
                # Unknown addresses incur the same password derivation, not a cheap existence oracle.
                candidate = user or {"salt": "00" * 16, "hash": "00" * 32, "iterations": ITERATIONS}
                valid = check_password(candidate, body.get("password"))
                if not user or not valid or not user["active"]:
                    self.failed()
                record = copy.deepcopy(self.record)
                updated = next(u for u in record["users"] if u["id"] == user["id"])
                updated["last_login"] = timestamp()
                self.commit(record)
                return self.signed_in(updated)
            if operation == "change":
                current = self.require(session, allow_pending=True)
                if not check_password(current, body.get("current_password")):
                    self.failed()
                if body.get("current_password") == body.get("password"):
                    raise ValueError("Escolha uma senha diferente da atual ou temporária.")
                return self.replace_password(current, body, authenticate=True)
            if operation == "recover":
                try:
                    email = email_address(body.get("email"))
                except ValueError:
                    email = ""
                current = next((u for u in self.record["users"] if u["email"] == email), None)
                code = body.get("recovery_code")
                if not isinstance(code, str) or len(code) > 100:
                    self.failed()
                digest = hashlib.sha256(code.replace("-", "").replace(" ", "").upper().encode()).hexdigest()
                if (not current or not current["active"] or current["role"] != "admin"
                        or not current.get("recovery_hash") or not hmac.compare_digest(digest, current["recovery_hash"])):
                    self.failed()
                return self.replace_password(current, body, authenticate=True)
            if operation == "reset-password":
                token = body.get("token", "")
                if not isinstance(token, str) or not re.fullmatch(r"[a-zA-Z0-9_-]{43}", token):
                    self.failed()
                digest = hashlib.sha256(token.encode()).hexdigest()
                entry = next((r for r in self.record["resets"] if hmac.compare_digest(r["hash"], digest)), None)
                current = self.user(entry["user_id"]) if entry else None
                if (not entry or entry["expires"] <= time.time() or not current or not current["active"]
                        or current["auth_version"] != entry["version"]):
                    self.failed()
                return self.replace_password(current, body, authenticate=False)
            raise ValueError("Operação de acesso desconhecida.")

    def replace_password(self, current, body, authenticate):
        credentials = password_values(body)
        if check_password(current, body["password"]):
            raise ValueError("Escolha uma senha diferente da anterior.")
        record = copy.deepcopy(self.record)
        user = next(u for u in record["users"] if u["id"] == current["id"])
        user.update(credentials)
        user["must_change_password"] = False
        code = None
        if user["role"] == "admin":
            code, user["recovery_hash"] = recovery_values()
        self.revoke(record, user)
        self.event(record, "senha alterada", user, user)
        self.commit(record)
        self.attempts.pop(self.attempt_key, None)
        self.attempts.pop("login:" + user["email"], None)
        if authenticate:
            return self.signed_in(user, code)
        result = {"message": "Senha redefinida. Entre no programa com seu e-mail e a nova senha."}
        if code:
            result["recovery_code"] = code
        return result

    def handle_legacy(self, operation, body, session):
        if operation == "login":
            if not self.legacy.verify(body.get("password")):
                self.failed()
            return self.signed_in({"id": "legacy", "auth_version": 1})
        if operation == "recover":
            code = body.get("recovery_code", "")
            if not isinstance(code, str) or len(code) > 100:
                self.failed()
            digest = hashlib.sha256(code.replace("-", "").replace(" ", "").upper().encode()).hexdigest()
            if not hmac.compare_digest(digest, self.legacy.record["recovery_hash"]):
                self.failed()
            result = self.legacy.save_password(body)
            return self.signed_in({"id": "legacy", "auth_version": 1}, result["recovery_code"])
        if operation == "migrate":
            self.require(session, allow_pending=True)
            if not self.legacy.verify(body.get("current_password")):
                self.failed()
            user = self.new_user(body, {k: self.legacy.record[k] for k in ("salt", "hash", "iterations", "recovery_hash")})
            record = copy.deepcopy(self.record)
            record["users"].append(user)
            self.event(record, "migração de acesso antigo", user, user)
            self.commit(record)
            self.legacy = None
            self.sessions.clear()
            return self.signed_in(user)
        raise ValueError("Entre com a senha antiga e cadastre o e-mail do administrador para continuar.")

    def handle_admin(self, path, body, session):
        with self.lock:
            actor = self.admin(session)
            if path == "/api/admin/mail":
                return self.mailer.public()
            if path == "/api/admin/mail/save":
                result = self.mailer.save(body)
                return result
            if path == "/api/admin/mail/test":
                recipient = actor["email"]
            elif path == "/api/admin/users":
                return {"items": [public_user(u) for u in self.record["users"]], "events": self.record["events"][-50:][::-1]}
            else:
                return self.manage_user(path, body, actor)
        # Never hold the account lock during network operations.
        return {**self.mailer.send(recipient, "Teste de recuperação — CNPJ Explorer Local",
                                  "Este teste foi solicitado no painel do administrador. Nenhum dado de empresas foi enviado.",
                                  testing=True), **self.mailer.public()}

    def manage_user(self, path, body, actor):
        record = copy.deepcopy(self.record)
        if path == "/api/admin/users/create":
            if len(record["users"]) >= 500:
                raise ValueError("Limite de 500 contas locais atingido.")
            if body.get("role", "user") not in ("user", "admin"):
                raise ValueError("Perfil inválido.")
            temporary = secrets.token_urlsafe(15)
            user = self.new_user(body, password_values({"password": temporary, "confirmation": temporary}),
                                 role=body.get("role", "user"), temporary=True)
            record["users"].append(user)
            action = "usuário criado"
        else:
            user = next((u for u in record["users"] if u["id"] == body.get("id")), None)
            if not user:
                raise ValueError("Usuário não encontrado.")
            temporary = None
            if path == "/api/admin/users/reset":
                if user["id"] == actor["id"]:
                    raise ValueError("Para sua própria conta, use Trocar senha.")
                temporary = secrets.token_urlsafe(15)
                user.update(password_values({"password": temporary, "confirmation": temporary}))
                user["recovery_hash"] = None
                user["must_change_password"] = True
                self.revoke(record, user)
                action = "senha temporária criada"
            elif path == "/api/admin/users/update":
                email, name = self.identity(body)
                if any(u["id"] != user["id"] and u["email"] == email for u in record["users"]):
                    raise ValueError("Este e-mail já está cadastrado.")
                role, active = body.get("role"), body.get("active")
                if role not in ("admin", "user") or type(active) is not bool:
                    raise ValueError("Perfil ou situação inválida.")
                if user["id"] == actor["id"] and not active:
                    raise ValueError("Você não pode bloquear sua própria conta.")
                if (user["email"], user["role"], user["active"]) != (email, role, active):
                    self.revoke(record, user)
                if role != user["role"]:
                    user["recovery_hash"] = None
                    if role == "admin":
                        user["must_change_password"] = True
                user.update(email=email, name=name, role=role, active=active)
                action = "cadastro atualizado"
            else:
                raise ValueError("Operação de administração desconhecida.")
        if not any(u["active"] and u["role"] == "admin" for u in record["users"]):
            raise ValueError("Mantenha pelo menos um administrador ativo.")
        self.event(record, action, actor, user)
        self.commit(record)
        result = {"user": public_user(user)}
        if temporary:
            result["temporary_password"] = temporary
        return result

    def request_reset(self, body):
        email = email_address(body.get("email"))
        with self.lock:
            if self.legacy or not self.mailer.available() or not self.recovery_url:
                raise ValueError("Recuperação por e-mail indisponível. Peça ao administrador para configurar e testar o envio.")
            now = time.time()
            self.reset_requests = {key: [t for t in times if now-t < RESET_SECONDS]
                                   for key, times in self.reset_requests.items() if any(now-t < RESET_SECONDS for t in times)}
            key = hashlib.sha256(email.encode()).hexdigest()
            if len(self.reset_requests.get(key, [])) >= 3 or sum(map(len, self.reset_requests.values())) >= 20:
                raise ValueError("Limite de solicitações atingido. Aguarde 15 minutos ou peça ajuda ao administrador.")
            self.reset_requests.setdefault(key, []).append(now)
            result = {"message": "Se o e-mail estiver cadastrado e ativo, enviaremos as instruções. Confira a caixa de entrada e o spam; se não chegar, peça ajuda ao administrador."}
            current = next((u for u in self.record["users"] if u["email"] == email and u["active"]), None)
            if not current:
                return result
            if not self.delivery_slots.acquire(blocking=False):
                # Same public response: do not disclose whether this address is registered.
                return result
            try:
                token = secrets.token_urlsafe(32)
                digest = hashlib.sha256(token.encode()).hexdigest()
                record = copy.deepcopy(self.record)
                record["resets"] = [r for r in record["resets"] if r["expires"] > now]
                record["resets"].append({"hash": digest, "user_id": current["id"],
                                         "version": current["auth_version"], "expires": now+RESET_SECONDS})
                self.commit(record)
                url = self.recovery_url(token)
                thread = threading.Thread(target=self.deliver_reset, args=(email, current["id"], digest, token, url), daemon=True)
                thread.start()
            except Exception:
                self.delivery_slots.release()
                raise
            return result

    def deliver_reset(self, email, user_id, digest, token, url):
        success = False
        try:
            self.mailer.send(email, "Redefinir senha — CNPJ Explorer Local",
                             "Foi solicitada uma nova senha para sua conta local.\n\n"
                             "Abra o link NO MESMO COMPUTADOR, com o CNPJ Explorer Local aberto:\n" + url +
                             "\n\nO link expira em 15 minutos e só pode ser usado uma vez.\n"
                             "Se o link não abrir, use 'Já tenho o código de e-mail' no programa e cole:\n" + token +
                             "\n\nSe você não solicitou, ignore. Sua senha atual não foi alterada.")
            success = True
        except Exception:
            pass  # The administrator gets a sanitized SMTP result; recipients never receive secrets in errors.
        finally:
            try:
                with self.lock:
                    record = copy.deepcopy(self.record)
                    # Concurrent successful messages must not invalidate each other's links.
                    # A successful password reset revokes every remaining token for that user.
                    record["resets"] = [r for r in record["resets"] if r["expires"] > time.time()
                                        and (success or r["hash"] != digest)]
                    self.commit(record)
            finally:
                self.delivery_slots.release()
