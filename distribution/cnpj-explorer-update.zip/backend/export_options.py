"""User-scoped spreadsheet layouts; no company data or credentials are stored."""
import json
import os
import threading
import uuid
from pathlib import Path

from fields import EXPORT_FIELDS

PARTNERS = "SÓCIOS (JSON)"
FIELDS = EXPORT_FIELDS + [PARTNERS]
SORT_OPTIONS = [
    {"value": "cnpj", "label": "CNPJ (ordem atual)"},
    {"value": "city_neighborhood", "label": "Cidade → Bairro → Razão social (A–Z)"},
]


def layout(body):
    if not isinstance(body, dict):
        raise ValueError("A configuração das colunas é inválida.")
    columns = body.get("columns")
    if columns is None and "columns" not in body:
        columns = EXPORT_FIELDS + ([PARTNERS] if body.get("include_partners") else [])
    if (not isinstance(columns, list) or not columns or len(columns) > len(FIELDS)
            or any(not isinstance(key, str) or key not in FIELDS for key in columns)
            or len(set(columns)) != len(columns)):
        raise ValueError("Selecione ao menos uma coluna válida, sem nomes repetidos.")
    sort = body.get("sort", "cnpj")
    if sort not in ("cnpj", "city_neighborhood"):
        raise ValueError("Escolha uma ordenação válida para a planilha.")
    return {"columns": list(columns), "sort": sort}


class ExportOptions:
    def __init__(self, path):
        self.path = Path(path)
        self.lock = threading.RLock()

    def read(self):
        if not self.path.exists():
            return {}
        try:
            data = json.loads(self.path.read_text("utf-8"))
            if not isinstance(data, dict):
                raise ValueError()
            return data
        except (ValueError, OSError) as error:
            raise ValueError("Não foi possível ler as configurações de colunas. "
                             "As configurações anteriores não foram alteradas.") from error

    def get(self, owner):
        with self.lock:
            data = self.read()
            saved = owner in data
            chosen = layout(data[owner] if saved else {})
            return dict(chosen, fields=FIELDS, saved=saved, sort_options=SORT_OPTIONS)

    def save(self, owner, body):
        if "columns" not in body:
            raise ValueError("Informe as colunas que deseja lembrar.")
        chosen = layout(body)
        with self.lock:
            data = self.read()
            data[owner] = chosen
            self.path.parent.mkdir(parents=True, exist_ok=True)
            temporary = self.path.with_name(self.path.name + "." + uuid.uuid4().hex + ".tmp")
            try:
                fd = os.open(temporary, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
                with os.fdopen(fd, "w", encoding="utf-8") as stream:
                    json.dump(data, stream, ensure_ascii=False)
                    stream.flush()
                    os.fsync(stream.fileno())
                os.replace(temporary, self.path)
            finally:
                temporary.unlink(missing_ok=True)
            return self.get(owner)
