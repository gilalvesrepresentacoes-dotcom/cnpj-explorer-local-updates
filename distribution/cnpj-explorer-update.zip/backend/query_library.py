"""Private local municipality groups and materialized query memberships."""
import json
import uuid
from datetime import datetime, timezone

from store import codes, dumps

JOIN = """ FROM establishments e
 LEFT JOIN companies c ON c.job=e.job AND c.base=e.base
 LEFT JOIN simples s ON s.job=e.job AND s.base=e.base """


class QueryLibrary:
    def __init__(self, store):
        self.store = store
        with store.session() as db:
            db.executescript("""
                CREATE TABLE IF NOT EXISTS query_library(
                    id TEXT PRIMARY KEY, owner TEXT NOT NULL, kind TEXT NOT NULL,
                    name TEXT NOT NULL, created_at TEXT NOT NULL, payload TEXT NOT NULL);
                CREATE INDEX IF NOT EXISTS query_library_owner ON query_library(owner,kind);
                CREATE TABLE IF NOT EXISTS query_members(
                    saved_id TEXT NOT NULL, cnpj TEXT NOT NULL, PRIMARY KEY(saved_id,cnpj));
            """)

    def get(self, ident, owner, kind="result"):
        if not owner:
            raise ValueError("Conta da consulta não identificada.")
        with self.store.session() as db:
            row = db.execute("SELECT * FROM query_library WHERE id=? AND owner=? AND kind=?",
                             (ident, owner, kind)).fetchone()
        if not row:
            raise ValueError("Consulta ou grupo salvo não encontrado nesta conta e pasta.")
        return self.decode(row)

    @staticmethod
    def decode(row):
        item = dict(row)
        item["payload"] = json.loads(item["payload"])
        item.pop("owner", None)
        return item

    def count(self, body, owner):
        filters = dict(body.get("filters") or {}, _owner=owner)
        where, values = self.store.conditions(body.get("job_id", ""), filters)
        with self.store.session() as db:
            return {"count": db.execute("SELECT count(*)" + JOIN + " WHERE " + where, values).fetchone()[0]}

    def handle(self, body, owner):
        action = body.get("action", "list")
        if action == "list":
            with self.store.session() as db:
                return {"items": [self.decode(row) for row in db.execute(
                    "SELECT * FROM query_library WHERE owner=? ORDER BY created_at DESC,id", (owner,))]}
        if action == "get":
            return self.get(body.get("id", ""), owner, body.get("kind", "result"))
        if action == "delete":
            item = self.get(body.get("id", ""), owner, body.get("kind", "result"))
            with self.store.session() as db:
                db.execute("DELETE FROM query_members WHERE saved_id=?", (item["id"],))
                db.execute("DELETE FROM query_library WHERE id=? AND owner=?", (item["id"], owner))
            return {"ok": True}
        if action not in ("save_group", "save_result"):
            raise ValueError("Operação de consultas salvas inválida.")
        name = str(body.get("name", "")).strip()
        if not name or len(name) > 100:
            raise ValueError("Informe um nome com até 100 caracteres.")
        ident = uuid.uuid4().hex
        created = datetime.now(timezone.utc).isoformat()
        if action == "save_group":
            payload = {"cities": codes(body.get("cities", []), 4, "Municípios")}
            if not payload["cities"]:
                raise ValueError("Selecione ao menos um município para salvar o grupo.")
            kind = "group"
        else:
            kind = "result"
            filters = dict(body.get("filters") or {}, _owner=owner)
            job_id = body.get("job_id", "")
            where, values = self.store.conditions(job_id, filters)
            selected = body.get("selected", [])
            if not isinstance(selected, list) or len(selected) > 3000:
                raise ValueError("Seleção manual inválida: máximo de 3.000 empresas.")
            if any(not __import__("re").fullmatch(r"\d{14}", str(s)) for s in selected):
                raise ValueError("Seleção de CNPJs inválida.")
            payload = {"job_id": job_id, "selected": sorted(set(selected)),
                       "all_selected": body.get("all_selected") is True}
        with self.store.session() as db:
            limit = 100 if kind == "group" else 50
            if db.execute("SELECT count(*) FROM query_library WHERE owner=? AND kind=?",
                          (owner, kind)).fetchone()[0] >= limit:
                raise ValueError(f"Limite de {limit} itens salvos. Exclua um item antigo para salvar outro.")
            if kind == "result":
                # One atomic INSERT SELECT, streamed by SQLite, never a huge list in JS/Python.
                # Completed bases are immutable. Store membership, not a recipe that
                # reruns the original (potentially expensive) filtering on reopening.
                db.execute("INSERT INTO query_members SELECT ?,e.cnpj" + JOIN + " WHERE " + where,
                           [ident] + values)
                payload["count"] = db.execute(
                    "SELECT count(*) FROM query_members WHERE saved_id=?", (ident,)).fetchone()[0]
                if not payload["count"]:
                    raise ValueError("A consulta está vazia. Não há resultado para salvar.")
                if selected:
                    matches = db.execute("SELECT count(*) FROM query_members WHERE saved_id=? AND cnpj IN (" +
                                         ",".join("?" for _ in selected) + ")", [ident] + selected).fetchone()[0]
                    if matches != len(set(selected)):
                        raise ValueError("A seleção mudou ou contém empresas fora deste resultado.")
            db.execute("INSERT INTO query_library VALUES(?,?,?,?,?,?)",
                       (ident, owner, kind, name, created, dumps(payload)))
        return {"id": ident, "name": name, "kind": kind, "payload": payload, "created_at": created}
