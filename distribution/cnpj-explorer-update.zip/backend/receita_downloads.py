"""Catálogo público da Receita e downloads em fluxo para o disco local."""
import base64
import copy
import json
import os
import re
import shutil
import threading
import time
import uuid
import zipfile
from pathlib import Path
from urllib.parse import quote, unquote, urlsplit
from urllib.request import Request, urlopen
from xml.etree import ElementTree

HOST = "https://arquivos.receitafederal.gov.br"
SHARE = "YggdBLfdninEJX9"  # Identificador do compartilhamento público, não senha.
DAV = HOST + "/public.php/webdav/"
HEADERS = {"Authorization": "Basic " + base64.b64encode((SHARE + ":").encode()).decode(),
           "User-Agent": "CNPJ-Explorer-Local", "Accept-Encoding": "identity"}
NS = {"d": "DAV:"}
MAX_XML = 4 * 1024 * 1024


def valid_period(value):
    if not isinstance(value, str) or not re.fullmatch(r"\d{4}-(0[1-9]|1[0-2])", value):
        raise ValueError("Selecione uma competência válida (AAAA-MM).")
    return value


def category(name):
    stem = name[:-4].lower()
    if stem in ("cnae", "cnaes", "motivos", "municipios", "naturezas", "paises", "qualificacoes"):
        return "Tabelas auxiliares", 0
    for prefix, label, order in (("estabelecimentos", "Estabelecimentos", 1),
                                  ("empresas", "Empresas", 2), ("socios", "Sócios", 3)):
        if re.fullmatch(prefix + r"\d+", stem):
            return label, order
    return ("Simples e MEI", 4) if stem == "simples" else ("Outros arquivos", 5)


class Catalog:
    def __init__(self, opener=urlopen):
        self.opener = opener
        self.cache = {}
        self.lock = threading.Lock()

    def listing(self, period=""):
        if period:
            valid_period(period)
        with self.lock:
            cached = self.cache.get(period)
            if cached and cached[0] > time.monotonic():
                return copy.deepcopy(cached[1])
            request = Request(DAV + (period + "/" if period else ""),
                              headers=dict(HEADERS, Depth="1"), method="PROPFIND")
            try:
                with self.opener(request, timeout=45) as response:
                    if response.status != 207:
                        raise ValueError("A Receita não confirmou o catálogo de arquivos.")
                    data = response.read(MAX_XML + 1)
            except (OSError, TimeoutError) as error:
                raise ValueError("Não foi possível consultar a Receita. Verifique a internet e tente novamente.") from error
            if len(data) > MAX_XML or b"<!DOCTYPE" in data.upper() or b"<!ENTITY" in data.upper():
                raise ValueError("Catálogo da Receita inválido ou muito grande.")
            try:
                root = ElementTree.fromstring(data)
            except ElementTree.ParseError as error:
                raise ValueError("A Receita retornou um catálogo em formato inválido.") from error
            if root.tag != "{DAV:}multistatus":
                raise ValueError("A Receita retornou um catálogo em formato desconhecido.")
            items = []
            for node in root.findall("d:response", NS):
                href = unquote(node.findtext("d:href", default="", namespaces=NS))
                for stat in node.findall("d:propstat", NS):
                    if " 200 " not in stat.findtext("d:status", default="", namespaces=NS):
                        continue
                    raw_size = stat.findtext("d:prop/d:getcontentlength", default="0", namespaces=NS)
                    try:
                        size = max(0, int(raw_size))
                    except ValueError:
                        continue
                    items.append({"href": href, "size": size})
                    break
            self.cache[period] = (time.monotonic() + 900, items)
            return copy.deepcopy(items)

    def periods(self):
        found = set()
        for item in self.listing():
            match = re.search(r"/(\d{4}-(?:0[1-9]|1[0-2]))/$", item["href"])
            if match:
                found.add(match[1])
        return sorted(found, reverse=True)

    def files(self, period):
        valid_period(period)
        found = {}
        for item in self.listing(period):
            path = urlsplit(item["href"]).path
            match = re.search(r"/" + re.escape(period) + r"/([A-Za-z0-9]+\.zip)$", path, re.I)
            if not match:
                continue
            name = match[1]
            group, order = category(name)
            found[name] = {"name": name, "size": item["size"], "group": group, "order": order}
        return sorted(found.values(), key=lambda f: (f["order"], f["name"].lower()))


class DownloadStopped(Exception):
    pass


class Downloads:
    def __init__(self, state_file, catalog=None, opener=urlopen):
        self.state_file = Path(state_file)
        self.catalog = catalog or Catalog()
        self.opener = opener
        self.lock = threading.RLock()
        self.stop = threading.Event()
        self.thread = None
        self.task = None
        if self.state_file.exists():
            try:
                task = json.loads(self.state_file.read_text("utf-8"))
                if isinstance(task, dict):
                    self.task = task
                    if task.get("status") == "running":
                        task.update(status="paused", message="Programa encerrado durante o download. ZIPs concluídos foram preservados. Selecione os arquivos que faltam para baixar novamente.")
                        for item in task.get("queue", []):
                            if item.get("status") in ("running", "queued"):
                                item["status"] = "paused"
            except (OSError, ValueError):
                pass  # Um histórico opcional danificado não pode impedir abrir a base.

    @property
    def running(self):
        return bool(self.thread and self.thread.is_alive())

    def status(self):
        with self.lock:
            return {"running": self.running, "task": copy.deepcopy(self.task)}

    def save(self):
        self.state_file.parent.mkdir(parents=True, exist_ok=True)
        temp = self.state_file.with_suffix(".tmp")
        temp.write_text(json.dumps(self.task, ensure_ascii=False), "utf-8")
        temp.replace(self.state_file)

    def pause(self):
        with self.lock:
            if self.running:
                self.stop.set()
                self.task["stopping"] = True
                self.task["message"] = "Interrompendo o download. Aguarde; os ZIPs já salvos serão mantidos."
            return {"ok": True, "pending": self.running}

    def start(self, body):
        with self.lock:
            if self.running:
                raise ValueError("Já há um download em andamento. Aguarde ou interrompa.")
            period = valid_period(body.get("period"))
            names = body.get("names")
            if not isinstance(names, list) or not names or len(names) > 150 or any(not isinstance(n, str) for n in names):
                raise ValueError("Selecione de 1 a 150 arquivos ZIP.")
            if len(names) != len(set(names)):
                raise ValueError("A seleção contém arquivos repetidos.")
            available = {f["name"]: f for f in self.catalog.files(period)}
            if any(name not in available for name in names):
                raise ValueError("Há arquivos que não constam no catálogo desta competência. Consulte a lista novamente.")
            files = sorted((available[n] for n in names), key=lambda f: (f["order"], f["name"]))
            parent = Path(str(body.get("directory", "")).strip()).expanduser()
            if not parent.is_absolute() or parent.suffix.lower() == ".zip":
                raise ValueError("Informe uma pasta absoluta para receber os downloads, não um arquivo ZIP.")
            parent.mkdir(parents=True, exist_ok=True)
            root = parent / period
            if root.is_symlink():
                raise ValueError("A pasta da competência não pode ser um atalho simbólico.")
            root.mkdir(exist_ok=True)
            existing = [f["name"] for f in files if (root / f["name"]).exists()]
            if existing and body.get("overwrite") is not True:
                raise ValueError("Já existem ZIPs nesta pasta: " + ", ".join(existing[:5]) +
                                 ". Desmarque esses arquivos ou autorize substituir os ZIPs existentes.")
            if any((root / f["name"]).is_symlink() or (root / f["name"]).is_dir() for f in files):
                raise ValueError("Um dos destinos é uma pasta ou atalho simbólico. Escolha outra pasta.")
            total = sum(f["size"] for f in files)
            if shutil.disk_usage(root).free < total + 128 * 1024 * 1024:
                raise ValueError("Não há espaço livre suficiente para os ZIPs selecionados e a margem de segurança.")
            self.stop.clear()
            self.task = {"status": "running", "period": period, "directory": str(root),
                         "bytes_done": 0, "bytes_total": total, "completed_files": 0,
                         "total_files": len(files), "current_file": "", "error": "",
                         "message": "Iniciando download direto da Receita para este computador."}
            self.save()
            self.thread = threading.Thread(target=self.run, args=(root, period, files), daemon=True)
            self.thread.start()
            return self.status()

    def start_batch(self, body):
        """Validate the entire selection before downloading any month or replacing a ZIP."""
        with self.lock:
            if self.running:
                raise ValueError("Já há um download em andamento. Aguarde ou interrompa.")
            items = body.get("items")
            if not isinstance(items, list) or not 1 <= len(items) <= 120:
                raise ValueError("Selecione de 1 a 120 competências.")
            parent = Path(str(body.get("directory", "")).strip()).expanduser()
            if not parent.is_absolute() or parent.suffix.lower() == ".zip":
                raise ValueError("Informe uma pasta absoluta para receber os downloads, não um arquivo ZIP.")
            if parent.drive and not Path(parent.anchor).is_dir():
                raise ValueError("A unidade escolhida não está conectada.")
            parent.mkdir(parents=True, exist_ok=True)
            seen, plan = set(), []
            for item in items:
                if not isinstance(item, dict):
                    raise ValueError("Seleção de competências inválida.")
                period = valid_period(item.get("period"))
                if period in seen:
                    raise ValueError("A seleção contém competências repetidas.")
                seen.add(period)
                names = item.get("names")
                if (not isinstance(names, list) or not 1 <= len(names) <= 150 or
                        any(not isinstance(n, str) for n in names) or len(set(names)) != len(names)):
                    raise ValueError("Selecione de 1 a 150 ZIPs distintos em cada competência.")
                available = {f["name"]: f for f in self.catalog.files(period)}
                if any(n not in available for n in names):
                    raise ValueError("Há ZIPs que não constam no catálogo de " + period + ". Atualize a lista.")
                files = sorted((available[n] for n in names), key=lambda f: (f["order"], f["name"]))
                root = parent / period
                if root.is_symlink():
                    raise ValueError("A pasta da competência não pode ser um atalho simbólico.")
                root.mkdir(exist_ok=True)
                if any((root / f["name"]).is_symlink() or (root / f["name"]).is_dir() for f in files):
                    raise ValueError("Um dos destinos é uma pasta ou atalho simbólico. Escolha outra pasta.")
                existing = [f["name"] for f in files if (root / f["name"]).exists()]
                if existing and body.get("overwrite") is not True:
                    raise ValueError("Já existem ZIPs em " + period + ": " + ", ".join(existing[:5]) +
                                     ". Desmarque esses arquivos ou autorize substituir os ZIPs existentes.")
                plan.append((root, period, files))
            plan.sort(key=lambda x: x[1])
            total = sum(f["size"] for _, _, files in plan for f in files)
            if shutil.disk_usage(parent).free < total + 128 * 1024 * 1024:
                raise ValueError("Não há espaço livre suficiente para os ZIPs selecionados e a margem de segurança.")
            self.stop.clear()
            self.task = {"status": "running", "period": plan[0][1], "directory": str(plan[0][0]),
                         "bytes_done": 0, "bytes_total": total, "completed_files": 0,
                         "total_files": sum(len(files) for _, _, files in plan), "current_file": "", "error": "",
                         "completed_periods": 0, "total_periods": len(plan),
                         "queue": [{"period": p, "directory": str(r), "status": "queued",
                                    "completed_files": 0, "total_files": len(fs)} for r, p, fs in plan],
                         "message": "Baixando competências em ordem cronológica para pastas separadas."}
            try:
                self.save()
            except OSError as error:
                self.task.update(status="failed", error=str(error), message="O download não foi iniciado.")
                raise
            self.thread = threading.Thread(target=self.run_batch, args=(plan,), daemon=True)
            self.thread.start()
            return self.status()

    def run_batch(self, plan):
        try:
            for index, (root, period, files) in enumerate(plan):
                with self.lock:
                    if self.stop.is_set():
                        self.task.update(status="paused", message="Fila interrompida. ZIPs concluídos preservados.")
                        break
                    item = self.task["queue"][index]
                    item["status"] = "running"
                    offset = self.task["bytes_done"]
                    self.task.update(period=period, directory=str(root), current_file="",
                                     message="Baixando a competência " + period + ".")
                    self.save()
                self.run(root, period, files, offset=offset, final=False)
                with self.lock:
                    if self.task["status"] in ("failed", "paused"):
                        item["status"] = self.task["status"]
                        break
                    item["status"] = "completed"
                    self.task["completed_periods"] += 1
                    self.save()
            else:
                with self.lock:
                    self.task.update(status="completed", current_file="",
                                     message="Downloads concluídos. Cada competência foi salva na sua própria pasta.")
        except Exception as error:
            with self.lock:
                self.task.update(status="failed", error=str(error),
                                 message="Fila interrompida. ZIPs e competências já concluídos foram preservados.")
        finally:
            with self.lock:
                for item in self.task["queue"]:
                    if item["status"] == "running":
                        item["status"] = self.task["status"]
                    elif item["status"] == "queued":
                        item["status"] = "paused"
                self.save()

    def run(self, root, period, files, offset=0, final=True):
        partial = None
        try:
            saved_bytes = offset
            for file in files:
                if self.stop.is_set():
                    raise DownloadStopped()
                name = file["name"]
                with self.lock:
                    self.task.update(current_file=name, message="Baixando " + name)
                partial = root / ("." + name + "." + uuid.uuid4().hex + ".cnpj-part")
                request = Request(DAV + period + "/" + quote(name), headers=HEADERS)
                with self.opener(request, timeout=30) as response, partial.open("xb") as out:
                    if response.status != 200:
                        raise ValueError("A Receita recusou o download de " + name + ".")
                    count = 0
                    while True:
                        if self.stop.is_set():
                            raise DownloadStopped()
                        chunk = response.read(1024 * 1024)
                        if not chunk:
                            break
                        count += len(chunk)
                        if file["size"] and count > file["size"]:
                            raise ValueError("O tamanho de " + name + " mudou na Receita. Atualize o catálogo.")
                        out.write(chunk)
                        with self.lock:
                            self.task["bytes_done"] = saved_bytes + count
                    if file["size"] and count != file["size"]:
                        raise ValueError("Download incompleto de " + name + ". O arquivo anterior não foi substituído.")
                    out.flush()
                    os.fsync(out.fileno())
                if self.stop.is_set():
                    raise DownloadStopped()
                with zipfile.ZipFile(partial) as archive:
                    if not archive.infolist():
                        raise ValueError("A Receita retornou um ZIP vazio: " + name)
                # Não descompacta nem altera o conteúdo; a inspeção local valida
                # novamente o conjunto antes de permitir processá-lo.
                partial.replace(root / name)
                partial = None
                saved_bytes += count
                with self.lock:
                    self.task.update(bytes_done=saved_bytes, completed_files=self.task["completed_files"] + 1)
                    for item in self.task.get("queue", []):
                        if item["period"] == period:
                            item["completed_files"] += 1
                    self.save()
            with self.lock:
                self.task.update(status="completed" if final else "running", current_file="",
                                 message="Download concluído. ZIPs salvos na pasta da competência.")
                self.save()
        except DownloadStopped:
            with self.lock:
                self.task.update(status="paused", message="Download interrompido. ZIPs concluídos preservados; o arquivo em andamento precisa ser baixado novamente.")
                self.save()
        except Exception as error:
            with self.lock:
                self.task.update(status="failed", error=str(error),
                                 message="Falha no download. ZIPs concluídos e arquivos anteriores foram preservados.")
                self.save()
        finally:
            if partial is not None:
                partial.unlink(missing_ok=True)
