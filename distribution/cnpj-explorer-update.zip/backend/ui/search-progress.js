"use strict";
(function (root) {
  // Equal, completed workflow steps, not an estimate of SQLite rows or time.
  var STEPS = ["Preparar filtros", "Consultar a base local", "Exibir resultados"];
  function create(ctx, host) {
    var current = null, timer = null;
    var now = ctx.now || Date.now, schedule = ctx.setInterval || setInterval;
    var unschedule = ctx.clearInterval || clearInterval;
    function stop() { if (timer !== null) unschedule(timer); timer = null; }
    function elapsed() {
      if (!current || !current.clock) return;
      var seconds = Math.max(0, Math.floor((now() - current.started) / 1000));
      current.clock.textContent = "Tempo decorrido: " + Math.floor(seconds / 60) + " min " + seconds % 60 + " s" +
        (current.active ? " · Aguardando a conclusão da etapa atual." : "");
    }
    function paint(message) {
      var el = ctx.el, s = current, percent = Math.round(s.done / STEPS.length * 100);
      ctx.clear(host); host.hidden = false;
      var bar = el("div", { class: "import-progress-track", role: "progressbar",
        "aria-label": "Etapas concluídas da consulta", "aria-valuemin": 0, "aria-valuemax": 100,
        "aria-valuenow": percent, "aria-valuetext": percent + "% — " + s.done + " de 3 etapas concluídas."
      }, [el("i", { "aria-hidden": "true" })]);
      bar.firstChild.style.transform = "scaleX(" + percent / 100 + ")";
      var heading = el("div", { class: "import-progress-head" }, [
        el("span", { class: "import-progress-state", role: "status" }, [
          el("span", { class: "import-progress-dot", "aria-hidden": "true" }),
          el("strong", { text: message })
        ]),
        el("strong", { class: "import-progress-percent", text: percent + "%" })
      ]);
      var steps = el("ol", { class: "search-progress-steps" });
      STEPS.forEach(function (label, index) {
        steps.appendChild(el("li", { class: index < s.done ? "step-done" : index === s.done && s.active ? "step-active" : "",
          text: (index < s.done ? "✓ " : (index + 1) + ". ") + label,
          "aria-current": index === s.done && s.active ? "step" : null }));
      });
      s.clock = el("div", { class: "meta" });
      host.appendChild(el("div", { class: "import-progress" + (s.active ? " is-running" : "") },
        [heading, bar, steps, s.clock, el("div", { class: "import-progress-note",
          text: "Percentual das 3 etapas da consulta — não representa a quantidade de empresas analisadas nem o tempo restante." })]));
      elapsed();
    }
    return {
      begin: function (id, append) {
        stop(); current = { id: id, done: 0, active: true, started: now() };
        paint(append ? "Preparando a próxima página" : "Preparando a seleção");
        timer = schedule(elapsed, 1000);
      },
      advance: function (id, done) {
        if (!current || current.id !== id || !current.active) return;
        current.done = Math.max(current.done, Math.min(2, done));
        paint(done === 1 ? "Aplicando os filtros na base local…" : "Organizando os resultados…");
      },
      finish: function (id, count, more) {
        if (!current || current.id !== id || !current.active) return;
        stop(); current.done = 3; current.active = false;
        paint(count ? "Consulta concluída — " + count + " empresas nesta página" + (more ? "; há mais páginas." : ".") :
          "Consulta concluída — nenhuma empresa encontrada.");
      },
      fail: function (id) {
        if (!current || current.id !== id) return;
        stop(); current.active = false;
        paint("Consulta não concluída — confira o erro abaixo e tente novamente.");
      },
      reset: function () { stop(); current = null; ctx.clear(host); host.hidden = true; }
    };
  }
  var api = { create: create };
  if (typeof module === "object" && module.exports) module.exports = api;
  else root.LocalSearchProgress = api;
})(typeof window === "object" ? window : {});
