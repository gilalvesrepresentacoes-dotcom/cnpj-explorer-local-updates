"use strict";
/* Nova importação — seleção de edições da Receita (anos/meses + manifesto + download em lote local). */
(function (root) {
  var MONTHS = ["janeiro", "fevereiro", "março", "abril", "maio", "junho", "julho", "agosto", "setembro", "outubro", "novembro", "dezembro"];
  var REF = ["cnaes", "motivos", "municipios", "naturezas", "paises", "qualificacoes"];
  var ORDER = ["estabelecimentos", "empresas", "socios", "simples"];
  var QSTAT = { queued: "Na fila", running: "Baixando", completed: "Salvo", paused: "Interrompido", failed: "Falhou", cancelled: "Cancelado" };
  var MAX_CONC = 3;

  var ctx = null, host = null, gen = 0, refs = {}, st = null;
  var pState = "idle", pErr = "", periods = [], year = "";
  var sel = new Set(), man = {}, picked = {}, open = {}, active = 0;
  var dlPending = false, stopPending = false, msg = "", msgOk = false;

  function E(t, a, k) { return ctx.el(t, a, k); }
  function clear(n) { while (n.firstChild) n.removeChild(n.firstChild); return n; }
  function mlabel(p) { var m = /^(\d{4})-(\d{2})$/.exec(p || ""); return m ? MONTHS[+m[2] - 1] + " de " + m[1] : p; }
  function size(n) { n = Number(n) || 0; return n ? ctx.fmtSize(n) : "tamanho desconhecido"; }
  function plural(n, a, b) { return ctx.fmtN(n) + " " + (n === 1 ? a : b); }
  function norm(s) { return String(s || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, ""); }
  function rank(g) {
    var k = norm(g);
    if (k === "tabelas auxiliares" || REF.some(function (r) { return k.indexOf(r) === 0; })) return 0;
    var i = ORDER.findIndex(function (r) { return k.indexOf(r) === 0; });
    return i < 0 ? 9 : i + 1;
  }
  function slug(s) { return norm(s).replace(/[^a-z0-9]+/g, "-"); }
  function selList() { return Array.from(sel).sort(); }
  function yearsMap() {
    var m = {}; periods.forEach(function (p) { var y = p.slice(0, 4); (m[y] = m[y] || []).push(p); });
    return Object.keys(m).sort().reverse().map(function (y) { return { y: y, ps: m[y].sort() }; });
  }
  function groupsOf(files) {
    var g = {};
    files.forEach(function (f) { var k = f.group || "Outros"; (g[k] = g[k] || []).push(f); });
    return Object.keys(g).sort(function (a, b) { return rank(a) - rank(b) || a.localeCompare(b); }).map(function (k) {
      return { name: k, files: g[k].slice().sort(function (a, b) { return (a.order || 0) - (b.order || 0) || a.name.localeCompare(b.name); }) };
    });
  }
  function sum(files) { return files.reduce(function (s, f) { return s + (Number(f.size) || 0); }, 0); }

  // ---------- init ----------
  function init(c) {
    ctx = c; host = document.getElementById("sourceWorkspace");
    if (!host) return;
    gen++; clear(host).classList.add("lc");
    if (!ctx.isAdmin()) { host.appendChild(E("div", { class: "lc-empty" }, [E("strong", { text: "Acesso restrito" }), E("span", { text: "Somente o administrador pode escolher e baixar edições da Receita." })])); return; }
    host.appendChild(hero());
    refs.periods = E("div", { class: "lc-body", "aria-live": "polite" });
    host.appendChild(step("01 — período", "Edição do cadastro", "Cada mês é um retrato completo do cadastro naquela data, não as empresas abertas no período.", refs.periods, "lcS1"));
    refs.manifest = E("div", { class: "lc-body" });
    refs.dl = buildDl();
    host.appendChild(step("02 — manifesto", "Arquivos selecionados", "Os meses são baixados em ordem cronológica, um por vez. Dentro de cada mês, os ZIPs seguem a ordem de referência; os números dos arquivos não correspondem a estados.", E("div", { class: "lc-stack" }, [refs.manifest, refs.dl]), "lcS2"));
    refs.task = E("div", { class: "lc-body", "aria-live": "polite" });
    host.appendChild(step("03 — processar", "Processar no computador", "O download só salva os ZIPs. Nada é importado até você iniciar o processamento.", refs.task, "lcS3"));
    paintPeriods(); paintManifest(); paintTask();
    loadPeriods();
  }
  function hero() {
    return E("header", { class: "lc-hero" }, [E("div", { class: "lc-rule", "aria-hidden": "true" }), E("div", { class: "lc-hero-in" }, [
      E("p", { class: "lc-kicker", text: "Cadastro Nacional da Pessoa Jurídica" }),
      E("h1", { class: "lc-h1", text: "Do arquivo nacional à planilha que você precisa." }),
      E("p", { class: "lc-lead", text: "Escolha edições oficiais da Receita Federal, salve os ZIPs no seu próprio disco e prepare a base neste computador, sem custo de nuvem. Depois defina o recorte por atividade e localidade." }),
      E("div", { class: "lc-facts" }, ["fonte oficial", "nada inicia sozinho", "todos os arquivos, em ordem", "processado no seu PC"].map(function (t) { return E("span", null, [E("i", { "aria-hidden": "true" }), t]); }))
    ])]);
  }
  function step(n, t, hint, body, id) {
    return E("section", { class: "lc-step", "aria-labelledby": id }, [
      E("div", { class: "lc-side" }, [E("p", { class: "lc-n", text: n }), E("h2", { id: id, class: "lc-h2", text: t }), E("p", { class: "lc-hint", text: hint })]), body]);
  }

  // ---------- 01 periods ----------
  function loadPeriods() {
    var g = gen; pState = "loading"; paintPeriods();
    ctx.api("/api/source/periods").then(function (r) {
      if (g !== gen) return;
      periods = ((r && r.periods) || []).filter(function (p) { return /^\d{4}-\d{2}$/.test(p); });
      pState = periods.length ? "ok" : "empty";
      var ys = yearsMap();
      if (!ys.some(function (x) { return x.y === year; })) year = ys.length ? ys[0].y : "";
      sel.forEach(function (p) { if (periods.indexOf(p) < 0) sel.delete(p); });
      paintPeriods(); paintManifest();
    }).catch(function (e) { if (g !== gen || (e && e.locked)) return; pState = "error"; pErr = (e && e.message) || "erro desconhecido"; paintPeriods(); });
  }
  function paintPeriods() {
    var b = refs.periods; if (!b) return; clear(b);
    if (pState === "loading" || pState === "idle") { b.appendChild(E("div", { class: "sk lc-sk" })); b.appendChild(E("div", { class: "sk lc-sk tall" })); return; }
    if (pState === "error") { b.appendChild(E("div", { class: "lc-err", role: "alert" }, [E("strong", { text: "Catálogo da Receita indisponível" }), E("span", { text: pErr }), E("button", { type: "button", class: "lc-btn", "data-testid": "button-retry-periods", text: "Tentar novamente", onclick: loadPeriods })])); return; }
    if (pState === "empty") { b.appendChild(E("div", { class: "lc-empty" }, [E("strong", { text: "Nenhuma edição listada" }), E("span", { text: "O catálogo remoto não listou nenhuma edição no momento." }), E("button", { type: "button", class: "lc-btn", text: "Consultar de novo", onclick: loadPeriods })])); return; }
    var ys = yearsMap(), cur = ys.filter(function (x) { return x.y === year; })[0] || { ps: [] };
    b.appendChild(E("div", { class: "lc-years", role: "group", "aria-label": "Anos" }, ys.map(function (x, i) {
      var n = x.ps.filter(function (p) { return sel.has(p); }).length;
      return E("button", { type: "button", class: "lc-chip lc-year", "data-yi": String(Math.min(i, 8)), "data-on": String(x.y === year), "aria-pressed": String(x.y === year), "data-testid": "button-year-" + x.y,
        onclick: function () { year = x.y; paintPeriods(); } }, [x.y, E("span", { class: "lc-cnt", text: String(x.ps.length) }), n ? E("span", { class: "lc-dot", "aria-label": n + " selecionados", text: String(n) }) : null]);
    })));
    var inYear = cur.ps.filter(function (p) { return sel.has(p); }).length;
    b.appendChild(E("div", { class: "lc-tools" }, [
      E("button", { type: "button", class: "lc-btn", "data-testid": "button-select-all-months", disabled: !cur.ps.length || inYear === cur.ps.length, text: "Selecionar todos de " + year,
        onclick: function () { cur.ps.forEach(function (p) { sel.add(p); }); changed(); } }),
      E("button", { type: "button", class: "lc-btn ghost", "data-testid": "button-clear-months", disabled: !sel.size, text: "Limpar seleção", onclick: function () { sel.clear(); changed(); } }),
      E("span", { role: "status", class: "lc-muted", "data-testid": "text-selected-months", text: inYear + " de " + cur.ps.length + " meses de " + year + " · " + plural(sel.size, "mês selecionado", "meses selecionados") + " no total" })
    ]));
    var grid = E("div", { class: "lc-months" });
    for (var i = 1; i <= 12; i++) (function (i) {
      var mm = (i < 10 ? "0" : "") + i, p = year + "-" + mm, av = cur.ps.indexOf(p) >= 0, on = sel.has(p);
      grid.appendChild(E("button", { type: "button", class: "lc-chip lc-month", "data-m": mm, "data-on": String(on), "aria-pressed": String(on), disabled: !av,
        "aria-label": mlabel(p) + (av ? "" : " (não publicado)"), "data-testid": "button-period-" + p,
        onclick: function () { on ? sel.delete(p) : sel.add(p); changed(); } }, [E("span", { class: "lc-mm", text: mm }), E("span", { class: "lc-mn", text: MONTHS[i - 1].slice(0, 3) })]));
    })(i);
    b.appendChild(grid);
    b.appendChild(E("p", { class: "lc-note", text: "Cada competência é uma fotografia completa do CNPJ: para usar a base atual não é preciso baixar meses anteriores. O ano não é o ano de abertura da empresa. Cada mês ocupa muitos gigabytes e pode levar horas para baixar." }));
  }
  function changed() {
    selList().forEach(function (p) { if (!man[p] || man[p].state === "error") { if (!man[p]) man[p] = { state: "pending" }; } });
    pump(); paintPeriods(); paintManifest();
  }

  // ---------- manifests ----------
  function pump() {
    var g = gen;
    selList().forEach(function (p) {
      if (active >= MAX_CONC || !man[p] || man[p].state !== "pending") return;
      active++; man[p].state = "loading";
      ctx.api("/api/source/files?period=" + encodeURIComponent(p)).then(function (r) {
        if (g !== gen) return; active--;
        var files = ((r && r.files) || []).filter(function (f) { return f && f.name; });
        man[p] = { state: "ok", files: files };
        if (!picked[p]) picked[p] = new Set(files.map(function (f) { return f.name; }));
        pump(); paintManifest();
      }).catch(function (e) {
        if (g !== gen) return; active--;
        man[p] = { state: "error", err: (e && e.message) || "erro desconhecido" };
        pump(); paintManifest();
      });
    });
  }
  function retry(p) { man[p] = { state: "pending" }; pump(); paintManifest(); }
  function pickedFiles(p) { var m = man[p]; return m && m.state === "ok" ? m.files.filter(function (f) { return picked[p] && picked[p].has(f.name); }) : []; }
  function setPick(p, names, on) { var s = picked[p] = picked[p] || new Set(); names.forEach(function (n) { on ? s.add(n) : s.delete(n); }); paintManifest(); }

  function paintManifest() {
    var b = refs.manifest; if (!b) return;
    var keepOpen = {}; b.querySelectorAll("details[data-p]").forEach(function (d) { keepOpen[d.getAttribute("data-p")] = d.open; });
    Object.keys(keepOpen).forEach(function (k) { open[k] = keepOpen[k]; });
    clear(b);
    var ps = selList();
    if (!ps.length) { b.appendChild(E("p", { class: "lc-muted", text: "Escolha um ou mais meses ou selecione todos os disponíveis." })); syncDl(); return; }
    var totF = 0, totB = 0, allF = 0;
    ps.forEach(function (p) { var pf = pickedFiles(p); totF += pf.length; totB += sum(pf); if (man[p] && man[p].files) allF += man[p].files.length; });
    var loaded = ps.filter(function (p) { return man[p] && man[p].state === "ok"; }).length;
    b.appendChild(E("div", { class: "lc-sum" }, [
      E("p", { "data-testid": "text-total-bytes" }, [plural(ps.length, "mês", "meses") + " · " + ctx.fmtN(totF) + " de " + ctx.fmtN(allF) + " ZIPs marcados · ", E("span", { class: "lc-mono", text: (totB ? ctx.fmtSize(totB) : "0 B") + " no total" }), loaded < ps.length ? " · carregando " + (ps.length - loaded) + " manifesto(s)" : ""]),
      E("span", { class: "lc-sp" }),
      E("button", { type: "button", class: "lc-btn ghost sm", "data-testid": "button-pick-all-files", text: "Marcar todos", onclick: function () { ps.forEach(function (p) { if (man[p] && man[p].files) setPick(p, man[p].files.map(function (f) { return f.name; }), true); }); } }),
      E("button", { type: "button", class: "lc-btn ghost sm", "data-testid": "button-clear-files", text: "Desmarcar todos", onclick: function () { ps.forEach(function (p) { picked[p] = new Set(); }); paintManifest(); } })
    ]));
    ps.forEach(function (p) { b.appendChild(monthBlock(p, ps.length)); });
    syncDl();
  }
  function cb(checked, mixed, label, testid, fn) {
    var c = E("input", { type: "checkbox", "aria-label": label, "data-testid": testid });
    c.checked = checked; c.indeterminate = mixed;
    c.addEventListener("change", function () { fn(c.checked); });
    return c;
  }
  function monthBlock(p, n) {
    var m = man[p] || { state: "pending" }, mm = p.slice(5);
    var d = E("details", { class: "lc-mblock", "data-p": p, "data-m": mm, "data-testid": "manifest-" + p });
    d.open = open[p] != null ? open[p] : n === 1;
    var head = E("summary", { class: "lc-mhead" }, [E("span", { class: "lc-mtitle", text: mlabel(p) }), E("span", { class: "lc-mono lc-muted", text: p })]);
    d.appendChild(head);
    if (m.state === "pending" || m.state === "loading") { head.appendChild(E("span", { class: "lc-muted", text: "carregando manifesto…" })); d.appendChild(E("div", { class: "lc-pad" }, [E("div", { class: "sk lc-sk" }), E("div", { class: "sk lc-sk" })])); return d; }
    if (m.state === "error") {
      head.appendChild(E("span", { class: "lc-errtxt", text: "manifesto indisponível" }));
      d.open = true;
      d.appendChild(E("div", { class: "lc-err", role: "alert" }, [E("span", { text: m.err }), E("button", { type: "button", class: "lc-btn sm", "data-testid": "button-retry-manifest-" + p, text: "Tentar novamente", onclick: function () { retry(p); } })]));
      return d;
    }
    var pf = pickedFiles(p), all = m.files;
    head.appendChild(E("span", { class: "lc-meta", text: ctx.fmtN(pf.length) + "/" + ctx.fmtN(all.length) + " ZIPs · " + size(sum(pf)) }));
    if (!all.length) { d.appendChild(E("p", { class: "lc-muted lc-pad", text: "Nenhum ZIP publicado nesta competência." })); return d; }
    var body = E("div", { class: "lc-pad lc-stack" });
    body.appendChild(E("div", { class: "lc-tools" }, [
      E("label", { class: "lc-check" }, [cb(pf.length === all.length, pf.length > 0 && pf.length < all.length, "Marcar todos os ZIPs de " + p, "checkbox-month-" + p, function (on) { setPick(p, all.map(function (f) { return f.name; }), on); }), "Todos os ZIPs do mês"]),
      E("span", { class: "lc-sp" }),
      E("button", { type: "button", class: "lc-btn sm", disabled: !pf.length || busy(), "data-testid": "button-download-month-" + p, text: "Baixar mês (" + pf.length + ")",
        onclick: function () { download([{ period: p, names: pf.map(function (f) { return f.name; }) }], mlabel(p)); } })
    ]));
    groupsOf(all).forEach(function (g) {
      var gp = g.files.filter(function (f) { return picked[p].has(f.name); }), gid = slug(g.name);
      var list = E("ul", { class: "lc-files" }, g.files.map(function (f) {
        var on = picked[p].has(f.name);
        return E("li", { class: "lc-file" + (on ? " on" : "") }, [
          E("label", { class: "lc-check lc-grow" }, [cb(on, false, "Selecionar " + f.name, "checkbox-file-" + p + "-" + f.name, function (v) { setPick(p, [f.name], v); }), E("span", { class: "lc-mono", text: f.name })]),
          E("span", { class: "lc-size", text: size(f.size) }),
          E("button", { type: "button", class: "lc-btn ghost xs", disabled: busy(), "data-testid": "button-download-file-" + p + "-" + f.name, "aria-label": "Baixar " + f.name, text: "Baixar",
            onclick: function () { download([{ period: p, names: [f.name] }], f.name); } })
        ]);
      }));
      body.appendChild(E("div", { class: "lc-group", "data-testid": "group-" + p + "-" + gid }, [
        E("div", { class: "lc-ghead" }, [
          E("label", { class: "lc-check" }, [cb(gp.length === g.files.length, gp.length > 0 && gp.length < g.files.length, "Selecionar grupo " + g.name, "checkbox-group-" + p + "-" + gid, function (v) { setPick(p, g.files.map(function (f) { return f.name; }), v); }), E("strong", { text: g.name })]),
          E("span", { class: "lc-muted", text: gp.length + "/" + g.files.length + " · " + size(sum(gp)) }),
          E("span", { class: "lc-sp" }),
          E("button", { type: "button", class: "lc-btn ghost xs", disabled: !gp.length || busy(), "data-testid": "button-download-group-" + p + "-" + gid, text: "Baixar grupo",
            onclick: function () { download([{ period: p, names: gp.map(function (f) { return f.name; }) }], g.name + " de " + p); } })
        ]), list]));
    });
    d.appendChild(body);
    return d;
  }

  // ---------- download ----------
  function dl() { return st && st.downloads ? st.downloads : null; }
  function busy() { var d = dl(); return dlPending || !!(d && d.running); }
  function buildDl() {
    refs.dir = E("input", { type: "text", placeholder: "E:\\Receita", autocomplete: "off", "aria-label": "Pasta de destino", "data-testid": "input-download-dir", oninput: syncDl });
    refs.pick = typeof ctx.pickFolder === "function" ? E("button", { type: "button", class: "lc-btn", "data-testid": "button-pick-folder", text: "Escolher pasta…", onclick: function () {
      var g = gen; Promise.resolve(ctx.pickFolder()).then(function (p) { if (g === gen && p) { refs.dir.value = p; syncDl(); } })
        .catch(function (e) { if (g === gen) { msg = "Seletor de pastas indisponível: " + e.message; msgOk = false; paintTask(); } });
    } }) : null;
    refs.over = E("input", { type: "checkbox", "data-testid": "checkbox-overwrite", onchange: syncDl });
    refs.go = E("button", { type: "button", class: "lc-btn primary", "data-testid": "button-download-selected", text: "Baixar selecionados", onclick: function () {
      var items = selList().map(function (p) { return { period: p, names: pickedFiles(p).map(function (f) { return f.name; }) }; }).filter(function (i) { return i.names.length; });
      download(items, "a seleção");
    } });
    refs.goInfo = E("span", { class: "lc-muted" });
    return E("div", { class: "lc-dl" }, [
      E("div", { class: "lc-row" }, [E("label", { class: "lc-field" }, [E("span", { text: "Pasta de destino no seu disco" }), refs.dir]), refs.pick]),
      E("p", { class: "lc-muted", text: "Uma subpasta por competência (ex.: E:\\Receita\\2026-01) será criada, com os ZIPs com os nomes originais. A internet é usada só para buscar os arquivos públicos; o resto acontece neste computador. O programa confere catálogo, espaço livre e arquivos existentes antes de começar." }),
      E("label", { class: "lc-check" }, [refs.over, "Substituir ZIPs que já existem nas pastas (pede confirmação)"]),
      E("div", { class: "lc-row end" }, [refs.goInfo, refs.go])
    ]);
  }
  function syncDl() {
    if (!refs.go) return;
    var n = 0, bytes = 0, ms = 0;
    selList().forEach(function (p) { var pf = pickedFiles(p); if (pf.length) ms++; n += pf.length; bytes += sum(pf); });
    var unresolved = selList().some(function (p) { return !man[p] || man[p].state !== "ok"; });
    refs.go.disabled = busy() || unresolved || !n || !refs.dir.value.trim();
    refs.go.textContent = dlPending ? "Solicitando…" : "Baixar selecionados";
    refs.goInfo.textContent = unresolved ? "Carregue todos os manifestos selecionados; se houver erro, clique em Tentar novamente." : !n ? "Nenhum ZIP marcado." : !refs.dir.value.trim() ? "Informe a pasta de destino." : busy() ? "Aguarde o download atual terminar." : plural(n, "ZIP", "ZIPs") + " em " + plural(ms, "mês", "meses") + " · " + size(bytes);
  }
  function download(items, what) {
    var dir = refs.dir.value.trim();
    items = items.filter(function (i) { return i.names.length; }).sort(function (a, b) { return a.period < b.period ? -1 : 1; });
    if (dlPending || busy()) return;
    if (!dir) { msg = "Informe a pasta de destino antes de baixar."; msgOk = false; paintTask(); refs.dir.focus(); return; }
    if (!items.length) return;
    var over = !!refs.over.checked;
    if (over && !window.confirm("Substituir ZIPs existentes com o mesmo nome nas subpastas de " + items.map(function (i) { return i.period; }).join(", ") + "?\n\nOs arquivos atuais serão sobrescritos.")) return;
    var g = gen; dlPending = true; msg = ""; syncDl(); paintTask(); paintManifest();
    ctx.api("/api/source/download-batch", { items: items, directory: dir, overwrite: over }).then(function (r) {
      if (g !== gen) return; dlPending = false;
      if (r && (r.task || "running" in r)) { if (!st) st = {}; st.downloads = r; }
      msg = "Download de " + what + " solicitado. Acompanhe abaixo."; msgOk = true;
      syncDl(); paintTask(); paintManifest();
    }).catch(function (e) { if (g !== gen) return; dlPending = false; if (!(e && e.locked)) { msg = (e && e.message) || "Falha ao solicitar o download."; msgOk = false; } syncDl(); paintTask(); paintManifest(); });
  }
  function stop() {
    var g = gen; stopPending = true; paintTask();
    ctx.api("/api/source/stop", {}).catch(function (e) { if (g !== gen) return; stopPending = false; if (!(e && e.locked)) { msg = e.message; msgOk = false; } paintTask(); });
  }

  // ---------- 03 task ----------
  function paintTask() {
    var b = refs.task; if (!b) return; clear(b);
    var d = dl(), t = d && d.task, running = !!(d && d.running);
    if (!running) stopPending = false;
    if (msg) b.appendChild(E("div", { class: msgOk ? "lc-ok" : "lc-err", role: "status", text: msg }));
    b.appendChild(E("ol", { class: "lc-howto" }, [
      E("li", { text: "Aguarde os meses aparecerem como salvos abaixo." }),
      E("li", { text: "Clique em \u201cUsar pasta no processamento\u201d no mês desejado." }),
      E("li", { text: "Na tela de processamento, inspecione os ZIPs, defina o recorte e inicie quando quiser. Nada começa sozinho." })
    ]));
    if (!t) { b.appendChild(E("p", { class: "lc-muted", "data-testid": "text-no-download", text: "Nenhum download nesta sessão do programa." })); return; }
    if (msg && !msgOk && t.status === "completed") b.appendChild(E("p", { class: "lc-muted",
      text: "A tentativa acima não iniciou um novo download. O cartão abaixo é do último download concluído; os arquivos anteriores foram preservados." }));
    var bt = Number(t.bytes_total) || 0, bd = Number(t.bytes_done) || 0, done = t.status === "completed";
    var pct = done ? 100 : bt ? Math.floor(Math.min(99.9, bd / bt * 100) * 10) / 10 : null;
    var label = running && (t.stopping || stopPending) ? "Interrompendo" : (QSTAT[t.status] || "Aguardando");
    var bar = E("div", { class: "lc-bar" + (running ? " live" : "") + (pct == null ? " ind" : ""), role: "progressbar", "aria-valuemin": "0", "aria-valuemax": "100", "aria-label": "Progresso do download" }, [E("i")]);
    if (pct != null) { bar.setAttribute("aria-valuenow", String(pct)); bar.firstChild.style.transform = "scaleX(" + pct / 100 + ")"; }
    var queue = Array.isArray(t.queue) && t.queue.length ? t.queue : (t.period ? [{ period: t.period, directory: t.directory, status: t.status, completed_files: t.completed_files, total_files: t.total_files }] : []);
    var tp = t.total_periods || queue.length, cp = t.completed_periods != null ? t.completed_periods : queue.filter(function (q) { return q.status === "completed"; }).length;
    b.appendChild(E("div", { class: "lc-card", "data-testid": "download-task" }, [
      E("div", { class: "lc-flex" }, [E("strong", { text: label + (t.period ? " · " + mlabel(t.period) : "") }), E("span", { class: "lc-pct", text: pct == null ? "—" : pct.toFixed(1).replace(".", ",") + "%" })]),
      bar,
      E("p", { class: "lc-muted", text: (bt ? ctx.fmtSize(bd) + " de " + ctx.fmtSize(bt) : ctx.fmtSize(bd) + " recebidos, total ainda desconhecido") + " · " + ctx.fmtN(t.completed_files || 0) + "/" + ctx.fmtN(t.total_files || 0) + " ZIPs salvos" + (tp ? " · " + cp + "/" + tp + " meses" : "") }),
      t.current_file ? E("p", { class: "lc-mono lc-small", text: "Arquivo atual: " + t.current_file }) : null,
      t.message ? E("p", { class: "lc-small", text: t.message }) : null,
      t.error ? E("div", { class: "lc-err", text: t.error }) : null,
      running ? E("div", { class: "lc-row" }, [E("button", { type: "button", class: "lc-btn danger sm", "data-testid": "button-stop-download", disabled: stopPending || !!t.stopping, text: stopPending || t.stopping ? "Interrompendo…" : "Interromper", onclick: stop }),
        E("span", { class: "lc-muted", text: "Interromper cancela os meses pendentes e preserva os ZIPs já salvos." })]) : null,
      !running && (t.status === "paused" || t.status === "failed" || t.status === "cancelled") ? E("p", { class: "lc-muted", text: "Não há retomada automática. Para continuar, marque só os ZIPs que faltam e baixe novamente; o arquivo interrompido recomeça do zero." }) : null,
      queue.length ? E("ul", { class: "lc-queue" }, queue.map(function (q) {
        var s = running && q.status === "running" && (t.stopping || stopPending) ? "Interrompendo" : (QSTAT[q.status] || q.status);
        return E("li", { "data-status": q.status, "data-testid": "queue-" + q.period }, [
          E("span", { class: "lc-qs", text: s }),
          E("span", { class: "lc-grow" }, [E("strong", { text: mlabel(q.period) }), q.directory ? E("span", { class: "lc-mono lc-small lc-block", text: q.directory }) : null]),
          E("span", { class: "lc-mono lc-small", text: ctx.fmtN(q.completed_files || 0) + "/" + ctx.fmtN(q.total_files || 0) }),
          q.status === "completed" && q.directory ? E("button", { type: "button", class: "lc-btn primary sm", "data-testid": "button-use-folder-" + q.period, text: "Usar pasta no processamento", onclick: function () { ctx.useFolder(q.directory, q.period); } }) : null
        ]);
      })) : null
    ]));
  }

  function render(s) {
    if (!host || !ctx) return;
    var wasBusy = busy(); st = s || null;
    if (wasBusy !== busy()) paintManifest(); else syncDl();
    paintTask();
  }
  function reset() {
    gen++; st = null; pState = "idle"; periods = []; year = ""; sel.clear(); man = {}; picked = {}; open = {}; active = 0;
    dlPending = stopPending = false; msg = "";
    if (host) clear(host);
    refs = {}; host = null;
  }
  root.LocalSourceWorkspace = { init: init, render: render, reset: reset };
})(window);
