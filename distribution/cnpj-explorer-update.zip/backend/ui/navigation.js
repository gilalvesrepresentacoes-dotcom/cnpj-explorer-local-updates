"use strict";
/* Páginas por hash. Usa a classe page-off; nunca altera o atributo hidden (reservado a applyRole). */
window.LocalNavigation = (function () {
  var PAGES = {
    "s-new-import": ["s-new-import"],
    "s-imports": ["s-imports"],
    "s-data": ["s-data", "s-source", "s-import"], "s-source": ["s-data", "s-source", "s-import"], "s-import": ["s-data", "s-source", "s-import"],
    "s-search": ["s-search"], "s-export": ["s-search"], "s-history": ["s-history"],
    "s-backups": ["s-backups"], "s-help": ["s-help"], "s-team": ["s-team"], "s-security": ["s-security"]
  };
  var ADMIN = { "s-new-import": 1, "s-data": 1, "s-source": 1, "s-backups": 1, "s-team": 1 };
  var ctx = null, bound = false, current = "";
  function $(id) { return document.getElementById(id); }
  function targetFor(h) {
    var id = (h || "").replace(/^#/, "");
    if (!PAGES[id] || !$(id)) id = ctx && ctx.isAdmin && ctx.isAdmin() ? "s-new-import" : "s-imports";
    if (ADMIN[id] && ctx && ctx.isAdmin && !ctx.isAdmin()) id = "s-imports";
    return id;
  }
  function route() {
    var id = targetFor(location.hash), show = PAGES[id];
    var main = $("main"); if (!main) return;
    Array.prototype.forEach.call(main.children, function (sec) {
      if (!sec.id) return;
      var on = show.indexOf(sec.id) >= 0;
      sec.classList.toggle("page-off", !on);
      if (on && current !== show.join()) { sec.classList.remove("page-in"); void sec.offsetWidth; sec.classList.add("page-in"); }
    });
    var navKey = id === "s-source" || id === "s-data" ? id : id;
    document.querySelectorAll(".side-nav a").forEach(function (a) {
      var on = a.getAttribute("data-nav") === navKey;
      a.classList.toggle("on", on);
      if (on) a.setAttribute("aria-current", "page"); else a.removeAttribute("aria-current");
    });
    current = show.join();
    var t = $(id);
    if (t && show[0] !== id) t.scrollIntoView({ block: "start" }); else window.scrollTo(0, 0);
    setMenu(false);
  }
  function setMenu(open) {
    var s = $("sidebar"), b = $("navToggle"); if (!s) return;
    s.classList.toggle("open", open); if (b) b.setAttribute("aria-expanded", open ? "true" : "false");
  }
  function profile() {
    var u = ctx && ctx.user ? ctx.user() : null;
    $("navUser").textContent = u ? (u.email || u.name || "Conta local") : "—";
    $("navRole").textContent = u ? (u.role === "admin" ? "Administrador" : "Usuário") : "";
  }
  function init(c) {
    ctx = c || {};
    if (!bound) {
      bound = true;
      window.addEventListener("hashchange", route);
      $("navToggle").addEventListener("click", function () { setMenu(!$("sidebar").classList.contains("open")); });
      document.querySelectorAll(".side-nav a").forEach(function (a) {
        a.addEventListener("click", function () { if (a.getAttribute("href") === location.hash) route(); });
      });
    }
    profile(); route();
  }
  function render(s) {
    if (!ctx) return;
    profile();
    var jobs = (s && s.jobs) || [];
    var done = jobs.filter(function (j) { return j.status === "completed"; });
    var run = jobs.filter(function (j) { return j.status === "running" || j.status === "queued"; }).length;
    var rows = done.reduce(function (n, j) { return n + (Number(j.rows_kept) || 0); }, 0);
    var f = ctx.fmtN || function (n) { return String(n); };
    $("navDone").textContent = done.length + "/" + jobs.length;
    $("navRun").textContent = f(run);
    $("navRows").textContent = f(rows);
    var b = $("navActive"); b.textContent = run; b.hidden = !run;
    // role may change after init (applyRole); revalidate admin-only page
    if (targetFor(location.hash) !== (location.hash || "").replace(/^#/, "") && current !== PAGES[targetFor(location.hash)].join()) route();
  }
  function reset() {
    ctx = ctx ? { fmtN: ctx.fmtN } : null; current = "";
    ["navUser", "navDone", "navRun", "navRows"].forEach(function (id) { var n = $(id); if (n) n.textContent = "—"; });
    var r = $("navRole"); if (r) r.textContent = "";
    var b = $("navActive"); if (b) b.hidden = true;
    setMenu(false);
  }
  return { init: init, render: render, reset: reset, route: route };
})();
