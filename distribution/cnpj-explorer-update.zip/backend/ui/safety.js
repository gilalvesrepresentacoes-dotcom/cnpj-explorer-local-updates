"use strict";
/* Cópia de segurança (admin), Ajuda e Senha e segurança. Sem laço de polling próprio: render(status) vem do app. */
window.LocalSafety = (function () {
  var ctx = null, gen = 0, bound = false, info = null, posting = false, lastKey = "", lastStatus = null, restored = null, loading = false;
  function $(id) { return document.getElementById(id); }
  function el(t, a, k) { return ctx && ctx.el ? ctx.el(t, a, k) : document.createElement(t); }
  function clr(n) { while (n.firstChild) n.removeChild(n.firstChild); return n; }
  function msg(text, ok) { var b = clr($("bkMsg")); if (text) b.appendChild(el("div", { class: ok ? "okbox" : "inline-err", role: ok ? "status" : "alert", text: text })); }
  function admin() { return !!(ctx && ctx.isAdmin && ctx.isAdmin()); }
  function fmtAt(s) { var d = new Date(s); return isNaN(d) ? String(s || "") : d.toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" }); }
  function size(b) { return ctx.fmtSize ? ctx.fmtSize(b) : b + " B"; }
  function busy() { return posting || !!(lastStatus && lastStatus.running); }
  function sync() {
    var dis = busy() || !admin();
    ["bkCreate", "bkRestore", "bkSaveSettings"].forEach(function (id) { $(id).disabled = dis; });
    if (!lastStatus || !lastStatus.configured) $("bkCreate").disabled = true;
  }
  function load() {
    if (!admin() || loading) return;
    var g = gen; loading = true;
    if (!info) clr($("bkHistory")).appendChild(el("div", { class: "sk" }));
    ctx.api("/api/backups").then(function (r) {
      if (g !== gen) return; loading = false;
      var first = !info; info = r || {};
      if (first || !$("bkDir").value) $("bkDir").value = info.directory || "";
      if (first) $("bkAuto").checked = !!info.automatic;
      renderHistory();
    }).catch(function (e) {
      if (g !== gen || e.locked) return; loading = false;
      var b = clr($("bkHistory"));
      b.appendChild(el("div", { class: "inline-err", role: "alert", text: "Não foi possível ler as cópias: " + e.message }));
      b.appendChild(el("button", { class: "btn sm", type: "button", text: "Tentar novamente", onclick: load }));
    });
  }
  function renderHistory() {
    var h = (info && info.history) || [], box = clr($("bkHistory")), sel = $("bkHistSel"), cur = sel.value;
    clr(sel).appendChild(el("option", { value: "", text: h.length ? "Escolha uma cópia registrada" : "Nenhuma cópia registrada" }));
    h.forEach(function (x) { sel.appendChild(el("option", { value: x.path, text: fmtAt(x.created_at) + " · " + size(x.size) })); });
    if (cur) sel.value = cur;
    if (info && info.last_error) box.appendChild(el("div", { class: "inline-err", role: "alert", text: "Última falha: " + info.last_error }));
    if (!h.length) { box.appendChild(el("div", { class: "emptybox" }, [el("strong", { text: "Nenhuma cópia ainda." }), el("span", { text: "Escolha uma pasta em outra unidade e clique em Criar cópia." })])); return; }
    var list = el("div", { class: "bk-hist" });
    h.forEach(function (x) {
      list.appendChild(el("div", null, [el("span", { class: "p", text: x.path }), el("span", { class: "muted", text: fmtAt(x.created_at) + " · " + size(x.size) + (x.source_dir ? " · de " + x.source_dir : "") }),
        el("button", { class: "btn ghost sm", type: "button", text: "Usar para restaurar", onclick: function () { $("bkPath").value = x.path; $("bkHistSel").value = x.path; $("bkRestoreDir").focus(); } })]));
    });
    box.appendChild(list);
  }
  function post(path, body, okText) {
    if (posting) return Promise.resolve();
    posting = true; sync(); msg("");
    var g = gen;
    return ctx.api(path, body).then(function () {
      if (g !== gen) return false;
      posting = false; sync(); if (okText) msg(okText, true);
      if (ctx.refresh) return ctx.refresh().then(function () { return g === gen; });
      return true;
    }).catch(function (e) { if (g !== gen) return false; posting = false; sync(); if (!e.locked) msg(e.message); return false; });
  }
  function pick(input) {
    if (!ctx.pickFolder) return;
    var g = gen;
    Promise.resolve(ctx.pickFolder()).then(function (p) { if (g === gen && p) { $(input).value = p; $(input).focus(); } }).catch(function (e) { if (g === gen) msg("Não foi possível abrir o seletor de pastas: " + e.message); });
  }
  function bind() {
    $("fBackupCreate").addEventListener("submit", function (e) {
      e.preventDefault(); var d = $("bkDir").value.trim(); if (!d) return;
      post("/api/backups/create", { directory: d }, "Cópia iniciada. Acompanhe o progresso abaixo.");
    });
    $("bkSaveSettings").addEventListener("click", function () {
      var d = $("bkDir").value.trim();
      if ($("bkAuto").checked && !d) return msg("Informe a pasta de destino para a cópia automática.");
      var automatic = $("bkAuto").checked, g = gen;
      post("/api/backups/settings", { directory: d, automatic: automatic }, "Preferências salvas.").then(function (saved) {
        if (saved && g === gen) info = info && { history: info.history, last_error: "", directory: d, automatic: automatic };
      });
    });
    $("bkHistSel").addEventListener("change", function () { if (this.value) $("bkPath").value = this.value; });
    $("fBackupRestore").addEventListener("submit", function (e) {
      e.preventDefault();
      var p = $("bkPath").value.trim(), d = $("bkRestoreDir").value.trim(); if (!p || !d) return;
      if (!window.confirm("Restaurar esta cópia em uma NOVA pasta cnpj-restaurado-… dentro de:\n" + d + "\n\nA base atual e a cópia original são preservadas; nada é sobrescrito.\nZIPs originais, planilhas exportadas, contas e senhas não são restaurados.\n\nContinuar?")) return;
      restored = null;
      post("/api/backups/restore", { path: p, directory: d, confirm: true }, "Restauração iniciada. Acompanhe o progresso abaixo.");
    });
    $("bkPick").addEventListener("click", function () { pick("bkDir"); });
    $("bkPick2").addEventListener("click", function () { pick("bkRestoreDir"); });
    $("srcCopy").addEventListener("click", function () {
      var t = $("srcUrl").textContent, b = this;
      var done = function () { b.textContent = "Copiado"; setTimeout(function () { b.textContent = "Copiar link"; }, 1800); };
      if (navigator.clipboard) navigator.clipboard.writeText(t).then(done, function () { window.prompt("Copie o link:", t); });
      else window.prompt("Copie o link:", t);
    });
  }
  var PH = { copying: "Copiando o banco", checking: "Verificando a integridade", saving: "Gravando o arquivo final" };
  function renderTask(t) {
    var box = clr($("bkTask"));
    if (!t || (t.kind !== "backup" && t.kind !== "restore")) return;
    var pr = t.progress || {}, run = t.status === "running";
    var pct = t.status === "completed" ? 100 : (pr.total ? Math.min(99.9, 100 * (pr.done || 0) / pr.total) : null);
    var showPct = pct != null && pr.phase !== "checking";
    var card = el("div", { class: "li-taskcard" }, [
      el("div", { class: "li-flex" }, [el("strong", { text: (t.kind === "backup" ? "Cópia de segurança" : "Restauração") + " · " + ({ running: "em andamento", completed: "concluída", paused: "interrompida", failed: "falhou" }[t.status] || t.status) }),
        showPct ? el("span", { class: "bk-pct", text: pct.toFixed(1).replace(".", ",") + "%" }) : null]),
      showPct ? (function () { var b = el("div", { class: "li-bar" + (run ? " live" : "") }), i = el("i"); i.style.transform = "scaleX(" + pct / 100 + ")"; b.appendChild(i); return b; })() : null,
      el("p", { class: "li-muted", text: (PH[pr.phase] || "") + (run && pr.phase === "checking" ? " — sem percentual nesta etapa." : "") + (t.message ? " " + t.message : "") })
    ]);
    if (run && admin()) card.appendChild(el("div", { class: "row" }, [el("button", { class: "btn ghost sm", type: "button", text: t.stopping ? "Interrompendo…" : t.finishing ? "Concluindo gravação…" : "Interromper", disabled: posting || t.stopping || t.finishing, onclick: function () {
      if (window.confirm("Interromper a " + (t.kind === "backup" ? "cópia" : "restauração") + "? O arquivo parcial não será publicado; a base atual não é afetada.")) post("/api/pause", {}, "Interrupção solicitada.");
    } })]));
    if (t.status === "failed") card.appendChild(el("div", { class: "inline-err", text: t.message || "Falha" }));
    if (t.status === "completed" && t.result) {
      if (t.kind === "backup") card.appendChild(el("div", { class: "li-okmsg", text: "Cópia gravada: " + t.result.path + (t.result.size ? " (" + size(t.result.size) + ")" : "") }));
      else {
        restored = t.result.directory;
        card.appendChild(el("div", { class: "li-okmsg", text: "Base restaurada em: " + restored + ". A base atual continua intacta." }));
        card.appendChild(el("div", { class: "row" }, [el("button", { class: "btn primary sm", type: "button", text: "Abrir base restaurada", disabled: busy(), onclick: openRestored })]));
      }
    }
    box.appendChild(card);
  }
  function openRestored() {
    if (!restored || !ctx.configure) return;
    if (!window.confirm("Passar a usar a base restaurada?\n" + restored + "\n\nA pasta de dados anterior é preservada e pode ser selecionada de novo em Pasta de dados.")) return;
    var g = gen;
    Promise.resolve(ctx.configure(restored)).then(function () { if (g === gen) msg("Base restaurada aberta.", true); }).catch(function (e) { if (g === gen && !e.locked) msg(e.message); });
  }
  function profile(s) {
    var u = ctx && ctx.user ? ctx.user() : null;
    $("secName").textContent = (u && u.name) || "—";
    $("secEmail").textContent = (u && u.email) || "—";
    $("secRole").textContent = u ? (u.role === "admin" ? "Administrador — acesso total" : "Usuário — consulta e exporta") : "—";
    $("secDir").textContent = s && s.configured ? s.data_dir : "Não configurada";
  }
  function init(c) {
    ctx = c || {}; gen++;
    if (!bound) { bound = true; bind(); }
    var hasPick = !!ctx.pickFolder; $("bkPick").hidden = !hasPick; $("bkPick2").hidden = !hasPick;
    profile(null); sync(); load();
  }
  function render(s) {
    if (!ctx || !ctx.api) return;
    lastStatus = s; profile(s); sync();
    if (info && typeof s.backup_error === "string" && info.last_error !== s.backup_error) {
      info.last_error = s.backup_error; renderHistory();
    }
    var t = s && s.task;
    if (t && (t.kind === "backup" || t.kind === "restore")) {
      renderTask(t);
      var key = t.kind + t.status + (t.result ? JSON.stringify(t.result) : "");
      if (key !== lastKey) { lastKey = key; if (t.status !== "running") load(); }
    } else if (!t) clr($("bkTask"));
    if (!info && admin()) load();
  }
  function reset() {
    gen++; info = null; posting = false; lastKey = ""; lastStatus = null; restored = null; loading = false;
    if (!bound) return;
    ["bkMsg", "bkTask", "bkHistory"].forEach(function (id) { clr($(id)); });
    $("fBackupCreate").reset(); $("fBackupRestore").reset();
    clr($("bkHistSel")).appendChild(new Option("Carregando…", ""));
    ["secName", "secEmail", "secRole", "secDir"].forEach(function (id) { $(id).textContent = "—"; });
    ctx = null;
  }
  return { init: init, render: render, reset: reset, reload: load };
})();
