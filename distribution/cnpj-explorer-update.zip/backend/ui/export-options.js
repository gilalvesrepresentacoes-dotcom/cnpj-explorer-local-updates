"use strict";
/* Diálogo de layout de exportação: colunas + ordenação. Não inicia exportação. */
(function () {
  var gen = 0, cur = null;

  function msg(e) { return (e && e.message) || "Falha ao comunicar com o programa local."; }

  function teardown() {
    var c = cur; cur = null; gen++;
    if (!c) return;
    c.done = true;
    try { if (c.dlg.open) c.dlg.close(); } catch (e) { /* ignore */ }
    if (c.dlg.parentNode) c.dlg.parentNode.removeChild(c.dlg);
    try { if (c.prevFocus && c.prevFocus.focus && document.contains(c.prevFocus)) c.prevFocus.focus(); } catch (e) { /* ignore */ }
  }

  function reset() { teardown(); }

  function open(ctx) {
    teardown();
    var my = ++gen;
    var el = ctx.el;
    var c = { done: false, prevFocus: document.activeElement, fields: [], chosen: {}, sort: "cnpj", sortOpts: [], busy: false, loaded: false };
    cur = c;
    function live() { return cur === c && gen === my && !c.done; }

    function finish(kind, layout) {
      if (!live()) return;
      var cb = kind === "ok" ? ctx.onConfirm : ctx.onCancel;
      teardown();
      if (typeof cb === "function") { if (kind === "ok") cb(layout); else cb(); }
    }
    function cancel() { finish("cancel"); }

    var errBox = el("div", { class: "xo-err", role: "alert", "data-testid": "exp-layout-error", hidden: true });
    var body = el("div", { class: "xo-body" });
    var foot = el("div", { class: "xo-foot" });
    var dlg = el("dialog", { class: "xo", "data-testid": "exp-layout-dialog", "aria-labelledby": "xoTitle", "aria-describedby": "xoDesc" }, [
      el("div", { class: "xo-head" }, [
        el("p", { class: "eyebrow", text: "Antes de gravar" }),
        el("h2", { id: "xoTitle", class: "xo-title", text: "Colunas e ordem do arquivo" }),
        el("p", { id: "xoDesc", class: "xo-hint", text: "Escolha as colunas e a ordenação. A exportação só começa depois de confirmar." })
      ]),
      errBox, body, foot
    ]);
    c.dlg = dlg;
    dlg.addEventListener("cancel", function (e) { e.preventDefault(); cancel(); });
    dlg.addEventListener("click", function (e) { if (e.target === dlg) cancel(); });
    dlg.addEventListener("close", function () { if (live()) cancel(); });
    document.body.appendChild(dlg);
    dlg.showModal();

    function showErr(t) { errBox.textContent = t || ""; errBox.hidden = !t; }
    function clr(n) { while (n.firstChild) n.removeChild(n.firstChild); }

    function load() {
      showErr(""); clr(body); clr(foot);
      body.appendChild(el("div", { class: "xo-sk", "aria-busy": "true", text: "Carregando colunas disponíveis..." }));
      foot.appendChild(el("button", { class: "btn ghost", type: "button", "data-testid": "exp-layout-cancel", text: "Cancelar", onclick: cancel }));
      Promise.resolve().then(function () { return ctx.api("/api/export-options"); }).then(function (r) {
        if (!live()) return;
        apply(r); render();
      }).catch(function (e) {
        if (!live()) return;
        clr(body); clr(foot);
        showErr("Não foi possível carregar as opções de exportação. " + msg(e));
        var retry = el("button", { class: "btn primary", type: "button", text: "Tentar novamente", onclick: load });
        foot.appendChild(el("button", { class: "btn ghost", type: "button", "data-testid": "exp-layout-cancel", text: "Cancelar", onclick: cancel }));
        foot.appendChild(retry); retry.focus();
      });
    }

    function apply(r) {
      r = r || {};
      c.fields = Array.isArray(r.fields) ? r.fields.map(String) : [];
      c.chosen = {};
      (Array.isArray(r.columns) ? r.columns : []).forEach(function (k) { if (c.fields.indexOf(String(k)) >= 0) c.chosen[String(k)] = true; });
      c.sortOpts = Array.isArray(r.sort_options) && r.sort_options.length ? r.sort_options
        : [{ value: "cnpj", label: "CNPJ" }, { value: "city_neighborhood", label: "Cidade, bairro e razão social" }];
      c.sort = r.sort || c.sortOpts[0].value;
      c.saved = !!r.saved;
    }
    function columns() { return c.fields.filter(function (f) { return c.chosen[f]; }); }

    var refs = {};
    function render() {
      clr(body); clr(foot); showErr("");
      refs.boxes = [];
      var list = el("div", { class: "xo-list", role: "group", "aria-label": "Colunas" },
        c.fields.map(function (f, i) {
          var cb = el("input", { type: "checkbox", "data-testid": "exp-layout-column-" + i, checked: !!c.chosen[f],
            onchange: function () { c.chosen[f] = cb.checked; update(); } });
          refs.boxes.push(cb);
          return el("label", { class: "xo-col" }, [el("span", { text: f }), cb]);
        }));
      refs.count = el("span", { class: "xo-count", "data-testid": "exp-layout-count", "aria-live": "polite" });
      var sel = el("select", { "data-testid": "exp-layout-sort", id: "xoSort", onchange: function () { c.sort = sel.value; update(); } },
        c.sortOpts.map(function (o) { return el("option", { value: o.value, selected: o.value === c.sort, text: o.label || o.value }); }));
      refs.sel = sel;
      refs.summary = el("div", { class: "xo-summary", "data-testid": "exp-layout-summary", "aria-live": "polite" });
      refs.remember = el("input", { type: "checkbox", "data-testid": "exp-layout-remember", checked: true });
      body.appendChild(el("div", { class: "xo-tools" }, [
        el("button", { class: "btn", type: "button", "data-testid": "exp-layout-all", text: "Selecionar todas",
          onclick: function () { setAll(true); } }),
        el("button", { class: "btn ghost", type: "button", "data-testid": "exp-layout-clear", text: "Limpar",
          onclick: function () { setAll(false); } }),
        refs.count
      ]));
      body.appendChild(list);
      body.appendChild(el("p", { class: "xo-hint", text: "Para a cidade por extenso, marque MUNICÍPIO NOME; MUNICÍPIO é o código da Receita. A ordenação funciona mesmo sem exportar cidade e bairro. Os sócios ficam na coluna SÓCIOS (JSON)." }));
      body.appendChild(el("label", { class: "xo-sort", for: "xoSort" }, ["Ordenar por", sel]));
      body.appendChild(refs.summary);
      body.appendChild(el("label", { class: "check xo-remember" }, [refs.remember, " Lembrar este layout para as próximas exportações"]));
      refs.cancel = el("button", { class: "btn ghost", type: "button", "data-testid": "exp-layout-cancel", text: "Cancelar", onclick: cancel });
      refs.ok = el("button", { class: "btn primary", type: "button", "data-testid": "exp-layout-confirm", text: "Continuar", onclick: confirm });
      foot.appendChild(refs.cancel); foot.appendChild(refs.ok);
      c.loaded = true;
      update();
      (refs.boxes[0] || refs.ok).focus();
    }
    function setAll(v) {
      c.fields.forEach(function (f) { c.chosen[f] = v; });
      refs.boxes.forEach(function (b) { b.checked = v; });
      update();
    }
    function sortLabel() {
      for (var i = 0; i < c.sortOpts.length; i++) if (c.sortOpts[i].value === c.sort) return c.sortOpts[i].label || c.sort;
      return c.sort;
    }
    function update() {
      var cols = columns();
      refs.count.textContent = cols.length + " de " + c.fields.length + " colunas";
      refs.count.classList.toggle("xo-none", !cols.length);
      var s = refs.summary; clr(s);
      if (!cols.length) s.appendChild(el("p", { class: "xo-warn", text: "Nenhuma coluna selecionada. Escolha ao menos uma para continuar." }));
      else {
        s.appendChild(el("p", { class: "xo-sum-t", text: "Ordem: " + sortLabel() }));
        s.appendChild(el("ol", { class: "xo-prev" }, cols.map(function (f) { return el("li", { text: f }); })));
      }
      refs.ok.disabled = c.busy || !cols.length;
    }
    function lock(v) {
      c.busy = v;
      refs.boxes.concat([refs.sel, refs.remember]).forEach(function (n) { n.disabled = v; });
      body.querySelectorAll(".xo-tools button").forEach(function (b) { b.disabled = v; });
      refs.ok.textContent = v ? "Salvando..." : "Continuar";
      update();
    }
    function valid() { return typeof ctx.isValid !== "function" || ctx.isValid() !== false; }
    function confirm() {
      if (!live() || c.busy || !c.loaded) return;
      var cols = columns();
      if (!cols.length) return;
      if (!valid()) { showErr("A consulta ou seleção mudou. Feche e verifique a exportação novamente."); return; }
      var layout = { columns: cols.slice(), sort: c.sort };
      if (!refs.remember.checked) return finish("ok", layout);
      showErr(""); lock(true);
      Promise.resolve().then(function () { return ctx.api("/api/export-options/save", { columns: cols.slice(), sort: c.sort }); }).then(function (r) {
        if (!live()) return;
        lock(false);
        if (!valid()) { showErr("A consulta ou seleção mudou. Feche e verifique a exportação novamente."); return; }
        var outCols = r && Array.isArray(r.columns) && r.columns.length ? r.columns.map(String) : layout.columns;
        finish("ok", { columns: outCols.slice(), sort: (r && r.sort) || layout.sort });
      }).catch(function (e) {
        if (!live()) return;
        lock(false);
        showErr("Não foi possível salvar o layout. Nada foi exportado. " + msg(e) + " Tente de novo ou desmarque \"Lembrar\".");
        refs.ok.focus();
      });
    }

    load();
  }

  window.LocalExportOptions = { open: open, reset: reset };
})();
