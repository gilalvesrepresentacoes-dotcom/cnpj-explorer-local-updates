(function (root) {
  "use strict";
  function describe(task) {
    var p = task.progress || {}, done = Math.max(0, Number(p.done) || 0), total = Math.max(0, Number(p.total) || 0);
    var completed = task.status === "completed";
    var percent = completed ? 100 : Math.floor(Math.min(99.9, total ? done / total * 100 : 0) * 10) / 10;
    return { done: done, total: total, percent: percent,
      label: percent.toFixed(1).replace(".", ",") + "%",
      state: completed ? "Planilha pronta" : task.status === "failed" ? "Exportação interrompida" :
        task.status === "paused" ? "Exportação interrompida — inicie novamente" :
        task.stopping ? "Interrompendo a exportação…" :
        p.phase === "finalizing" ? "Finalizando e salvando a planilha…" : "Gravando empresas na planilha…" };
  }
  function render(el, fmtN, task) {
    var n = describe(task);
    var track = el("div", { class: "import-progress-track", role: "progressbar",
      "aria-label": "Progresso da exportação", "aria-valuemin": "0", "aria-valuemax": "100",
      "aria-valuenow": String(n.percent), "aria-valuetext": n.label + " — " + n.state
    }, [el("i", { "aria-hidden": "true" })]);
    track.firstChild.style.transform = "scaleX(" + n.percent / 100 + ")";
    return el("div", { class: "import-progress export-progress", "aria-busy": String(task.status === "running") }, [
      el("div", { class: "import-progress-head" }, [
        el("strong", { text: n.state }), el("strong", { text: n.label })]),
      track,
      el("p", { class: "export-connection-note inline-err", hidden: true }),
      el("p", { class: "hint", text: fmtN(n.done) + " de " + fmtN(n.total) + " empresas gravadas. " +
        (task.status === "completed" ? "Arquivo salvo." : task.status === "paused" ?
          "Arquivo parcial removido. Solicite uma nova exportação." : task.stopping ?
          "Aguarde o encerramento e a remoção do arquivo parcial; não instale a atualização ainda." :
          "100% somente após salvar e registrar a planilha.") }),
      task.status === "failed" ? el("p", { class: "inline-err", text: task.message || "Não foi possível concluir." }) : null
    ]);
  }
  function offline(parent) {
    if (!parent) return;
    var note = parent.querySelector(".export-connection-note");
    if (note) {
      note.hidden = false;
      note.textContent = "Sem conexão com o programa. O percentual acima é a última leitura recebida, não confirma que a exportação continua. Aguarde reconectar antes de repetir.";
    }
    var box = parent.querySelector(".export-progress");
    if (box) box.setAttribute("aria-busy", "false");
  }
  var api = { describe: describe, render: render, offline: offline };
  if (typeof module === "object" && module.exports) module.exports = api;
  else root.LocalExportProgress = api;
})(typeof window === "object" ? window : {});
