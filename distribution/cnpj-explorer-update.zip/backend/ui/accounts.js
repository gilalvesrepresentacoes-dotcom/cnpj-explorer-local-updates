"use strict";
/* Painel de equipe e e-mail (somente administrador). O backend aplica as permissões; esta tela apenas organiza. */
window.LocalAccounts = function (ctx) {
  var api = ctx.api, el = ctx.el, clear = ctx.clear, $ = function (id) { return document.getElementById(id); };
  var users = [], loadGen = 0, editing = null;
  var ACTION_PT = { setup: "Criou o primeiro administrador", login: "Entrou", logout: "Saiu", migrate: "Migrou conta antiga", change: "Trocou a senha", recover: "Recuperação de emergência", create: "Criou conta", update: "Editou conta", block: "Bloqueou conta", activate: "Reativou conta", reset: "Gerou senha temporária", request_reset: "Pediu link por e-mail", reset_password: "Redefiniu senha por e-mail", mail_save: "Salvou configuração de e-mail", mail_test: "Testou envio de e-mail" };

  function errText(e) { return e.status === 403 ? "Sem permissão para esta ação (" + e.message + ")." : e.message; }
  function note(box, msg, ok) { clear(box).appendChild(el("div", { class: ok ? "okbox" : "inline-err", role: ok ? "status" : "alert", text: msg })); }
  function fmtAt(s) { if (!s) return ""; var d = new Date(s); return isNaN(d) ? String(s) : d.toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" }); }
  function busy(btn, on) { if (btn) btn.disabled = on; }

  // ---------- segredo temporário (exibido uma vez) ----------
  function showSecret(user, pw) {
    var box = clear($("tmpSecret"));
    var ack = el("input", { type: "checkbox", id: "tmpAck" });
    var done = el("button", { class: "btn primary sm", type: "button", disabled: true, text: "Já repassei, ocultar" });
    var copy = el("button", { class: "btn sm", type: "button", text: "Copiar" });
    var code = el("code", { text: pw });
    copy.addEventListener("click", function () { ctx.copyText(code.textContent, copy); });
    ack.addEventListener("change", function () { done.disabled = !ack.checked; });
    done.addEventListener("click", function () { clear(box); box.hidden = true; });
    box.hidden = false;
    box.appendChild(el("div", { class: "secret" }, [
      el("p", { class: "secret-t" }, [el("strong", { text: "Senha temporária de " + (user.name || user.email) }), " · " + user.email]),
      el("p", { class: "hint", text: "Aparece somente agora. Repasse por um canal seguro (pessoalmente ou telefone). A pessoa precisará trocá-la no próximo acesso." }),
      el("div", { class: "codebox" }, [code, copy]),
      el("label", { class: "check" }, [ack, " Repassei a senha com segurança"]),
      el("div", { class: "row end" }, [done])
    ]));
    box.scrollIntoView({ block: "nearest" });
    done.focus();
  }

  // ---------- roster ----------
  function load() {
    var g = ++loadGen, box = clear($("roster"));
    box.appendChild(el("div", { class: "sk" })); box.appendChild(el("div", { class: "sk" }));
    api("/api/admin/users").then(function (r) {
      if (g !== loadGen) return;
      users = r.items || []; renderRoster(); renderEvents(r.events || []);
    }).catch(function (e) {
      if (e.locked || g !== loadGen) return;
      clear(box); note(box, "Não foi possível carregar a equipe: " + errText(e));
      box.appendChild(el("button", { class: "btn sm", type: "button", text: "Tentar novamente", onclick: load }));
    });
    loadMail();
  }
  function renderRoster() {
    var box = clear($("roster")), me = ctx.getMe() || {};
    var admins = users.filter(function (u) { return u.role === "admin" && u.active; }).length;
    $("teamCount").textContent = users.length + (users.length === 1 ? " conta" : " contas") + " · " + admins + " admin ativo" + (admins === 1 ? "" : "s");
    if (!users.length) return box.appendChild(el("div", { class: "emptybox" }, [el("strong", { text: "Nenhuma conta listada." }), el("span", { text: "Crie contas para quem vai consultar e exportar." })]));
    var tb = el("tbody");
    users.forEach(function (u) {
      var self = u.id === me.id;
      var st = !u.active ? el("span", { class: "pill failed", text: "bloqueada" }) : u.must_change_password ? el("span", { class: "pill paused", text: "senha temporária" }) : el("span", { class: "pill completed", text: "ativa" });
      var acts = el("div", { class: "jact" }, [
        el("button", { class: "btn ghost sm", type: "button", text: "Editar", "aria-label": "Editar " + u.email, onclick: function () { openEdit(u); } }),
        el("button", { class: "btn sm" + (u.active ? "" : " primary"), type: "button", text: u.active ? "Bloquear" : "Reativar", disabled: self, title: self ? "Você não pode bloquear a própria conta" : null, "aria-label": (u.active ? "Bloquear " : "Reativar ") + u.email, onclick: function (ev) { toggle(u, ev.currentTarget); } }),
        el("button", { class: "btn sm", type: "button", text: "Senha temporária", disabled: self, title: self ? "Para a sua conta, use Trocar senha" : null, "aria-label": "Gerar senha temporária para " + u.email, onclick: function (ev) { resetUser(u, ev.currentTarget); } })
      ]);
      tb.appendChild(el("tr", { class: u.active ? null : "off" }, [
        el("td", null, [el("div", { class: "uname" }, [u.name || "(sem nome)", self ? el("span", { class: "tag", text: "você" }) : null]), el("div", { class: "sub mono", text: u.email })]),
        el("td", null, [el("span", { class: "role " + u.role, text: u.role === "admin" ? "Administrador" : "Usuário" })]),
        el("td", null, [st]),
        el("td", { class: "sub", text: fmtAt(u.last_login_at || u.last_login) || "—" }),
        el("td", null, [acts])
      ]));
    });
    box.appendChild(el("div", { class: "tablewrap" }, [el("table", { class: "roster" }, [
      el("thead", null, [el("tr", null, [el("th", { text: "Pessoa" }), el("th", { text: "Perfil" }), el("th", { text: "Situação" }), el("th", { text: "Último acesso" }), el("th", null, [el("span", { class: "sr", text: "Ações" })])])]), tb])]));
  }
  function renderEvents(ev) {
    var box = clear($("events"));
    if (!ev.length) return box.appendChild(el("p", { class: "muted", text: "Sem registros ainda." }));
    var list = el("ol", { class: "events" });
    ev.slice(0, 60).forEach(function (x) {
      list.appendChild(el("li", null, [el("time", { text: fmtAt(x.at) }), el("span", null, [el("strong", { text: ACTION_PT[x.action] || x.action }), x.target ? " · " + x.target : ""]), el("span", { class: "sub", text: x.actor ? "por " + x.actor : "" })]));
    });
    box.appendChild(list);
  }
  function toggle(u, btn) {
    var to = !u.active;
    if (!window.confirm(to ? "Reativar " + u.email + "?" : "Bloquear " + u.email + "? As sessões abertas dessa pessoa serão encerradas.")) return;
    busy(btn, true);
    api("/api/admin/users/update", { id: u.id, email: u.email, name: u.name, role: u.role, active: to }).then(function () {
      note($("teamMsg"), (to ? "Conta reativada: " : "Conta bloqueada: ") + u.email, true); load();
    }).catch(function (e) { busy(btn, false); if (!e.locked) note($("teamMsg"), errText(e)); });
  }
  function resetUser(u, btn) {
    if (!window.confirm("Gerar nova senha temporária para " + u.email + "? A senha atual dessa pessoa deixa de valer. Nenhuma base é apagada.")) return;
    busy(btn, true);
    api("/api/admin/users/reset", { id: u.id }).then(function (r) {
      clear($("teamMsg")); showSecret(r.user || u, r.temporary_password); load();
    }).catch(function (e) { busy(btn, false); if (!e.locked) note($("teamMsg"), errText(e)); });
  }

  $("fNewUser").addEventListener("submit", function (e) {
    e.preventDefault();
    var f = e.currentTarget, btn = f.querySelector("button[type=submit]"), msg = $("newUserMsg");
    clear(msg); busy(btn, true);
    api("/api/admin/users/create", { name: $("nuName").value.trim(), email: $("nuEmail").value.trim(), role: $("nuRole").value }).then(function (r) {
      busy(btn, false); f.reset(); showSecret(r.user, r.temporary_password); load();
    }).catch(function (er) { busy(btn, false); if (!er.locked) note(msg, errText(er)); });
  });

  function openEdit(u) {
    editing = u; clear($("editMsg"));
    $("edName").value = u.name || ""; $("edEmail").value = u.email || ""; $("edRole").value = u.role; $("edActive").checked = !!u.active;
    var self = u.id === (ctx.getMe() || {}).id;
    $("edActive").disabled = self;
    $("edSelfNote").hidden = !self;
    $("editDlg").showModal(); $("edName").focus();
  }
  $("editClose").addEventListener("click", function () { $("editDlg").close(); editing = null; });
  $("fEdit").addEventListener("submit", function (e) {
    e.preventDefault(); if (!editing) return;
    var btn = e.currentTarget.querySelector("button[type=submit]"), u = editing;
    busy(btn, true);
    api("/api/admin/users/update", { id: u.id, name: $("edName").value.trim(), email: $("edEmail").value.trim(), role: $("edRole").value, active: $("edActive").checked }).then(function (r) {
      busy(btn, false); $("editDlg").close(); editing = null;
      note($("teamMsg"), "Conta atualizada: " + ((r.user && r.user.email) || u.email) + (u.role !== $("edRole").value ? ". Sessões dessa pessoa foram encerradas." : ""), true);
      load(); if (u.id === (ctx.getMe() || {}).id) ctx.refreshMe();
    }).catch(function (er) { busy(btn, false); if (!er.locked) note($("editMsg"), errText(er)); });
  });

  // ---------- e-mail ----------
  var mailGen = 0;
  function loadMail() {
    var g = ++mailGen, st = clear($("mailState"));
    st.appendChild(el("div", { class: "sk" }));
    api("/api/admin/mail").then(function (m) {
      if (g !== mailGen) return;
      $("mHost").value = m.host || ""; $("mPort").value = m.port || ""; $("mSec").value = m.security || "starttls";
      $("mUser").value = m.username || ""; $("mFrom").value = m.from_email || ""; $("mName").value = m.sender_name || "";
      $("mEnabled").checked = !!m.enabled; $("mPass").value = "";
      $("mPass").placeholder = m.password_set ? "Senha guardada. Deixe vazio para manter" : "Senha de aplicativo";
      renderMailState(m);
    }).catch(function (e) { if (e.locked || g !== mailGen) return; clear(st); note(st, "Não foi possível ler a configuração de e-mail: " + errText(e)); });
  }
  function renderMailState(m) {
    var st = clear($("mailState"));
    var chips = el("div", { class: "statechips" }, [
      el("span", { class: "pill " + (m.enabled ? "completed" : ""), text: m.enabled ? "envio ligado" : "envio desligado" }),
      el("span", { class: "pill " + (m.verified ? "completed" : "paused"), text: m.verified ? "teste aceito" : "sem teste aceito" }),
      el("span", { class: "pill " + (m.password_set ? "completed" : ""), text: m.password_set ? "senha guardada" : "sem senha" })
    ]);
    st.appendChild(chips);
    if (m.supported === false) st.appendChild(el("div", { class: "inline-err", text: "A proteção de credenciais por DPAPI exige Windows. Não é possível guardar a senha SMTP neste sistema; use o administrador ou o código de emergência." }));
    st.appendChild(el("p", { class: "hint", text: m.enabled && m.verified ? "Recuperação por e-mail disponível na tela de acesso." : "A recuperação por e-mail só aparece depois de salvar e receber um teste aceito." }));
    if (m.last_result) st.appendChild(el("p", { class: "muted", text: "Último resultado: " + (typeof m.last_result === "string" ? m.last_result : JSON.stringify(m.last_result)) }));
    $("mailSave").disabled = m.supported === false && !m.password_set;
    $("mailTest").disabled = !m.password_set || m.supported === false;
  }
  $("presetGmail").addEventListener("click", function () { $("mHost").value = "smtp.gmail.com"; $("mPort").value = "587"; $("mSec").value = "starttls"; $("mHost").focus(); });
  $("fMail").addEventListener("submit", function (e) {
    e.preventDefault();
    var btn = $("mailSave"), msg = $("mailMsg"), port = Number($("mPort").value);
    if (!port || port < 1 || port > 65535) return note(msg, "Informe uma porta entre 1 e 65535.");
    var body = { host: $("mHost").value.trim(), port: port, security: $("mSec").value, username: $("mUser").value.trim(), from_email: $("mFrom").value.trim(), sender_name: $("mName").value.trim(), enabled: $("mEnabled").checked };
    if ($("mPass").value) body.password = $("mPass").value;
    busy(btn, true); clear(msg);
    api("/api/admin/mail/save", body).then(function () {
      busy(btn, false); $("mPass").value = ""; note(msg, "Configuração salva. Envie um teste para liberar a recuperação por e-mail.", true); loadMail();
    }).catch(function (er) { busy(btn, false); $("mPass").value = ""; if (!er.locked) note(msg, errText(er)); });
  });
  $("mailTest").addEventListener("click", function () {
    var btn = $("mailTest"), msg = $("mailMsg"), me = ctx.getMe() || {};
    busy(btn, true); note(msg, "Enviando teste para " + me.email + "…", true);
    api("/api/admin/mail/test", {}).then(function (r) {
      busy(btn, false); note(msg, (r && r.message) || "Servidor aceitou a mensagem. Confira a caixa de entrada de " + me.email + ".", true); loadMail();
    }).catch(function (er) { busy(btn, false); if (!er.locked) { note(msg, "Teste recusado: " + errText(er)); loadMail(); } });
  });

  function reset() {
    loadGen++; mailGen++; users = []; editing = null;
    if ($("editDlg").open) $("editDlg").close();
    ["roster", "events", "tmpSecret", "teamMsg", "newUserMsg", "mailState", "mailMsg", "editMsg"].forEach(function (id) { clear($(id)); });
    $("tmpSecret").hidden = true; $("teamCount").textContent = "";
    $("fNewUser").reset(); $("fMail").reset(); $("fEdit").reset();
  }
  return { load: load, reset: reset };
};
