"use strict";
(function (root) {
  var ctx = null, host = null, gen = 0, st = null, selectedId = "", resuming = new Set();
  var refs = {}, files = [], picked = new Set(), period = "", filesErr = "", periodsState = "idle", filesState = "idle";
  var dlPending = false, stopPending = false, dlMsg = "";
  var STATUS_PT = { completed: "Concluída", running: "Em processamento", queued: "Na fila", paused: "Pausada", failed: "Falhou", cancelled: "Cancelada" };
  var MONTHS = ["janeiro", "fevereiro", "março", "abril", "maio", "junho", "julho", "agosto", "setembro", "outubro", "novembro", "dezembro"];

  function E(t, a, k) { return ctx.el(t, a, k); }
  function clear(n) { while (n.firstChild) n.removeChild(n.firstChild); return n; }
  function periodLabel(p) { var m = /^(\d{4})-(\d{2})$/.exec(p || ""); return m ? MONTHS[+m[2] - 1] + " de " + m[1] : (p || "Sem competência"); }
  function fmtDate(v) {
    if (v == null || v === "") return "";
    var d = typeof v === "number" ? new Date(v < 1e12 ? v * 1000 : v) : new Date(v);
    return isNaN(d) ? String(v) : d.toLocaleString("pt-BR", { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit" });
  }
  function badge(s) { return E("span", { class: "li-badge s-" + s }, [E("i", { "aria-hidden": "true" }), STATUS_PT[s] || s]); }
  function chips(j) {
    var c = [];
    if (j.scope === "state") c.push("UF " + (j.state || "?") + " inteira");
    else {
      if (j.state) c.push("UF " + j.state);
      (j.cities || []).slice(0, 4).forEach(function (x) { c.push("Município " + x); });
      if ((j.cities || []).length > 4) c.push("+" + (j.cities.length - 4) + " municípios");
      (j.cnaes || []).slice(0, 4).forEach(function (x) { c.push("CNAE " + x); });
      if ((j.cnaes || []).length > 4) c.push("+" + (j.cnaes.length - 4) + " CNAEs");
      if (j.active_only) c.push("Somente ativas");
    }
    return c;
  }
  function progress(j, compact) {
    var P = root.LocalImportProgress;
    if (P && typeof P.render === "function") return P.render({ el: ctx.el, fmtSize: ctx.fmtSize }, j, st && st.task, st && st.running, compact);
    return E("p", { class: "inline-err", text: "O indicador de progresso não carregou. Os controles continuam disponíveis." });
  }

  function init(c) {
    ctx = c; host = document.getElementById("importsWorkspace");
    if (!host) return;
    gen++;
    clear(host).classList.add("li");
    var newBtn = E("button", { type: "button", class: "li-btn primary", text: "+ Nova importação", onclick: function () { ctx.newImport && ctx.newImport(); } });
    refs.newBtn = newBtn;
    refs.list = E("ul", { class: "li-list", "aria-label": "Importações" });
    refs.detail = E("div", { class: "li-detail", "aria-live": "polite" });
    refs.body = E("div", { class: "li-grid" }, [refs.list, refs.detail]);
    refs.empty = E("div", { class: "li-empty", hidden: true });
    host.appendChild(E("header", { class: "li-head" }, [
      E("div", null, [E("p", { class: "li-eyebrow", text: "Histórico" }), E("h2", { class: "li-title", text: "Importações" }),
        E("p", { class: "li-lead", text: "Acompanhe o progresso real de cada arquivo, confira o ponto salvo e pause, retome ou cancele quando necessário." })]),
      newBtn]));
    refs.loading = E("div", { class: "li-grid" }, [E("div", { class: "li-skcol" }, [E("div", { class: "sk li-sk" }), E("div", { class: "sk li-sk" }), E("div", { class: "sk li-sk" })]), E("div", { class: "sk li-sk big" })]);
    host.appendChild(refs.loading); host.appendChild(refs.empty); host.appendChild(refs.body); refs.body.hidden = true;
    if (ctx.isAdmin()) { host.appendChild(buildDownload()); loadPeriods(); }
  }

  // ---------- download area (built once) ----------
  function buildDownload() {
    refs.periodSel = E("select", { "aria-label": "Competência na Receita", onchange: function () { period = refs.periodSel.value; picked.clear(); loadFiles(); } });
    refs.reloadP = E("button", { type: "button", class: "li-btn ghost sm", text: "Atualizar lista", onclick: loadPeriods });
    refs.fileBox = E("div", { class: "li-files" });
    refs.selCount = E("span", { class: "li-mono" });
    refs.dir = E("input", { placeholder: "E:\\Receita", autocomplete: "off", "aria-label": "Pasta de destino", oninput: syncDl });
    refs.pick = E("button", { type: "button", class: "li-btn", text: "Escolher pasta…", onclick: function () {
      var g = gen; Promise.resolve(ctx.pickFolder()).then(function (p) { if (g === gen && p) { refs.dir.value = p; syncDl(); } }).catch(function (e) { dlMsg = "Seletor de pastas indisponível: " + e.message; paintTask(); });
    } });
    refs.over = E("input", { type: "checkbox", onchange: syncDl });
    refs.go = E("button", { type: "button", class: "li-btn primary", text: "Baixar selecionados", onclick: startDl });
    refs.task = E("div", { class: "li-task", "aria-live": "polite" });
    return E("section", { class: "li-dl", "aria-labelledby": "liDlT" }, [
      E("p", { class: "li-eyebrow", text: "Receita Federal" }),
      E("h3", { id: "liDlT", class: "li-h3", text: "Baixar ZIPs da Receita" }),
      E("p", { class: "li-lead", text: "O download usa a internet só para buscar os arquivos públicos. O processamento depois é feito neste computador, sem upload." }),
      E("div", { class: "li-row" }, [E("label", { class: "li-grow" }, ["Competência", refs.periodSel]), refs.reloadP]),
      E("div", { class: "li-row li-tools" }, [refs.selCount, E("span", { class: "li-sp" }),
        E("button", { type: "button", class: "li-btn ghost sm", text: "Marcar todos", onclick: function () { files.forEach(function (f) { picked.add(f.name); }); paintFiles(); } }),
        E("button", { type: "button", class: "li-btn ghost sm", text: "Limpar", onclick: function () { picked.clear(); paintFiles(); } })]),
      refs.fileBox,
      E("div", { class: "li-row" }, [E("label", { class: "li-grow" }, ["Pasta de destino (a subpasta da competência será criada)", refs.dir]), refs.pick]),
      E("label", { class: "li-check" }, [refs.over, " Permitir substituir ZIPs existentes desta competência"]),
      E("div", { class: "li-row end" }, [refs.go]),
      refs.task
    ]);
  }
  function loadPeriods() {
    var g = gen; periodsState = "loading"; paintFiles();
    ctx.api("/api/source/periods").then(function (r) {
      if (g !== gen) return;
      var ps = (r && r.periods) || []; periodsState = ps.length ? "ok" : "empty";
      clear(refs.periodSel).appendChild(E("option", { value: "", text: ps.length ? "Escolha a competência" : "Nenhuma competência publicada" }));
      ps.slice().sort().reverse().forEach(function (p) { refs.periodSel.appendChild(E("option", { value: p, text: p + " · " + periodLabel(p) })); });
      if (period && ps.indexOf(period) >= 0) refs.periodSel.value = period; else { period = ""; files = []; }
      paintFiles();
    }).catch(function (e) { if (g !== gen || e.locked) return; periodsState = "error"; filesErr = e.message; paintFiles(); });
  }
  function loadFiles() {
    var g = gen, p = period; files = []; filesErr = "";
    if (!p) { filesState = "idle"; paintFiles(); return; }
    filesState = "loading"; paintFiles();
    ctx.api("/api/source/files?period=" + encodeURIComponent(p)).then(function (r) {
      if (g !== gen || p !== period) return;
      files = ((r && r.files) || []).slice().sort(function (a, b) { return (a.order || 0) - (b.order || 0) || a.name.localeCompare(b.name); });
      filesState = files.length ? "ok" : "empty"; paintFiles();
    }).catch(function (e) { if (g !== gen || p !== period || e.locked) return; filesState = "error"; filesErr = e.message; paintFiles(); });
  }
  function paintFiles() {
    if (!refs.fileBox) return;
    var box = clear(refs.fileBox);
    if (periodsState === "loading") box.appendChild(E("div", { class: "sk" }));
    else if (periodsState === "error") box.appendChild(E("div", { class: "inline-err", role: "alert" }, ["Não foi possível listar as competências: " + filesErr + " ", E("button", { type: "button", class: "li-btn sm", text: "Tentar novamente", onclick: loadPeriods })]));
    else if (filesState === "idle") box.appendChild(E("p", { class: "li-muted", text: "Escolha uma competência para ver os ZIPs publicados." }));
    else if (filesState === "loading") { box.appendChild(E("div", { class: "sk" })); box.appendChild(E("div", { class: "sk" })); }
    else if (filesState === "error") box.appendChild(E("div", { class: "inline-err", role: "alert" }, ["Não foi possível listar os arquivos: " + filesErr + " ", E("button", { type: "button", class: "li-btn sm", text: "Tentar novamente", onclick: loadFiles })]));
    else if (filesState === "empty") box.appendChild(E("p", { class: "li-muted", text: "Nenhum ZIP encontrado nesta competência." }));
    else {
      var groups = {};
      files.forEach(function (f) { var g = f.group || "outros"; (groups[g] = groups[g] || []).push(f); });
      Object.keys(groups).forEach(function (g) {
        var list = groups[g], all = list.every(function (f) { return picked.has(f.name); });
        var gcb = E("input", { type: "checkbox", checked: all, "aria-label": "Selecionar grupo " + g });
        gcb.addEventListener("change", function () { list.forEach(function (f) { gcb.checked ? picked.add(f.name) : picked.delete(f.name); }); paintFiles(); });
        var items = E("div", { class: "li-fitems" });
        list.forEach(function (f) {
          var cb = E("input", { type: "checkbox", checked: picked.has(f.name) });
          cb.addEventListener("change", function () { cb.checked ? picked.add(f.name) : picked.delete(f.name); paintFiles(); });
          items.appendChild(E("label", { class: "li-file" }, [cb, E("span", { class: "li-mono", text: f.name }), E("span", { class: "li-muted", text: f.size ? ctx.fmtSize(f.size) : "tamanho desconhecido" })]));
        });
        box.appendChild(E("fieldset", { class: "li-group" }, [E("legend", null, [E("label", { class: "li-check" }, [gcb, " " + g + " (" + list.length + ")"])]), items]));
      });
    }
    var tot = 0; files.forEach(function (f) { if (picked.has(f.name)) tot += Number(f.size) || 0; });
    refs.selCount.textContent = picked.size + " de " + files.length + " selecionado(s)" + (tot ? " · " + ctx.fmtSize(tot) : "");
    syncDl();
  }
  function dlTask() { return st && st.downloads ? st.downloads : null; }
  function syncDl() {
    if (!refs.go) return;
    var d = dlTask(), active = !!(d && d.running);
    refs.go.disabled = active || dlPending || !ctx.isAdmin() || !period || !picked.size || !refs.dir.value.trim();
    refs.go.textContent = d && d.task && d.task.status === "completed" && d.task.period === period ? "Baixar novamente" : "Baixar selecionados";
  }
  function startDl() {
    var dir = refs.dir.value.trim(), names = files.filter(function (f) { return picked.has(f.name); }).map(function (f) { return f.name; });
    if (!names.length || !period || !dir || dlPending) return;
    var d = dlTask();
    if (d && d.task && d.task.status === "completed" && d.task.period === period &&
        !window.confirm("Esta competência já foi baixada. Baixar novamente os " + names.length + " ZIP(s) selecionados?")) return;
    if (refs.over.checked && !window.confirm("Substituir ZIPs existentes de " + period + " na pasta de destino?\n\nArquivos com o mesmo nome serão sobrescritos.")) return;
    var g = gen; dlPending = true; dlMsg = ""; syncDl(); paintTask();
    ctx.api("/api/source/download", { period: period, names: names, directory: dir, overwrite: !!refs.over.checked }).then(function (download) {
      if (g !== gen) return; if (st) st.downloads = download; dlPending = false; dlMsg = "Download solicitado. Acompanhe abaixo."; syncDl(); paintTask();
    }).catch(function (e) { if (g !== gen) return; dlPending = false; if (!e.locked) dlMsg = e.message; syncDl(); paintTask(); });
  }
  function stopDl() {
    var g = gen; stopPending = true; paintTask();
    ctx.api("/api/source/stop", {}).then(function () { if (g === gen) { stopPending = false; paintTask(); } })
      .catch(function (e) { if (g !== gen) return; stopPending = false; if (!e.locked) dlMsg = e.message; paintTask(); });
  }
  function paintTask() {
    if (!refs.task) return;
    var box = clear(refs.task), d = dlTask(), t = d && d.task;
    if (t && t.status === "completed" && /^Download solicitado/.test(dlMsg)) dlMsg = "";
    if (dlMsg) box.appendChild(E("div", { class: /^Download solicitado/.test(dlMsg) ? "li-okmsg" : "inline-err", role: "status", text: dlMsg }));
    if (!t) { if (!dlMsg) box.appendChild(E("p", { class: "li-muted", text: "Nenhum download nesta sessão do programa." })); return; }
    if (dlMsg && t.status === "completed") box.appendChild(E("p", { class: "li-muted", text: "A solicitação acima não confirmou um novo download. O cartão abaixo mostra o download anterior, cujos arquivos foram preservados." }));
    var bt = Number(t.bytes_total) || 0, bd = Number(t.bytes_done) || 0;
    var pct = t.status === "completed" ? 100 : bt ? Math.floor(Math.min(99.9, bd / bt * 100) * 10) / 10 : 0;
    var label = { running: "Baixando", queued: "Na fila", paused: "Pausado", failed: "Falhou", completed: "Salvo", cancelled: "Cancelado" }[t.status] || "Aguardando confirmação";
    if (d.running && t.stopping) label = "Interrompendo";
    var bar = E("div", { class: "li-bar" + (d.running ? " live" : ""), role: "progressbar", "aria-valuemin": "0", "aria-valuemax": "100", "aria-valuenow": String(pct), "aria-label": "Download " + (t.period || "") }, [E("i")]);
    bar.firstChild.style.transform = "scaleX(" + pct / 100 + ")";
    box.appendChild(E("div", { class: "li-taskcard" }, [
      E("div", { class: "li-flex" }, [E("span", null, [badge(t.status === "completed" ? "completed" : t.status), " ", E("strong", { text: label + " · " + (t.period || "") })]), E("span", { class: "li-pct", text: pct.toFixed(1).replace(".", ",") + "%" })]),
      bar,
      E("p", { class: "li-muted", text: (bt ? ctx.fmtSize(bd) + " de " + ctx.fmtSize(bt) : ctx.fmtSize(bd) + " recebidos, total ainda desconhecido") + " · " + ctx.fmtN(t.completed_files) + "/" + ctx.fmtN(t.total_files) + " arquivos salvos" }),
      t.current_file ? E("p", { class: "li-mono li-small", text: "Arquivo atual: " + t.current_file }) : null,
      t.directory ? E("p", { class: "li-mono li-small", text: "Pasta: " + t.directory }) : null,
      t.message ? E("p", { class: "li-small", text: t.message }) : null,
      t.error ? E("div", { class: "inline-err", text: t.error }) : null,
      E("div", { class: "li-row" }, [
         d.running && ctx.isAdmin() ? E("button", { type: "button", class: "li-btn sm", disabled: stopPending || t.stopping, text: stopPending || t.stopping ? "Interrompendo…" : "Interromper download", onclick: stopDl }) : null,
        t.status === "completed" && t.directory ? E("button", { type: "button", class: "li-btn primary sm", text: "Usar pasta no processamento", onclick: function () { ctx.useFolder(t.directory, t.period); } }) : null,
         !d.running && (t.status === "paused" || t.status === "failed") ? E("span", { class: "li-muted", text: "Para continuar, selecione apenas os ZIPs que faltam salvar e baixe novamente. O arquivo interrompido recomeça; os já concluídos estão preservados." }) : null
      ])
    ]));
  }

  // ---------- jobs ----------
  function render(s) {
    if (!host || !ctx) return;
    st = s || null;
    refs.newBtn.disabled = !ctx.isAdmin() || !(st && st.configured) || !!(st && st.running);
    var jobs = (st && st.jobs) || [];
    refs.loading.hidden = true;
    if (!jobs.length) {
      refs.body.hidden = true; refs.empty.hidden = false; clear(refs.empty);
      refs.empty.appendChild(E("strong", { text: "Nenhuma importação ainda" }));
      refs.empty.appendChild(E("span", { text: ctx.isAdmin() ? "Baixe ou inspecione uma pasta de ZIPs e inicie o processamento." : "Quando o administrador concluir um processamento, ele aparece aqui." }));
    } else {
      refs.empty.hidden = true; refs.body.hidden = false;
      if (!jobs.some(function (j) { return j.id === selectedId; })) selectedId = jobs[0].id;
      paintList(jobs);
      paintDetail(jobs.filter(function (j) { return j.id === selectedId; })[0]);
    }
    syncDl(); paintTask();
  }
  function paintList(jobs) {
    var top = refs.list.scrollTop, ul = clear(refs.list);
    jobs.forEach(function (j) {
      var live = j.status === "running" || j.status === "queued";
      ul.appendChild(E("li", null, [E("button", { type: "button", class: "li-item" + (j.id === selectedId ? " on" : ""), "aria-pressed": j.id === selectedId ? "true" : "false",
        onclick: function () { selectedId = j.id; render(st); } }, [
        E("div", { class: "li-flex" }, [E("span", { class: "li-iname", text: periodLabel(j.period) }), badge(j.status)]),
        E("p", { class: "li-trunc", text: chips(j).join(" · ") || "Sem filtros" }),
        live ? progress(j, true) : null,
        E("p", { class: "li-mono li-tiny", text: (fmtDate(j.created_at) ? fmtDate(j.created_at) + " · " : "") + ctx.fmtN(j.rows_kept) + " mantidas" })
      ])]));
    });
    ul.scrollTop = top;
  }
  function paintDetail(j) {
    var oldLog = refs.detail.querySelector(".li-log"), logTop = oldLog ? oldLog.scrollTop : null;
    var d = clear(refs.detail); if (!j) return;
    var running = !!(st && st.running), task = st && st.task, admin = ctx.isAdmin();
    var mine = task && task.kind === "import" && task.job_id === j.id, cancelling = !!(mine && task.cancelling);
    var acts = E("div", { class: "li-acts" });
    if (admin && (j.status === "running" || j.status === "queued")) acts.appendChild(E("button", { type: "button", class: "li-btn sm", disabled: cancelling || !!(mine && task.stopping), text: mine && task.stopping ? "Pausando…" : "Pausar", onclick: function () { ctx.pause(); } }));
    if (admin && (j.status === "failed" || j.status === "paused")) acts.appendChild(E("button", { type: "button", class: "li-btn primary sm", disabled: running || resuming.has(j.id), text: resuming.has(j.id) ? "Retomando…" : "Retomar", onclick: function () {
      var g = gen; resuming.add(j.id); render(st);
      Promise.resolve(ctx.resume(j)).catch(function () {}).then(function () { if (g === gen) { resuming.delete(j.id); render(st); } });
    } }));
    if (j.status === "completed") acts.appendChild(E("button", { type: "button", class: "li-btn primary sm", text: "Pesquisar", onclick: function () { ctx.research(j); } }));
    if (admin && ["running", "queued", "paused", "failed"].indexOf(j.status) >= 0) acts.appendChild(E("button", { type: "button", class: "li-btn danger sm", disabled: cancelling || !!(running && !mine), text: cancelling ? "Cancelando…" : "Cancelar", onclick: function () { ctx.cancelProcessing(j); } }));
    var meta = ["#" + String(j.id).slice(0, 8)];
    if (fmtDate(j.created_at)) meta.push("criada " + fmtDate(j.created_at));
    if (fmtDate(j.updated_at)) meta.push("atualizada " + fmtDate(j.updated_at));
    d.appendChild(E("div", { class: "li-flex top" }, [E("div", null, [badge(j.status), E("h3", { class: "li-dtitle", text: periodLabel(j.period) }), E("p", { class: "li-mono li-tiny", text: meta.join(" · ") })]), acts]));
    d.appendChild(progress(j, false));
    d.appendChild(E("dl", { class: "li-stats" }, [["Arquivos", ctx.fmtN(j.file_index) + "/" + ctx.fmtN(j.total_files)], ["Linhas lidas", ctx.fmtN(j.rows_scanned)], ["Mantidas", ctx.fmtN(j.rows_kept)], ["Cobertura", j.coverage || (j.scope === "state" ? "Estado" : "Seleção")]].map(function (p) {
      return E("div", null, [E("dt", { text: p[0] }), E("dd", { text: p[1] })]);
    })));
    var c = chips(j); if (c.length) d.appendChild(E("div", { class: "li-chips" }, c.map(function (x) { return E("span", { text: x }); })));
    if (j.error) d.appendChild(E("div", { class: "li-err", text: j.error }));
    if (cancelling) d.appendChild(E("div", { class: "note", text: "Cancelando com segurança. Aguarde a gravação em andamento; não feche o programa." }));
    if (j.status !== "completed" && j.status !== "cancelled") d.appendChild(E("div", { class: "li-ckpt" }, [
      E("p", { class: "li-strong", text: "Progresso salvo: " + ctx.fmtN(j.file_index) + "/" + ctx.fmtN(j.total_files) + " arquivos concluídos · " + ctx.fmtN(j.rows_kept) + " estabelecimentos preservados." }),
      fmtDate(j.updated_at) ? E("p", { text: "Último registro do ponto salvo: " + fmtDate(j.updated_at) + "." }) : null,
      E("p", { text: "Em caso de erro ou pausa, use Retomar. O ZIP interrompido será relido até o ponto salvo, sem duplicar registros confirmados. A base só fica disponível para pesquisa e exportação após a conclusão." })
    ]));
    if (j.status === "cancelled") d.appendChild(E("div", { class: "li-ckpt", text: "Processamento cancelado. ZIPs e outras bases preservados. Registros parciais não são consultáveis." }));
    var log = E("div", { class: "li-log" }, [E("div", { class: "li-loghead", text: ">_ registro de etapas · " + (j.events || []).length })]);
    if (!(j.events || []).length) log.appendChild(E("p", { text: "Importação anterior a este registro de etapas. O ponto salvo e os totais acima continuam disponíveis." }));
    (j.events || []).forEach(function (event) {
      log.appendChild(E("p", { class: "li-mono li-small", text: fmtDate(event.at) + " · " + event.message +
        " · " + ctx.fmtN(event.files) + " arquivos concluídos · " + ctx.fmtN(event.rows) + " linhas lidas · " + ctx.fmtN(event.kept) + " mantidas" }));
    });
    d.appendChild(log);
    if (logTop !== null) log.scrollTop = logTop;
  }

  function reset() {
    gen++; st = null; selectedId = ""; resuming.clear(); picked.clear(); files = []; period = ""; dlMsg = ""; dlPending = stopPending = false;
    filesState = "idle"; periodsState = "idle";
    if (host) clear(host);
    refs = {}; host = null;
  }
  root.LocalImports = { init: init, render: render, reset: reset, reloadPeriods: function () { if (ctx) loadPeriods(); } };
})(window);
