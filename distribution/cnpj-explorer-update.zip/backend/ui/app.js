"use strict";
(function () {
  // ---- token ----
  // Captura token e (se houver) código de redefinição ANTES de limpar o fragmento.
  var hash = location.hash || "";
  var m = /(?:^#|&)token=([^&]+)/.exec(hash);
  var rm = /(?:^#|&)reset=([^&]+)/.exec(hash);
  var resetToken = rm ? decodeURIComponent(rm[1]) : "";
  if (m) sessionStorage.setItem("localToken", decodeURIComponent(m[1]));
  if (m || rm) history.replaceState(null, "", location.pathname + location.search);
  hash = ""; rm = null;
  var TOKEN = sessionStorage.getItem("localToken") || "";

  var $ = function (id) { return document.getElementById(id); };
  function el(tag, attrs, kids) {
    var n = document.createElement(tag);
    if (attrs) for (var k in attrs) {
      var v = attrs[k];
      if (v == null || v === false) continue;
      if (k === "class") n.className = v;
      else if (k === "text") n.textContent = v;
      else if (k.slice(0, 2) === "on") n.addEventListener(k.slice(2), v);
      else if (v === true) n.setAttribute(k, "");
      else n.setAttribute(k, String(v));
    }
    (kids || []).forEach(function (c) { if (c != null) n.appendChild(typeof c === "string" ? document.createTextNode(c) : c); });
    return n;
  }
  function clear(n) { while (n.firstChild) n.removeChild(n.firstChild); return n; }
  function fmtN(n) { return (Number(n) || 0).toLocaleString("pt-BR"); }
  function fmtSize(b) { b = Number(b) || 0; var u = ["B", "KB", "MB", "GB"], i = 0; while (b >= 1024 && i < 3) { b /= 1024; i++; } return b.toFixed(i ? 1 : 0) + " " + u[i]; }
  function showErr(msg) { var g = $("globalError"); g.textContent = msg || ""; g.hidden = !msg; }
  function inlineErr(box, msg) { box.appendChild(el("div", { class: "inline-err", role: "alert", text: msg })); }
  var STATUS_PT = { completed: "concluída", running: "em andamento", queued: "na fila", paused: "pausada", failed: "falhou", cancelled: "cancelado" };
  function stPill(s) { return el("span", { class: "pill " + s, text: STATUS_PT[s] || s }); }

  // ---- auth state ----
  var authed = false, authGeneration = 0, me = null;
  function getSession() { return sessionStorage.getItem("localSession") || ""; }
  function setSession(t) { if (t) sessionStorage.setItem("localSession", t); }
  function dropSession() { sessionStorage.removeItem("localSession"); }
  function isAdmin() { return !!(me && me.role === "admin"); }
  // Rotas de auth que exigem sessão: 401 nelas significa sessão perdida.
  var SESSION_AUTH = ["/api/auth/change", "/api/auth/migrate", "/api/auth/logout"];
  function LockedError() { var e = new Error("Sessão bloqueada. Entre novamente."); e.locked = true; return e; }

  function api(path, body, retried) {
    var generation = authGeneration;
    var opts = { method: body === undefined ? "GET" : "POST", credentials: "same-origin", headers: { "X-Local-Token": TOKEN } };
    var sess = getSession(); if (sess) opts.headers["X-Local-Session"] = sess;
    var isAuth = path.indexOf("/api/auth/") === 0, sessAuth = SESSION_AUTH.indexOf(path) >= 0;
    if (body !== undefined) { opts.headers["Content-Type"] = "application/json"; opts.body = JSON.stringify(body); }
    return fetch(path, opts).then(function (r) {
      return r.text().then(function (t) {
        var j = null; try { j = t ? JSON.parse(t) : {}; } catch (e) { j = null; }
        if (path !== "/api/auth/logout" && generation !== authGeneration) throw LockedError();
        if (r.status === 403 && j && j.code === "LOCAL_TOKEN_INVALID" && !retried &&
            window.desktop && typeof window.desktop.connectionToken === "function") {
          // Rejected before dispatch: retrying cannot repeat an import or export.
          return window.desktop.connectionToken().then(function (fresh) {
            if (generation !== authGeneration) throw LockedError();
            if (typeof fresh !== "string" || !/^[a-zA-Z0-9_-]{43}$/.test(fresh)) throw new Error("Conexão local indisponível. Reabra o programa pelo ícone.");
            TOKEN = fresh; sessionStorage.setItem("localToken", fresh);
            return api(path, body, true);
          });
        }
        if (r.status === 401 && (!isAuth || (sessAuth && path !== "/api/auth/logout"))) {
          if (generation === authGeneration) onUnauthorized();
          throw LockedError();
        }
        if (!r.ok) { var er = new Error((j && j.error) || ("Erro HTTP " + r.status)); er.status = r.status; er.data = j; throw er; }
        if (j === null) throw new Error("Resposta inválida do servidor");
        return j;
      });
    });
  }
  function softErr(e) { if (!e.locked) showErr(e.message); }

  // ---- desktop folder picker ----
  var hasDesktop = !!(window.desktop && typeof window.desktop.pickFolder === "function");
  document.querySelectorAll(".pick").forEach(function (b) {
    if (!hasDesktop) return;
    b.hidden = false;
    b.addEventListener("click", function () {
      var generation = authGeneration;
      var input = $(b.getAttribute("data-for"));
      Promise.resolve(window.desktop.pickFolder(getSession())).then(function (p) {
        if (!authed || generation !== authGeneration) return;
        if (p) { input.value = p; input.dispatchEvent(new Event("input", { bubbles: true })); input.focus(); }
      }).catch(function (e) { showErr("Não foi possível abrir o seletor de pastas: " + e.message); });
    });
  });

  // ---- picker ----
  function municipalityKey(value) {
    return String(value).normalize("NFD").replace(/[\u0300-\u036f]/g, "").toUpperCase().trim().replace(/\s+/g, " ");
  }
  function resolveMunicipalities(value, options) {
    var names = new Map(), codes = new Set(), matches = new Set(), pending = [], problems = [];
    options.forEach(function (o) {
      codes.add(o.code);
      var key = municipalityKey(o.label), group = names.get(key) || [];
      if (!group.includes(o.code)) group.push(o.code);
      names.set(key, group);
    });
    value.split(/[,;\r\n]+/).map(function (s) { return s.trim(); }).filter(Boolean).forEach(function (part) {
      var candidates;
      if (/^\d{1,4}$/.test(part)) {
        var code = part.padStart(4, "0");
        candidates = !options.length || codes.has(code) ? [code] : [];
      } else candidates = names.get(municipalityKey(part)) || [];
      if (candidates.length === 1) matches.add(candidates[0]);
      else {
        pending.push(part);
        problems.push(candidates.length > 1 ? part + ": nome repetido; informe o código Receita (" + candidates.join(", ") + ")." :
          part + ": " + (!options.length && !/^\d+$/.test(part) ? "carregue a lista de municípios antes de usar nomes." : "não encontrado; confira o nome completo ou o código Receita de 4 dígitos."));
      }
    });
    return { codes: Array.from(matches), pending: pending, problems: problems };
  }
  function Picker(host, title, onChange, municipalities) {
    var opts = [], sel = new Set(), labels = {};
    var search = el("input", { type: "search", placeholder: "Filtrar por código ou nome", "aria-label": "Filtrar " + title });
    var list = el("div", { class: "list", role: "group", "aria-label": title });
    var chips = el("div", { class: "chips", tabindex: "0", "aria-label": "Códigos selecionados" });
    var count = el("span", { class: "muted" });
    var manual = el("input", { placeholder: municipalities ? "Códigos ou nomes completos, separados por vírgula" : "Ou digite códigos separados por vírgula", "aria-label": municipalities ? "Lista de códigos ou nomes completos dos municípios" : "Códigos de " + title });
    var feedback = el("p", { class: "hint", role: "status", "aria-live": "polite" });
    function applyManual() {
      if (municipalities) {
        if (!manual.value.trim()) return;
        var result = resolveMunicipalities(manual.value, opts), added = 0;
        result.codes.forEach(function (c) { if (!sel.has(c)) { sel.add(c); added++; } });
        manual.value = result.pending.join(", ");
        feedback.textContent = added + " município(s) adicionado(s). " + sel.size + " selecionado(s). " + result.problems.join(" ");
        render(); if (added) fire();
        return;
      }
      manual.value.split(/[,;\s]+/).filter(Boolean).forEach(function (c) {
        sel.add(title === "CNAEs" && /^\d{4}-?\d\/?\d{2}$/.test(c) ? c.replace(/\D/g, "") : c);
      });
      manual.value = ""; render(); fire();
    }
    manual.addEventListener("change", applyManual);
    var contents = [el("div", { class: "ttl" }, [title, count]), search, list, manual];
    if (municipalities) {
      manual.addEventListener("paste", function () { setTimeout(applyManual, 0); });
      manual.addEventListener("keydown", function (e) { if (e.key === "Enter") { e.preventDefault(); applyManual(); } });
      contents.push(el("button", { type: "button", class: "btn", text: "Marcar municípios da lista", onclick: applyManual }));
      contents.push(el("p", { class: "hint", text: "Cole códigos Receita ou nomes completos: 4019, Montes Claros, São Francisco. Acentos, ç e maiúsculas são ignorados. Ao colar, os encontrados são marcados; ao digitar, pressione Enter ou use o botão. Nomes repetidos exigem o código." }), feedback);
    }
    contents.push(chips);
    clear(host).appendChild(el("div", { class: "picker" }, contents));
    search.addEventListener("input", renderList);
    function fire() { if (onChange) onChange(); }
    function renderList() {
      clear(list);
      var q = municipalityKey(search.value), shown = 0;
      if (!opts.length) { list.appendChild(el("span", { class: "muted", text: municipalities ? "Sem lista de referência. Inspecione a pasta de ZIPs ou escolha uma base concluída." : "Lista de CNAEs ainda não carregada. No processamento, use Inspecionar na pasta que contém Cnaes.zip; na pesquisa, escolha uma base concluída." })); return; }
      var numericQuery = !municipalities && /^[\d./\s-]+$/.test(q) ? q.replace(/\D/g, "") : "";
      for (var i = 0; i < opts.length && shown < 200; i++) {
        var o = opts[i];
        if (q && municipalityKey(o.code + " " + o.label).indexOf(q) < 0 &&
            !(numericQuery && o.code.indexOf(numericQuery) >= 0)) continue;
        shown++;
        (function (o) {
          var cb = el("input", { type: "checkbox", checked: sel.has(o.code) });
          cb.addEventListener("change", function () { cb.checked ? sel.add(o.code) : sel.delete(o.code); renderChips(); fire(); });
          list.appendChild(el("label", null, [cb, el("code", { text: o.code }), document.createTextNode(o.label)]));
        })(o);
      }
      if (!shown) list.appendChild(el("span", { class: "muted", text: "Nada encontrado." }));
    }
    function renderChips() {
      clear(chips);
      count.textContent = sel.size ? sel.size + " selecionado(s)" : "";
      sel.forEach(function (c) {
        chips.appendChild(el("button", { type: "button", class: "chip", title: "Remover", "aria-label": "Remover " + c, onclick: function () { sel.delete(c); render(); fire(); } }, [c + (labels[c] ? " · " + labels[c] : "")]));
      });
    }
    function render() { renderList(); renderChips(); }
    render();
    return {
      setOptions: function (o) { opts = o || []; labels = {}; opts.forEach(function (x) { labels[x.code] = x.label; }); render(); },
      hasOptions: function () { return opts.length > 0; },
      get: function () { return Array.from(sel); },
      set: function (values) { sel = new Set((values || []).map(function (c) { return title === "CNAEs" && /^\d{4}-?\d\/?\d{2}$/.test(c) ? c.replace(/\D/g, "") : c; })); search.value = ""; render(); fire(); },
      clear: function () { sel.clear(); search.value = ""; manual.value = ""; feedback.textContent = ""; render(); },
      reset: function () { sel.clear(); search.value = ""; manual.value = ""; feedback.textContent = ""; opts = []; labels = {}; render(); }
    };
  }

  // ---- state ----
  var status = null, jobsCache = [];
  var applied = null, nextAfter = null, pageItems = [], selected = new Map(), lastTaskKey = "";
  var allSelected = false, allCount = 0, libraryItems = [], workspaceGeneration = 0, referenceRequest = 0, selectionVersion = 0;
  var searchReady = false, searchRequest = 0, pollTimer = null, pollGen = 0;
  var searchProgress = window.LocalSearchProgress.create({ el: el, clear: clear }, $("searchProgress"));
  var lastExport = null, autoOutDir = "";
  function resetSearchProgress() {
    allSelected = false; allCount = 0; referenceRequest++; updateSel();
    searchProgress.reset();
    $("results").setAttribute("aria-busy", "false");
  }

  // ---- status ----
  function sepFor(p) { return p.indexOf("\\") >= 0 || /^[A-Za-z]:/.test(p) ? "\\" : "/"; }
  function defaultOut(dir) { return dir.replace(/[\\/]+$/, "") + sepFor(dir) + "exportacoes"; }
  function renderStatus(s) {
    if (!authed) return;
    var oldDir = status && status.data_dir;
    status = s;
    if (s.configured && oldDir !== s.data_dir) {
      workspaceGeneration++;
      applied = null; searchReady = false; searchRequest++; selected.clear(); updateSel();
      resetSearchProgress();
      clear($("results")); clear($("dupOut"));
      sCities.clear(); sCnaes.clear();
      var out = $("outDir");
      if (!out.value || out.value === autoOutDir) { autoOutDir = defaultOut(s.data_dir); out.value = autoOutDir; }
      loadHistory();
      refreshLibrary();
      impCities.setOptions([]); impCnaes.setOptions([]);
      loadImportReferences();
    }
    if (s.error) showErr(s.error);
    var tb = clear($("taskBar"));
    var t = s.task;
    var exportProgress = clear($("exportProgress"));
    if (t && t.kind === "export") {
      exportProgress.appendChild(window.LocalExportProgress.render(el, fmtN, t));
    }
    $("xAll").disabled = !!s.running;
    $("xSel").disabled = !!s.running;
    if (!s.configured) tb.textContent = isAdmin() ? "Pasta de dados ainda não configurada." : "O administrador ainda não configurou a pasta de dados.";
    else if (!t) tb.textContent = "Ocioso. Dados em " + s.data_dir;
    else {
      var label = (t.kind === "import" ? "Processamento" : "Exportação") + " — ";
      tb.appendChild(el("div", null, [stPill(t.status), " " + label + (t.message || "")]));
      if (t.status === "running" && isAdmin()) tb.appendChild(el("button", { class: "btn ghost sm", type: "button", disabled: !!t.cancelling, onclick: pause, text: t.cancelling ? "Cancelando…" : "Pausar" }));
      var j = t.job_id && (s.jobs || []).filter(function (x) { return x.id === t.job_id; })[0];
      if (j && t.kind === "import" && j.total_files) {
        tb.appendChild(window.LocalImportProgress.render({ el: el, fmtSize: fmtSize }, j, t, s.running, true));
      }
      if (t.status === "failed") tb.appendChild(el("div", { class: "inline-err", text: t.message || "Falha" }));
      if (t.kind === "export" && t.status === "completed" && t.result) {
        tb.appendChild(el("div", { class: "ok", text: "Arquivo: " + t.result.path + " (" + fmtN(t.result.companies) + " empresas, " + fmtN(t.result.rows) + " linhas)" }));
        if (t.result.id != null) tb.appendChild(openBtn(t.result.id, "sm"));
      }
      var key = t.kind + t.status + (t.result ? t.result.path : "");
      if (key !== lastTaskKey) {
        lastTaskKey = key;
        if (t.kind === "export" && t.status === "completed") {
          lastExport = t.result || null;
          renderExportDone();
          loadHistory();
          refreshExportTags();
        }
      }
    }
    $("dataInfo").textContent = s.configured ? "Pasta ativa: " + s.data_dir : "Nenhuma pasta configurada.";
    if (s.configured && !$("dataDir").value) $("dataDir").value = s.data_dir;
    $("btnImport").disabled = !isAdmin() || !s.configured || !!s.running;
    renderJobs(s.jobs || []);
  }
  function poll() {
    var gen = pollGen;
    if (!authed) return;
    api("/api/status").then(function (s) { if (gen === pollGen) renderStatus(s); })
      .catch(function (e) { if (!e.locked && gen === pollGen) {
        window.LocalImportProgress.offline(document);
        showErr("Servidor local: " + e.message + (TOKEN ? "" : " (token ausente: abra pelo link exibido ao iniciar o programa)"));
      } })
      .then(function () { if (authed && gen === pollGen) pollTimer = setTimeout(poll, status && status.running ? 1500 : 4000); });
  }
  function stopPoll() { pollGen++; if (pollTimer) clearTimeout(pollTimer); pollTimer = null; }
  function pause() { api("/api/pause", {}).then(poll1).catch(softErr); }
  var cancellingJobs = new Set();
  function cancelProcessing(job) {
    if (cancellingJobs.has(job.id)) return;
    if (!window.confirm("Cancelar o processamento da competência " + job.period + "?\n\nEsta execução será encerrada e não poderá ser retomada. Para continuar depois, use Pausar em vez de cancelar.\n\nOs ZIPs, outras bases e os registros já gravados não serão apagados. A base incompleta não ficará disponível para pesquisa ou exportação. Você poderá iniciar um novo processamento.")) return;
    cancellingJobs.add(job.id);
    renderJobs(status.jobs || []);
    api("/api/cancel", { id: job.id }).then(function (r) {
      if (r.status === "cancelled") cancellingJobs.delete(job.id);
      return poll1();
    }).catch(function (e) { cancellingJobs.delete(job.id); poll1(); softErr(e); });
  }
  function poll1() { return api("/api/status").then(renderStatus); }

  function renderJobs(jobs) {
    var box = clear($("jobs"));
    if (!jobs.length) box.appendChild(el("div", { class: "emptybox" }, [el("strong", { text: "Nenhuma base criada ainda." }), el("span", { text: isAdmin() ? "Inspecione a pasta de ZIPs e inicie o processamento." : "Quando o administrador concluir um processamento, a base aparece aqui." })]));
    jobs.forEach(function (j) {
      var cancelling = cancellingJobs.has(j.id) || !!(status && status.task && status.task.job_id === j.id && status.task.cancelling);
      if (j.status === "cancelled" || j.status === "completed" ||
          ((j.status === "failed" || j.status === "paused") && status && status.task && status.task.job_id === j.id && status.task.cancelling && status.task.status !== "running")) {
        cancellingJobs.delete(j.id); cancelling = false;
      }
      var prog = window.LocalImportProgress.render({ el: el, fmtSize: fmtSize }, j, status && status.task, status && status.running, false);
      var actions = el("div", { class: "jact" });
      if (isAdmin() && (j.status === "failed" || j.status === "paused")) actions.appendChild(el("button", { class: "btn sm", type: "button", disabled: cancelling || !!(status && status.running), text: "Retomar", onclick: function () {
        api("/api/resume", { id: j.id }).then(poll1).catch(softErr);
      } }));
      if (isAdmin() && (j.status === "running" || j.status === "queued")) actions.appendChild(el("button", { class: "btn sm", type: "button", disabled: cancelling, text: "Pausar", onclick: pause }));
      if (isAdmin() && ["running", "queued", "paused", "failed"].indexOf(j.status) >= 0) actions.appendChild(el("button", { class: "btn sm", type: "button", disabled: cancelling || !!(status && status.running && (!status.task || status.task.kind !== "import" || status.task.job_id !== j.id)), text: cancelling ? "Cancelando…" : "Cancelar processamento", onclick: function () { cancelProcessing(j); } }));
      if (j.status === "completed") actions.appendChild(el("button", { class: "btn sm primary", type: "button", text: "Pesquisar", onclick: function () { $("jobSel").value = j.id; onJobChange(); location.hash = "#s-search"; } }));
      var scope = j.scope === "state" ? "Estado " + j.state + " inteiro" : "Seleção: " + (j.cities || []).length + " municípios, " + (j.cnaes || []).length + " CNAEs" + (j.active_only ? ", somente ativas" : "");
      box.appendChild(el("div", { class: "job" }, [
        el("div", { class: "head" }, [el("div", null, [el("strong", { text: "Competência " + j.period }), " ", stPill(j.status)]), actions]),
        el("div", { class: "meta", text: scope + (j.coverage ? " · " + j.coverage : "") }),
        prog,
        cancelling ? el("div", { class: "note", role: "status", text: "Cancelando com segurança. Aguarde a gravação em andamento; não feche o programa." }) : null,
        j.status === "cancelled" ? el("div", { class: "note", text: "Processamento cancelado. ZIPs e outras bases preservados. Registros parciais não são consultáveis; inicie outro processamento se precisar." }) : null,
        el("div", { class: "meta", text: fmtN(j.file_index) + " de " + fmtN(j.total_files) + " arquivos concluídos · linhas lidas " + fmtN(j.rows_scanned) + " · registros mantidos " + fmtN(j.rows_kept) }),
        j.error ? el("div", { class: "inline-err", text: j.error }) : null
      ]));
    });
    var done = jobs.filter(function (j) { return j.status === "completed"; });
    var key = done.map(function (j) { return j.id; }).join();
    if (key !== jobsCache.join() || !$("jobSel").options.length) {
      jobsCache = done.map(function (j) { return j.id; });
      var sel = $("jobSel"), cur = sel.value; clear(sel);
      if (!done.length) sel.appendChild(el("option", { value: "", text: "Nenhuma base concluída" }));
      done.forEach(function (j) { sel.appendChild(el("option", { value: j.id, text: j.period + " · " + (j.scope === "state" ? "Estado " + j.state : "Seleção") + " · " + fmtN(j.rows_kept) + " estab." })); });
      if (cur && jobsCache.indexOf(cur) >= 0) sel.value = cur; else if (done.length) { sel.value = done[0].id; onJobChange(); }
    }
  }

  // ---- configure ----
  $("fConfigure").addEventListener("submit", function (e) {
    e.preventDefault();
    api("/api/configure", { data_dir: $("dataDir").value.trim() }).then(function (s) { showErr(""); renderStatus(s); }).catch(softErr);
  });

  // ---- inspect ----
  var impCities = Picker($("impCities"), "Municípios (código Receita)", null, true);
  var impCnaes = Picker($("impCnaes"), "CNAEs");
  var importReferenceGeneration = 0;
  function loadImportReferences() {
    var request = ++importReferenceGeneration, generation = authGeneration;
    return api("/api/references").then(function (r) {
      if (generation !== authGeneration || request !== importReferenceGeneration) return;
      if (!impCities.hasOptions()) impCities.setOptions(r.cities);
      if (!impCnaes.hasOptions()) impCnaes.setOptions(r.cnaes);
    }).catch(softErr);
  }
  $("sourceDir").addEventListener("input", function () {
    importReferenceGeneration++;
    $("btnImport").dataset.valid = "";
    clear($("inspectOut"));
    impCities.setOptions([]); impCnaes.setOptions([]);
    loadImportReferences();
  });
  $("fInspect").addEventListener("submit", function (e) {
    e.preventDefault();
    importReferenceGeneration++;
    var inspectedPath = $("sourceDir").value.trim(), generation = authGeneration;
    var out = clear($("inspectOut"));
    out.appendChild(el("div", { class: "sk" }));
    api("/api/inspect", { source_dir: inspectedPath }).then(function (r) {
      if (generation !== authGeneration || $("sourceDir").value.trim() !== inspectedPath) return;
      clear(out);
      out.appendChild(el("p", { class: r.valid ? "ok" : "", text: r.valid ? "Conjunto completo: " + r.files.length + " arquivos prontos." : "Conjunto inválido ou incompleto." }));
      (r.missing || []).length && inlineErr(out, "Faltando: " + r.missing.join(", "));
      (r.warnings || []).forEach(function (w) { out.appendChild(el("div", { class: "note", text: w })); });
      var g = el("div", { class: "files" });
      (r.files || []).forEach(function (f) { g.appendChild(el("div", null, [el("span", { text: f.name }), el("span", { text: f.kind + " · " + fmtSize(f.size) })])); });
      out.appendChild(g);
      var refs = r.references || { cnaes: [], cities: [] };
      impCities.setOptions(refs.cities); impCnaes.setOptions(refs.cnaes);
      $("btnImport").dataset.valid = r.valid ? "1" : "";
    }).catch(function (e) {
      if (generation !== authGeneration || $("sourceDir").value.trim() !== inspectedPath) return;
      clear(out); if (!e.locked) inlineErr(out, e.message);
    });
  });

  // ---- import ----
  function scopeVal() { return document.querySelector("input[name=scope]:checked").value; }
  document.querySelectorAll("input[name=scope]").forEach(function (r) { r.addEventListener("change", function () { $("selectedOpts").hidden = scopeVal() !== "selected"; }); });
  $("fImport").addEventListener("submit", function (e) {
    e.preventDefault();
    var scope = scopeVal(), src = $("sourceDir").value.trim();
    if (!src) return showErr("Informe e inspecione a pasta de ZIPs na etapa 2.");
    if ($("btnImport").dataset.valid !== "1") return showErr("Inspecione a pasta atual e confirme o conjunto completo de ZIPs antes de iniciar.");
    var body = { source_dir: src, period: $("period").value.trim(), scope: scope, state: $("state").value.trim().toUpperCase(), cities: [], cnaes: [], active_only: false };
    if (scope === "selected") {
      body.cities = impCities.get(); body.cnaes = impCnaes.get(); body.active_only = $("impActive").checked;
      if (!body.cities.length && !body.cnaes.length) return showErr("No modo selecionado, escolha ao menos um município ou CNAE.");
    }
    api("/api/import", body).then(function () { showErr(""); poll1(); }).catch(softErr);
  });

  // ---- search ----
  var markPending = function () { if (applied) $("pendingNote").hidden = false; };
  var sCities = Picker($("sCities"), "Municípios", markPending, true);
  var sCnaes = Picker($("sCnaes"), "CNAEs", markPending);
  ["sState", "sNeigh", "sText", "sActive"].forEach(function (id) { $(id).addEventListener("input", markPending); $(id).addEventListener("change", markPending); });

  function onJobChange() {
    var id = $("jobSel").value;
    applied = null; searchReady = false; searchRequest++; selected.clear(); updateSel(); pageItems = []; nextAfter = null;
    resetSearchProgress();
    clear($("results")).appendChild(el("tr", null, [el("td", { colspan: 8, class: "empty", text: id ? "Aplique os filtros para pesquisar." : "Selecione uma base concluída." })]));
    $("more").hidden = true; clear($("dupOut"));
    sCities.clear(); sCnaes.clear();
    if (!id) return;
    loadReferences(id).catch(softErr);
  }
  $("jobSel").addEventListener("change", onJobChange);

  function loadReferences(id) {
    var request = ++referenceRequest;
    return api("/api/references?job_id=" + encodeURIComponent(id)).then(function (r) {
      if (request !== referenceRequest || $("jobSel").value !== id) return;
      sCities.setOptions(r.cities); sCnaes.setOptions(r.cnaes);
      [["resultCity", r.cities], ["resultCnae", r.cnaes]].forEach(function (pair) {
        var node = clear($(pair[0]));
        node.appendChild(el("option", { value: "", text: "Todos do resultado" }));
        (pair[1] || []).forEach(function (v) { node.appendChild(el("option", { value: v.code, text: v.code + " · " + v.label })); });
      });
    });
  }

  function refreshLibrary() {
    var generation = ++workspaceGeneration;
    return api("/api/workspace", { action: "list" }).then(function (r) {
      if (generation !== workspaceGeneration) return;
      libraryItems = r.items || [];
      [["cityGroups", "group"], ["savedResults", "result"]].forEach(function (pair) {
        var node = $(pair[0]), previous = node.value; clear(node);
        node.appendChild(el("option", { value: "", text: "Escolha um item salvo" }));
        libraryItems.filter(function (i) { return i.kind === pair[1]; }).forEach(function (i) {
          node.appendChild(el("option", { value: i.id, text: i.name + " · " +
            (i.kind === "group" ? i.payload.cities.length + " municípios" : fmtN(i.payload.count) + " empresas / " +
              (i.payload.all_selected ? "todas" : fmtN((i.payload.selected || []).length)) + " marcadas") }));
        });
        node.value = previous;
      });
    }).catch(softErr);
  }
  function libraryItem(selectId) {
    return libraryItems.find(function (item) { return item.id === $(selectId).value; });
  }
  function workspaceMessage(text) { $("workspaceNote").textContent = text; }
  $("refreshLibrary").addEventListener("click", refreshLibrary);
  $("saveCityGroup").addEventListener("click", function (event) {
    var b = event.currentTarget; b.disabled = true;
    api("/api/workspace", { action: "save_group", name: $("cityGroupName").value, cities: sCities.get() })
      .then(function () { workspaceMessage("Grupo de municípios salvo. Pode ser carregado em consultas futuras."); return refreshLibrary(); })
      .catch(softErr).finally(function () { b.disabled = false; });
  });
  $("useCityGroup").addEventListener("click", function () {
    var item = libraryItem("cityGroups");
    if (!item) return showErr("Escolha um grupo salvo.");
    sCities.set(item.payload.cities); $("cityGroupName").value = item.name;
    workspaceMessage("Grupo carregado no formulário. Clique em Aplicar filtros para pesquisar.");
  });
  function deleteLibrary(selectId) {
    var item = libraryItem(selectId);
    if (!item) return showErr("Escolha um item salvo para excluir.");
    if (!window.confirm('Excluir "' + item.name + '"? Remove apenas o item salvo, não a base nem planilhas.')) return;
    api("/api/workspace", { action: "delete", id: item.id, kind: item.kind }).then(function () {
      if (applied && applied.snapshot_id === item.id) onJobChange();
      workspaceMessage("Item salvo excluído. Base e planilhas preservadas."); return refreshLibrary();
    }).catch(softErr);
  }
  $("deleteCityGroup").addEventListener("click", function () { deleteLibrary("cityGroups"); });
  $("deleteResult").addEventListener("click", function () { deleteLibrary("savedResults"); });
  $("saveResult").addEventListener("click", function (event) {
    if (!applied || !searchReady) return showErr("Aguarde uma consulta concluir antes de salvar.");
    var b = event.currentTarget;
    b.disabled = true; workspaceMessage("Salvando todas as empresas deste resultado no disco… Aguarde, resultados grandes podem demorar.");
    api("/api/workspace", { action: "save_result", name: $("resultName").value, job_id: applied.job_id,
      filters: applied, selected: Array.from(selected.keys()), all_selected: allSelected }).then(function (r) {
      workspaceMessage('Resultado "' + r.name + '" salvo: ' + fmtN(r.payload.count) + " empresas / " +
        (r.payload.all_selected ? "todas" : fmtN((r.payload.selected || []).length)) + " marcadas. Abra pela lista quando precisar.");
      return refreshLibrary();
    }).catch(function (e) { workspaceMessage("Não foi possível salvar o resultado."); softErr(e); })
      .finally(function () { b.disabled = false; });
  });
  $("openResult").addEventListener("click", function () {
    var item = libraryItem("savedResults");
    if (!item) return showErr("Escolha um resultado salvo.");
    if (!Array.from($("jobSel").options).some(function (o) { return o.value === item.payload.job_id; })) return showErr("A base original não está disponível nesta pasta.");
    $("jobSel").value = item.payload.job_id; onJobChange();
    applied = { job_id: item.payload.job_id, snapshot_id: item.id, cities: [], cnaes: [], rules: [] };
    selected = new Map((item.payload.selected || []).map(function (cnpj) { return [cnpj, true]; }));
    allSelected = !!item.payload.all_selected; allCount = item.payload.count; updateSel();
    $("resultName").value = item.name;
    $("pendingNote").hidden = false;
    $("pendingNote").textContent = "Resultado salvo aberto — os campos do formulário acima só serão usados ao clicar em Aplicar filtros.";
    workspaceMessage('Resultado salvo "' + item.name + '" aberto. Empresas e marcações restauradas; os filtros originais não foram reexecutados.');
    load(false);
  });
  $("refineResult").addEventListener("click", function () {
    if (!applied || !searchReady) return showErr("Conclua uma consulta antes de refinar os resultados.");
    applied = Object.assign({}, applied, { refine_cities: $("resultCity").value ? [$("resultCity").value] : [],
      refine_cnaes: $("resultCnae").value ? [$("resultCnae").value] : [] });
    selected.clear(); allSelected = false; updateSel(); nextAfter = null; pageItems = [];
    load(false);
  });

  // ---- advanced rules ----
  var OP_PT = { contains: "contém", not_contains: "não contém", starts_with: "começa com", eq: "é igual a", ne: "é diferente de", "in": "é um de", not_in: "não é nenhum de", is_empty: "está vazio", not_empty: "está preenchido", gte: "a partir de", lte: "até", between: "entre" };
  var fieldMeta = null, fieldById = {}, maxRules = 40, ruleRows = [];
  function loadFields() {
    $("rulesMsg").textContent = "Carregando campos…";
    return api("/api/filter-fields").then(function (r) {
      fieldMeta = r.fields || []; maxRules = r.max_rules || 40; fieldById = {};
      fieldMeta.forEach(function (f) { fieldById[f.id] = f; });
      $("rulesMsg").textContent = ""; updateRuleCount();
    }).catch(function (e) {
      if (e.locked) return;
      clear($("rulesMsg")).appendChild(el("span", { class: "errtxt" }, ["Não foi possível carregar os campos: " + e.message + " "]));
      $("rulesMsg").appendChild(el("button", { class: "btn sm", type: "button", text: "Tentar novamente", onclick: loadFields }));
    });
  }
  function updateRuleCount() {
    var n = ruleRows.length;
    $("advCount").textContent = n ? n + (n === 1 ? " regra" : " regras") : "empresa, estabelecimento, sócios, Simples/MEI, contatos";
    $("addRule").disabled = !fieldMeta || n >= maxRules;
  }
  function addRule(init) {
    if (!fieldMeta || ruleRows.length >= maxRules) return;
    var row = el("div", { class: "rule" });
    var fSel = el("select", { "aria-label": "Campo" });
    var groups = {};
    fieldMeta.forEach(function (f) {
      if (!groups[f.group]) { groups[f.group] = el("optgroup", { label: f.group }); fSel.appendChild(groups[f.group]); }
      groups[f.group].appendChild(el("option", { value: f.id, text: f.label }));
    });
    var oSel = el("select", { "aria-label": "Condição" });
    var vBox = el("div", { class: "rval" });
    var rm = el("button", { class: "btn ghost sm rm", type: "button", "aria-label": "Remover regra", text: "Remover" });
    row.appendChild(fSel); row.appendChild(oSel); row.appendChild(vBox); row.appendChild(rm);
    var st = { row: row, fSel: fSel, oSel: oSel, v1: null, v2: null };
    function fillOps() {
      var f = fieldById[fSel.value], prev = oSel.value; clear(oSel);
      f.operators.forEach(function (o) { oSel.appendChild(el("option", { value: o, text: OP_PT[o] || o })); });
      if (f.operators.indexOf(prev) >= 0) oSel.value = prev;
    }
    function input(f, ph) {
      if (f.choices && f.choices.length && (oSel.value === "eq" || oSel.value === "ne")) {
        var s = el("select", { "aria-label": "Valor" });
        f.choices.forEach(function (c) { s.appendChild(el("option", { value: c.value, text: c.label })); });
        return s;
      }
      var a = { "aria-label": ph || "Valor", autocomplete: "off", maxlength: 256 };
      if (f.type === "date") a.type = "date";
      else if (f.type === "number") { a.inputmode = "decimal"; a.placeholder = ph || "ex.: 50000.00"; }
      else a.placeholder = ph || "valor";
      if (oSel.value === "in" || oSel.value === "not_in") {
        a.type = "text";
        a.placeholder = f.choices ? "códigos: " + f.choices.slice(0, 3).map(function (c) { return c.value; }).join(",") : "valor1, valor2";
      }
      return el("input", a);
    }
    function fillVal() {
      var f = fieldById[fSel.value], op = oSel.value; clear(vBox); st.v1 = st.v2 = null;
      if (op === "is_empty" || op === "not_empty") { vBox.appendChild(el("span", { class: "muted", text: "sem valor" })); return; }
      st.v1 = input(f); vBox.appendChild(st.v1);
      if (op === "between") { vBox.appendChild(el("span", { class: "muted", text: "e" })); st.v2 = input(f, "fim"); vBox.appendChild(st.v2); }
      if ((op === "in" || op === "not_in") && f.choices) vBox.appendChild(el("small", { class: "choicehint", text: f.choices.map(function (c) { return c.label; }).join("; ") }));
    }
    fSel.addEventListener("change", function () { fillOps(); fillVal(); markPending(); });
    oSel.addEventListener("change", function () { fillVal(); markPending(); });
    vBox.addEventListener("input", markPending); vBox.addEventListener("change", markPending);
    rm.addEventListener("click", function () { ruleRows.splice(ruleRows.indexOf(st), 1); row.remove(); updateRuleCount(); markPending(); $("addRule").focus(); });
    if (init && fieldById[init.field]) fSel.value = init.field;
    fillOps(); if (init && init.op) oSel.value = init.op; fillVal();
    if (init && st.v1) st.v1.value = init.value || ""; if (init && st.v2) st.v2.value = init.value2 || "";
    $("rules").appendChild(row); ruleRows.push(st); updateRuleCount();
    if (!init) fSel.focus();
  }
  $("addRule").addEventListener("click", function () { addRule(null); markPending(); });
  function collectRules() {
    var out = [];
    for (var i = 0; i < ruleRows.length; i++) {
      var r = ruleRows[i], f = fieldById[r.fSel.value], op = r.oSel.value, rule = { field: f.id, op: op };
      r.row.classList.remove("bad");
      if (r.v1) {
        var v = r.v1.value.trim();
        if (!v || (r.v2 && !r.v2.value.trim())) { r.row.classList.add("bad"); r.v1.focus(); throw new Error("Preencha o valor da regra \"" + f.label + "\"."); }
        rule.value = v; if (r.v2) rule.value2 = r.v2.value.trim();
      }
      out.push(rule);
    }
    return out;
  }
  function clearRules() { ruleRows = []; clear($("rules")); updateRuleCount(); }

  $("clearFilters").addEventListener("click", function () {
    $("sState").value = "MG"; $("sNeigh").value = ""; $("sText").value = ""; $("sActive").checked = true;
    sCities.clear(); sCnaes.clear(); clearRules();
    if (applied) { $("pendingNote").hidden = false; $("pendingNote").textContent = "Filtros limpos — aplique para atualizar"; }
  });

  function filtersQS(f, after) {
    var p = new URLSearchParams();
    p.set("job_id", f.job_id);
    if (f.state) p.set("state", f.state);
    if (f.cities.length) p.set("cities", f.cities.join(","));
    if (f.cnaes.length) p.set("cnaes", f.cnaes.join(","));
    if (f.neighborhood) p.set("neighborhood", f.neighborhood);
    if (f.search) p.set("search", f.search);
    if (f.active_only) p.set("active_only", "1");
    if (f.rules && f.rules.length) p.set("rules", JSON.stringify(f.rules));
    if (f.snapshot_id) p.set("snapshot_id", f.snapshot_id);
    if (f.refine_cities && f.refine_cities.length) p.set("refine_cities", f.refine_cities.join(","));
    if (f.refine_cnaes && f.refine_cnaes.length) p.set("refine_cnaes", f.refine_cnaes.join(","));
    if (after) p.set("after", after);
    return p.toString();
  }
  $("fSearch").addEventListener("submit", function (e) {
    e.preventDefault();
    var id = $("jobSel").value;
    if (!id) return showErr("Selecione uma base concluída.");
    var rules;
    try { rules = collectRules(); } catch (er) { $("advBox").open = true; return showErr(er.message); }
    showErr("");
    applied = { job_id: id, state: $("sState").value.trim().toUpperCase(), cities: sCities.get(), cnaes: sCnaes.get(), neighborhood: $("sNeigh").value.trim(), search: $("sText").value.trim(), active_only: $("sActive").checked, rules: rules };
    selected.clear(); allSelected = false; updateSel();
    $("resultCity").value = ""; $("resultCnae").value = "";
    workspaceMessage("Consulta aplicada. Salve o resultado e a seleção para reabrir depois.");
    $("pendingNote").hidden = true; $("pendingNote").textContent = "Filtros alterados — aplique para atualizar";
    pageItems = []; nextAfter = null;
    clear($("dupOut"));
    load(false);
  });
  $("more").addEventListener("click", function () { load(true); });

  function load(append) {
    var request = ++searchRequest;
    searchReady = false;
    var tb = $("results");
    searchProgress.begin(request, append);
    tb.setAttribute("aria-busy", "true");
    if (!append) { clear(tb); for (var i = 0; i < 5; i++) tb.appendChild(el("tr", null, [el("td", { colspan: 8 }, [el("div", { class: "sk" })])])); }
    $("more").disabled = true;
    searchProgress.advance(request, 1);
    api("/api/companies?" + filtersQS(applied, append ? nextAfter : null)).then(function (r) {
      if (request !== searchRequest) return;
      searchProgress.advance(request, 2);
      // Yield a frame to show the real response/formatting transition. A newer
      // request or lock can invalidate this response before its rows are drawn.
      return new Promise(function (resolve, reject) {
        window.requestAnimationFrame(function () {
          try {
            if (request !== searchRequest) return resolve();
            if (!append) clear(tb);
            pageItems = r.items || [];
            nextAfter = r.next_after;
            pageItems.forEach(function (c) { tb.appendChild(row(c)); });
            if (!append && !pageItems.length) tb.appendChild(el("tr", null, [el("td", { colspan: 8, class: "empty", text: "Nenhuma empresa corresponde aos filtros aplicados." })]));
            $("more").hidden = !nextAfter; $("more").disabled = false;
            searchReady = true;
            tb.setAttribute("aria-busy", "false");
            searchProgress.finish(request, pageItems.length, !!nextAfter);
            resolve();
          } catch (error) { reject(error); }
        });
      });
    }).catch(function (e) {
      if (request !== searchRequest || e.locked) return;
      searchProgress.fail(request);
      tb.setAttribute("aria-busy", "false");
      if (!append) clear(tb);
      var td = el("td", { colspan: 8, class: "empty" }, [el("div", { class: "inline-err", text: e.message }), el("button", { class: "btn sm", type: "button", text: "Tentar novamente", onclick: function () { load(append); } })]);
      tb.appendChild(el("tr", null, [td])); $("more").disabled = false;
    });
  }
  function row(c) {
    var cb = el("input", { type: "checkbox", "aria-label": "Selecionar " + c.cnpj, checked: allSelected || selected.has(c.cnpj), disabled: allSelected });
    var tr = el("tr", { class: allSelected || selected.has(c.cnpj) ? "sel" : null });
    tr.exportTag = el("span", { class: "tag", text: "já exportada", hidden: !c.exported });
    cb.addEventListener("change", function () {
      if (cb.checked) { if (selected.size >= 3000) { cb.checked = false; return showErr("Limite de 3000 empresas selecionadas."); } selected.set(c.cnpj, true); }
      else selected.delete(c.cnpj);
      tr.className = cb.checked ? "sel" : ""; updateSel();
    });
    tr.cb = cb; tr.cnpj = c.cnpj;
    [el("td", null, [cb]), el("td", { class: "mono", text: c.cnpj }),
      el("td", null, [el("div", { text: c.name || "" }), c.trade_name ? el("div", { class: "sub", text: c.trade_name }) : null, tr.exportTag]),
      el("td", null, [el("div", { text: (c.city || c.city_code || "") + (c.state ? "/" + c.state : "") }), el("div", { class: "sub", text: c.neighborhood || "" })]),
      el("td", { class: "mono", text: c.cnae || "" }),
      el("td", null, [el("div", { text: c.phone || "" }), el("div", { class: "sub", text: c.email || "" })]),
      el("td", { text: c.status || "" }),
      el("td", null, [el("button", { class: "btn ghost sm", type: "button", text: "Detalhes", "aria-label": "Detalhes de " + c.cnpj, onclick: function () { details(c.cnpj); } })])
    ].forEach(function (td) { tr.appendChild(td); });
    return tr;
  }
  function refreshExportTags() {
    var rows = Array.from($("results").querySelectorAll("tr")).filter(function (tr) { return tr.cnpj; });
    for (var i = 0; i < rows.length; i += 500) {
      (function (batch) {
        api("/api/export-status", { cnpjs: batch.map(function (tr) { return tr.cnpj; }) }).then(function (r) {
          var exported = new Set(r.exported || []);
          batch.forEach(function (tr) { if (tr.isConnected) tr.exportTag.hidden = !exported.has(tr.cnpj); });
        }).catch(function (e) { if (!e.locked) showErr("Não foi possível atualizar as marcações de exportação: " + e.message); });
      })(rows.slice(i, i + 500));
    }
  }
  function updateSel() {
    selectionVersion++;
    $("selCount").textContent = allSelected ? "Todo o resultado: " + fmtN(allCount) + " selecionadas" : fmtN(selected.size) + " selecionadas";
    $("expSelN").textContent = "(" + (allSelected ? fmtN(allCount) : fmtN(selected.size)) + ")";
  }
  $("selAll").addEventListener("click", function (event) {
    if (!applied || !searchReady) return showErr("Conclua a consulta antes de selecionar todos.");
    var version = searchRequest, selection = selectionVersion, b = event.currentTarget; b.disabled = true;
    api("/api/selection-count", { job_id: applied.job_id, filters: applied }).then(function (r) {
      if (version !== searchRequest || selection !== selectionVersion) return;
      allSelected = true; allCount = r.count; selected.clear(); updateSel();
      $("results").querySelectorAll("tr").forEach(function (tr) { if (tr.cb) { tr.cb.checked = true; tr.cb.disabled = true; tr.className = "sel"; } });
      workspaceMessage("Todas as " + fmtN(allCount) + " empresas do resultado estão selecionadas, inclusive as não exibidas. Use Limpar seleção para voltar à marcação individual.");
    }).catch(softErr).finally(function () { b.disabled = false; });
  });
  $("selPage").addEventListener("click", function () {
    if (!searchReady || allSelected) return;
    $("results").querySelectorAll("tr").forEach(function (tr) {
      if (tr.cb && !tr.cb.checked && selected.size < 3000) { tr.cb.checked = true; selected.set(tr.cnpj, true); tr.className = "sel"; }
    });
    updateSel();
  });
  $("selClear").addEventListener("click", function () {
    allSelected = false; selected.clear(); $("results").querySelectorAll("tr").forEach(function (tr) { if (tr.cb) { tr.cb.disabled = false; tr.cb.checked = false; tr.className = ""; } }); updateSel();
  });

  // ---- details ----
  function kv(obj) {
    var dl = el("dl");
    Object.keys(obj || {}).forEach(function (k) {
      var v = obj[k]; if (v !== null && typeof v === "object") v = JSON.stringify(v);
      dl.appendChild(el("dt", { text: k })); dl.appendChild(el("dd", { text: v == null ? "" : String(v) }));
    });
    return dl;
  }
  function details(cnpj) {
    if (!applied) return;
    var d = $("detail"), b = clear($("detailBody"));
    $("detailTitle").textContent = "CNPJ " + cnpj;
    b.appendChild(el("div", { class: "sk" }));
    if (!d.open) d.showModal();
    api("/api/company?job_id=" + encodeURIComponent(applied.job_id) + "&cnpj=" + encodeURIComponent(cnpj)).then(function (r) {
      if (!authed) return;
      clear(b);
      b.appendChild(kv(r.fields));
      b.appendChild(el("h3", { text: "Sócios (" + (r.partners || []).length + ")" }));
      if (!(r.partners || []).length) b.appendChild(el("p", { class: "muted", text: "Nenhum sócio registrado." }));
      (r.partners || []).forEach(function (p) { b.appendChild(el("div", { class: "partner" }, [kv(p)])); });
    }).catch(function (e) { clear(b); if (!e.locked) inlineErr(b, e.message); });
  }
  $("detailClose").addEventListener("click", function () { $("detail").close(); });

  // ---- export ----
  function openBtn(id, size) {
    return el("button", { class: "btn open " + (size || ""), type: "button", text: "Abrir planilha", onclick: function (ev) {
      var b = ev.currentTarget; b.disabled = true;
      api("/api/open-export", { id: id }).then(function () { b.disabled = false; })
        .catch(function (e) { b.disabled = false; softErr(e); });
    } });
  }
  function exportBody(what, policy) {
    var f = applied;
    var filters = Object.assign({}, f);
    return { job_id: f.job_id, filters: filters, selected: what === "selected" && !allSelected ? Array.from(selected.keys()) : [], format: $("fmt").value, include_partners: $("partners").checked, duplicate_policy: policy, output_dir: $("outDir").value.trim() };
  }
  function startExport(what) {
    if (status && status.running) return;
    var queryVersion = searchRequest;
    var selectionKey = allSelected + ":" + Array.from(selected.keys()).sort().join(",");
    function changed() {
      return queryVersion !== searchRequest || (what === "selected" && selectionKey !== allSelected + ":" + Array.from(selected.keys()).sort().join(","));
    }
    var out = clear($("dupOut"));
    if (!applied) return inlineErr(out, "Aplique uma pesquisa antes de exportar.");
    var body = exportBody(what, "ask");
    if (what === "selected" && !allSelected && !body.selected.length) return inlineErr(out, "Nenhuma empresa marcada. Use as caixas na tabela ou \"Selecionar todo o resultado\".");
    if (!searchReady) return inlineErr(out, "Aguarde a pesquisa concluir com sucesso antes de exportar.");
    if (!body.output_dir) { $("outDir").focus(); return inlineErr(out, "Informe a pasta de saída."); }
    out.appendChild(el("div", { class: "sk" }));
    api("/api/export", body).then(function (r) {
      if (changed()) return;
      clear(out);
      var title = what === "selected" ? "Marcadas para Excel" : "Resultado para Excel";
      var box = el("div", { class: "dup" }, [
        el("p", { class: "dup-t", text: title + " · " + String(body.format).toUpperCase() }),
        el("p", { class: "muted", text: "Destino confirmado: " + body.output_dir }),
        el("p", null, [el("strong", { text: fmtN(r.matching) }), " empresas correspondem; ", el("strong", { text: fmtN(r.duplicates) }), " já foram exportadas antes."]),
        el("div", { class: "row" }, [
          el("button", { class: "btn primary", type: "button", text: "Exportar todas (repetir)", onclick: function () { go("all"); } }),
          el("button", { class: "btn warn", type: "button", disabled: !r.duplicates || r.duplicates >= r.matching, text: "Ignorar já exportadas", onclick: function () { go("skip"); } }),
          el("button", { class: "btn ghost", type: "button", text: "Cancelar", onclick: function () { clear(out); } })
        ])
      ]);
      out.appendChild(box);
      box.querySelector(".btn.primary").focus();
      function go(policy) {
        if (changed()) return inlineErr(out, "A consulta ou seleção mudou. Verifique a exportação novamente.");
        box.querySelectorAll("button").forEach(function (b) { b.disabled = true; });
        $("xAll").disabled = true; $("xSel").disabled = true;
        api("/api/export", Object.assign({}, body, { duplicate_policy: policy })).then(function () {
          lastExport = null;
          clear(out).appendChild(el("p", { class: "ok", text: "Exportação iniciada. O arquivo será gravado em " + body.output_dir + "." }));
          poll1();
        }).catch(function (e) {
          clear(out);
          if (!e.locked) inlineErr(out, e.message);
          poll1();
        });
      }
    }).catch(function (e) { clear(out); if (!e.locked) inlineErr(out, e.message); });
  }
  function renderExportDone() {
    var out = $("dupOut");
    if (!lastExport) return;
    clear(out).appendChild(el("div", { class: "done" }, [
      el("div", null, [el("strong", { text: "Planilha pronta" }), el("div", { class: "pathtxt", text: lastExport.path }),
        el("div", { class: "muted", text: fmtN(lastExport.companies) + " empresas · " + fmtN(lastExport.rows) + " linhas · " + String(lastExport.format || "").toUpperCase() })]),
      lastExport.id != null ? openBtn(lastExport.id) : null
    ]));
  }
  $("xAll").addEventListener("click", function () { startExport("filter"); });
  $("xSel").addEventListener("click", function () { startExport("selected"); });
  $("outDir").addEventListener("input", function () { autoOutDir = ""; });

  // ---- history ----
  function loadHistory() {
    if (!authed) return;
    var h = clear($("history"));
    h.appendChild(el("div", { class: "sk" }));
    api("/api/history").then(function (r) {
      clear(h);
      if (!(r.items || []).length) return h.appendChild(el("div", { class: "emptybox" }, [el("strong", { text: "Nenhuma exportação feita ainda." }), el("span", { text: "As planilhas geradas aparecem aqui, com o caminho no disco." })]));
      var list = el("div", { class: "hist" });
      r.items.forEach(function (i) {
        list.appendChild(el("div", null, [el("span", { text: i.created_at || "" }), el("span", { class: "p", text: i.path || "" }), el("span", { class: "fmt", text: String(i.format || "").toUpperCase() }), el("span", { text: fmtN(i.companies) + " empresas · " + fmtN(i.rows) + " linhas" }), i.id != null && i.path ? openBtn(i.id, "sm") : null]));
      });
      h.appendChild(list);
    }).catch(function (e) { clear(h); if (e.locked) return; inlineErr(h, e.message); h.appendChild(el("button", { class: "btn sm", type: "button", text: "Tentar novamente", onclick: loadHistory })); });
  }
  $("histRefresh").addEventListener("click", loadHistory);

  // ================= AUTH =================
  function copyText(t, btn) {
    if (!navigator.clipboard || !t) return;
    navigator.clipboard.writeText(t).then(function () { btn.textContent = "Copiado"; setTimeout(function () { btn.textContent = "Copiar"; }, 1600); }).catch(function () {});
  }
  var team = window.LocalAccounts ? window.LocalAccounts({ api: api, el: el, clear: clear, copyText: copyText, getMe: function () { return me; }, refreshMe: function () { checkAuth(); } }) : null;

  var panes = ["authLoading", "fSetup", "fLogin", "fMigrate", "fForce", "fForgot", "fReset", "fRecover", "recoveryPane", "resetDone", "authFatal"];
  var authMode = "", afterAck = null;
  function showPane(id) {
    authMode = id;
    panes.forEach(function (p) { $(p).hidden = p !== id; });
    document.querySelectorAll("#auth .auth-err").forEach(function (x) { x.hidden = true; x.textContent = ""; });
    var first = $(id).querySelector("input:not([type=checkbox]):not([hidden]), button");
    if (first && id !== "authLoading") setTimeout(function () { if (!first.closest("[hidden]")) first.focus(); }, 30);
  }
  function formErr(form, msg) { var x = form.querySelector(".auth-err"); x.textContent = msg; x.hidden = !msg; }
  function wipePasswords() { document.querySelectorAll("input[type=password]").forEach(function (i) { i.value = ""; }); $("rcCode").value = ""; $("rsToken").value = ""; }
  function flash(msg) { var f = $("flash"); f.textContent = msg; f.hidden = !msg; if (msg) setTimeout(function () { if (f.textContent === msg) f.hidden = true; }, 6000); }

  function applyRole() {
    var adm = isAdmin();
    document.querySelectorAll(".admin-only").forEach(function (n) { n.hidden = !adm; });
    document.querySelectorAll(".user-only").forEach(function (n) { n.hidden = adm; });
    $("userNote").hidden = adm || !authed;
    if (me) {
      $("whoName").textContent = me.name || me.email;
      $("whoMeta").textContent = me.email + " · " + (adm ? "Administrador" : "Usuário");
      $("whoInit").textContent = String(me.name || me.email || "?").trim().split(/\s+/).slice(0, 2).map(function (w) { return w.charAt(0).toUpperCase(); }).join("");
      $("who").className = "who " + (adm ? "admin" : "user");
    } else { $("whoName").textContent = ""; $("whoMeta").textContent = ""; $("whoInit").textContent = ""; }
    $("chHint").textContent = adm ? "Todas as outras sessões desta conta serão encerradas e um novo código de emergência será gerado." : "Todas as outras sessões desta conta serão encerradas.";
  }

  function lockUI() {
    authed = false; authGeneration++; stopPoll();
    if ($("detail").open) $("detail").close();
    clear($("detailBody")); $("detailTitle").textContent = "Detalhes";
    if ($("changeDlg").open) $("changeDlg").close();
    resetChange();
    if (!$("rememberEmail").checked) $("liEmail").value = "";
    if (team) team.reset();
    applied = null; searchReady = false; searchRequest++; selected.clear(); pageItems = []; nextAfter = null; lastExport = null; lastTaskKey = "";
    resetSearchProgress();
    workspaceGeneration++;
    libraryItems = [];
    ["cityGroups", "savedResults", "resultCity", "resultCnae"].forEach(function (id) { clear($(id)).appendChild(el("option", { value: "", text: "Escolha uma opção" })); });
    $("cityGroupName").value = ""; $("resultName").value = ""; workspaceMessage("");
    status = null; jobsCache = [];
    clear($("exportProgress"));
    clear($("results")).appendChild(el("tr", null, [el("td", { colspan: 8, class: "empty", text: "Selecione uma base e aplique os filtros." })]));
    $("more").hidden = true;
    ["dupOut", "history", "jobs", "inspectOut", "taskBar"].forEach(function (id) { clear($(id)); });
    clear($("jobSel")).appendChild(el("option", { value: "", text: "Nenhuma base concluída" }));
    $("sNeigh").value = ""; $("sText").value = ""; $("sState").value = "MG"; $("sActive").checked = true;
    sCities.reset(); sCnaes.reset(); impCities.reset(); impCnaes.reset(); clearRules();
    fieldMeta = null; fieldById = {};
    ["dataDir", "sourceDir", "outDir", "period"].forEach(function (id) { $(id).value = ""; });
    autoOutDir = "";
    $("pendingNote").hidden = true; $("dataInfo").textContent = "";
    // segredos exibidos uma vez
    $("recoveryCode").textContent = ""; $("ackCode").checked = false; afterAck = null;
    wipePasswords();
    me = null; applyRole();
    updateSel(); showErr(""); flash("");
    $("app").hidden = true; $("auth").hidden = false;
  }
  function unlockUI() {
    authed = true; wipePasswords();
    $("auth").hidden = true; $("app").hidden = false;
    applyRole();
    $("history").textContent = "Configure a pasta de dados para consultar o histórico local.";
    loadFields(); stopPoll(); poll();
    if (isAdmin() && team) team.load();
    if (isAdmin() && window.desktop && window.desktop.checkUpdates) {
      window.desktop.checkUpdates(getSession(), false).catch(function () { /* sem internet: acesso local continua disponível */ });
    }
    $("main").focus({ preventScroll: true });
  }

  var rememberEmailLoaded = false;
  function routeStatus(s) {
    if (!rememberEmailLoaded) {
      rememberEmailLoaded = true;
      $("rememberEmail").checked = !!s.remembered_email;
      if (!$("liEmail").value && s.remembered_email && !s.legacy) $("liEmail").value = s.remembered_email;
    }
    $("rememberEmailRow").hidden = !!s.legacy;
    $("liLegacy").hidden = !s.legacy; $("rcLegacy").hidden = !s.legacy;
    $("liEmail").required = !s.legacy; $("rcEmail").required = !s.legacy;
    $("goForgot").hidden = !s.email_recovery_available || !!s.legacy;
    $("noMailNote").hidden = !!s.email_recovery_available || !!s.legacy;
    $("goResetCode").hidden = !!s.legacy;
    if (s.authenticated) {
      var u = s.user || null;
      if (s.migration_required) { if (authed) lockUI(); me = u; showPane("fMigrate"); return; }
      if (s.must_change_password || (u && u.must_change_password)) {
        if (authed) lockUI(); me = u;
        $("forceWho").textContent = u ? (u.name || "") + " · " + u.email : "";
        showPane("fForce"); return;
      }
      var changed = me && u && (me.id !== u.id || me.role !== u.role);
      if (changed && authed) lockUI();
      me = u;
      if (!authed) unlockUI(); else applyRole();
      return;
    }
    if (authed || $("auth").hidden) lockUI();
    me = null;
    if (authMode === "recoveryPane" || authMode === "resetDone" || authMode === "fReset" || authMode === "fForgot") return;
    showPane(s.configured || s.legacy ? (authMode === "fRecover" ? "fRecover" : "fLogin") : "fSetup");
    if (s.retry_after) retryNote(s.retry_after);
  }
  var checking = null;
  function checkAuth() {
    if (locking) return Promise.resolve();
    if (checking) return checking;
    if (!authMode || $("auth").hidden) showPane("authLoading");
    checking = api("/api/auth/status").then(function (s) {
      checking = null; if (!locking) routeStatus(s);
      if (window.desktop && window.desktop.ready) window.desktop.ready().catch(function () {});
    }).catch(function (e) {
      checking = null;
      if (e.locked) { if (!locking) return checkAuth(); return; }
      if (authed) lockUI();
      showPane("authFatal");
      $("authFatalMsg").textContent = "O servidor local não respondeu (" + e.message + ")." + (TOKEN ? "" : " Token ausente: abra o programa pelo atalho ou link exibido ao iniciar.");
    });
    return checking;
  }
  function onUnauthorized() {
    dropSession();
    if (authed) lockUI();
    if (authMode !== "recoveryPane") { authMode = ""; showPane("authLoading"); }
    checkAuth();
  }
  function retryNote(sec) {
    var f = $(authMode); if (!f || f.tagName !== "FORM") return;
    formErr(f, "Muitas tentativas. Aguarde " + Math.ceil(sec) + " segundos antes de tentar de novo.");
  }
  function authSubmit(form, path, body, after) {
    var btn = form.querySelector("button[type=submit]"); btn.disabled = true; formErr(form, "");
    return api(path, body).then(function (r) {
      btn.disabled = false;
      if (r && r.session_token) setSession(r.session_token); // guardar antes de consultar status
      wipePasswords(); after(r || {});
    }).catch(function (e) {
      btn.disabled = false;
      form.querySelectorAll("input[type=password]").forEach(function (input) { input.value = ""; });
      if (e.locked) return;
      var ra = e.data && e.data.retry_after;
      formErr(form, ra ? "Muitas tentativas. Aguarde " + Math.ceil(ra) + " segundos." : e.message);
    });
  }
  function pwCheck(form, p, c) {
    if (p.length < 10 || p.length > 128) { formErr(form, "A senha precisa ter de 10 a 128 caracteres."); return false; }
    if (p !== c) { formErr(form, "As duas senhas não são iguais."); return false; }
    return true;
  }
  function showRecovery(code, next) {
    if (!code) { next(); return; }
    afterAck = next;
    $("recoveryCode").textContent = code; $("ackCode").checked = false; $("ackGo").disabled = true;
    showPane("recoveryPane");
  }
  function continueAuth() { authMode = ""; checkAuth(); }
  function toLogin() { wipePasswords(); resetToken = ""; authMode = "fLogin"; showPane("fLogin"); checkAuth(); }

  $("fSetup").addEventListener("submit", function (e) {
    e.preventDefault(); var f = e.currentTarget, p = $("suPass").value, c = $("suConf").value;
    if (!pwCheck(f, p, c)) return;
    authSubmit(f, "/api/auth/setup", { name: $("suName").value.trim(), email: $("suEmail").value.trim(), password: p, confirmation: c }, function (r) {
      $("suName").value = ""; $("suEmail").value = ""; showRecovery(r.recovery_code, continueAuth);
    });
  });
  $("fLogin").addEventListener("submit", function (e) {
    e.preventDefault(); var f = e.currentTarget;
    authSubmit(f, "/api/auth/login", { email: $("liEmail").value.trim(), password: $("liPass").value,
      remember_email: $("rememberEmail").checked }, function (r) {
        continueAuth();
        if (r.preference_error) showErr(r.preference_error);
      });
  });
  $("rememberEmail").addEventListener("change", function () {
    if ($("rememberEmail").checked) return; // Persist only after a successful login.
    api("/api/auth/forget-email", {}).catch(function (e) {
      if (!e.locked) {
        $("rememberEmail").checked = true;
        formErr($("fLogin"), "Não foi possível esquecer o e-mail. Tente desmarcar novamente. " + e.message);
      }
    });
  });
  $("fMigrate").addEventListener("submit", function (e) {
    e.preventDefault(); var f = e.currentTarget;
    authSubmit(f, "/api/auth/migrate", { name: $("mgName").value.trim(), email: $("mgEmail").value.trim(), current_password: $("mgPass").value }, function (r) {
      $("mgName").value = ""; $("mgEmail").value = ""; showRecovery(r.recovery_code, continueAuth);
    });
  });
  $("fForce").addEventListener("submit", function (e) {
    e.preventDefault(); var f = e.currentTarget, p = $("fcPass").value, c = $("fcConf").value;
    if (!pwCheck(f, p, c)) return;
    if (p === $("fcCur").value) { formErr(f, "A nova senha precisa ser diferente da temporária."); return; }
    authSubmit(f, "/api/auth/change", { current_password: $("fcCur").value, password: p, confirmation: c }, function (r) { showRecovery(r.recovery_code, continueAuth); });
  });
  $("fRecover").addEventListener("submit", function (e) {
    e.preventDefault(); var f = e.currentTarget, p = $("rcPass").value, c = $("rcConf").value;
    if (!pwCheck(f, p, c)) return;
    authSubmit(f, "/api/auth/recover", { email: $("rcEmail").value.trim(), recovery_code: $("rcCode").value.trim(), password: p, confirmation: c }, function (r) {
      $("rcEmail").value = ""; showRecovery(r.recovery_code, continueAuth);
    });
  });
  $("fForgot").addEventListener("submit", function (e) {
    e.preventDefault(); var f = e.currentTarget; $("fgOk").hidden = true;
    authSubmit(f, "/api/auth/request-reset", { email: $("fgEmail").value.trim() }, function (r) {
      $("fgOk").textContent = (r.message || "Se a conta existir, o e-mail será enviado em instantes.") + " Confira também a caixa de spam.";
      $("fgOk").hidden = false;
    });
  });
  function openReset() {
    var fromLink = !!resetToken;
    $("rsLinkNote").hidden = !fromLink; $("rsCodeLead").hidden = fromLink; $("rsTokenWrap").hidden = fromLink;
    $("rsToken").required = !fromLink; $("rsToken").value = "";
    showPane("fReset");
  }
  $("fReset").addEventListener("submit", function (e) {
    e.preventDefault(); var f = e.currentTarget, p = $("rsPass").value, c = $("rsConf").value;
    var tok = resetToken || $("rsToken").value.trim();
    if (!tok) { formErr(f, "Cole o código recebido por e-mail."); return; }
    if (!pwCheck(f, p, c)) return;
    authSubmit(f, "/api/auth/reset-password", { token: tok, password: p, confirmation: c }, function (r) {
      resetToken = ""; tok = ""; dropSession();
      if (authed) lockUI();
      showRecovery(r.recovery_code, function () { showPane("resetDone"); });
    });
  });
  $("goForgot").addEventListener("click", function () { wipePasswords(); $("fgOk").hidden = true; $("fgEmail").value = $("liEmail").value.trim(); showPane("fForgot"); });
  $("fgToCode").addEventListener("click", function () { resetToken = ""; openReset(); });
  $("goResetCode").addEventListener("click", function () { wipePasswords(); resetToken = ""; openReset(); });
  $("goRecover").addEventListener("click", function () { wipePasswords(); showPane("fRecover"); });
  document.querySelectorAll("[data-to-login]").forEach(function (b) { b.addEventListener("click", toLogin); });
  document.querySelectorAll("[data-auth-exit]").forEach(function (b) { b.addEventListener("click", doLock); });
  $("ackCode").addEventListener("change", function () { $("ackGo").disabled = !$("ackCode").checked; });
  $("ackGo").addEventListener("click", function () {
    $("recoveryCode").textContent = ""; $("ackCode").checked = false;
    var next = afterAck || continueAuth; afterAck = null; authMode = ""; next();
  });
  $("authRetry").addEventListener("click", function () { authMode = ""; checkAuth(); });
  $("copyCode").addEventListener("click", function (e) { copyText($("recoveryCode").textContent, e.currentTarget); });

  var locking = false;
  function doLock() {
    if (locking) return; locking = true;
    var had = !!getSession();
    lockUI(); showPane("authLoading");
    (had ? api("/api/auth/logout", {}) : Promise.resolve()).catch(function () {}).then(function () {
      dropSession(); locking = false; authMode = ""; checkAuth();
    });
  }
  $("btnLock").addEventListener("click", doLock);
  if (window.desktop && typeof window.desktop.onLock === "function") {
    try { window.desktop.onLock(function () { doLock(); }); } catch (e) { /* shell sem suporte */ }
  }
  if (window.desktop && window.desktop.onUpdates) {
    window.desktop.onUpdates(function () { window.desktop.checkUpdates(getSession(), true).catch(softErr); });
    window.desktop.onRollback(function () { window.desktop.rollback(getSession()).catch(softErr); });
    setInterval(function () {
      if (authed && isAdmin()) window.desktop.checkUpdates(getSession(), false).catch(function () {});
    }, 6 * 60 * 60 * 1000);
  }

  // change password (dentro do app)
  var changeNeedsAck = false;
  function resetChange() {
    changeNeedsAck = false; $("fChange").hidden = false; $("changeDone").hidden = true;
    $("chCode").textContent = ""; $("chAck").checked = false; $("chAckGo").disabled = true;
    formErr($("fChange"), ""); ["chCur", "chPass", "chConf"].forEach(function (id) { $(id).value = ""; });
  }
  $("btnChange").addEventListener("click", function () { resetChange(); $("changeDlg").showModal(); $("chCur").focus(); });
  $("changeClose").addEventListener("click", function () { if (!changeNeedsAck) { $("changeDlg").close(); resetChange(); } else $("chAck").focus(); });
  $("changeDlg").addEventListener("cancel", function (e) { if (changeNeedsAck) e.preventDefault(); else resetChange(); });
  $("fChange").addEventListener("submit", function (e) {
    e.preventDefault(); var f = e.currentTarget, p = $("chPass").value, c = $("chConf").value;
    if (!pwCheck(f, p, c)) return;
    if (p === $("chCur").value) { formErr(f, "A nova senha precisa ser diferente da atual."); return; }
    authSubmit(f, "/api/auth/change", { current_password: $("chCur").value, password: p, confirmation: c }, function (r) {
      if (r.recovery_code) {
        changeNeedsAck = true; $("fChange").hidden = true; $("changeDone").hidden = false;
        $("chCode").textContent = r.recovery_code; $("chAck").focus();
      } else { $("changeDlg").close(); resetChange(); flash("Senha alterada. Outras sessões desta conta foram encerradas."); }
    });
  });
  $("chAck").addEventListener("change", function () { $("chAckGo").disabled = !$("chAck").checked; });
  $("chAckGo").addEventListener("click", function () { changeNeedsAck = false; $("changeDlg").close(); resetChange(); flash("Senha alterada. Novo código de emergência guardado."); });
  $("chCopy").addEventListener("click", function (e) { copyText($("chCode").textContent, e.currentTarget); });

  // No idle lock in the local program. Status polling still validates the
  // session server-side; manual lock and account revocations remain effective.

  applyRole();
  if (resetToken) { $("auth").hidden = false; openReset(); } // reset tem prioridade e nunca libera dados
  else checkAuth();
})();
