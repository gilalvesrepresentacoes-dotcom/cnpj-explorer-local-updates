"use strict";
(function (root) {
  var PHASES = {
    reading: "Descompactando e lendo o arquivo",
    writing: "Gravando os registros no banco local",
    rereading: "Relendo até o ponto salvo para retomar com segurança"
  };
  function number(v) { return typeof v === "number" && Number.isFinite(v) && v >= 0 ? v : 0; }
  function describe(job, task, running) {
    var match = task && task.kind === "import" && task.job_id === job.id;
    var live = !!(match && running && task.status === "running" && (job.status === "running" || job.status === "queued"));
    var p = match && task.progress, volume = !!(p && p.basis === "uncompressed_bytes" && number(p.bytes_total) > 0);
    var ratio = volume ? number(p.bytes_done) / p.bytes_total : (number(job.total_files) ? number(job.file_index) / job.total_files : 0);
    var percent = job.status === "completed" ? 100 : Math.max(0, Math.min(99.9, ratio * 100));
    // Never round 99.99 to 100 before the transaction finishes successfully.
    percent = job.status === "completed" ? 100 : Math.floor(percent * 10) / 10;
    var state = live ? "Processando" : ({ completed: "Concluído", paused: "Pausado", failed: "Interrompido", queued: "Na fila" }[job.status] || "Aguardando confirmação do processo");
    var phase = live ? (PHASES[p && p.phase] || "Preparando a leitura dos ZIPs") :
      ({ completed: "Base pronta para consultar e exportar.", paused: "O processo está parado. Use Retomar para continuar.", failed: "O processo foi interrompido. Confira o erro antes de retomar." }[job.status] || "Aguardando início ou nova confirmação do serviço local.");
    var age = p && number(p.sampled_at) ? Math.max(0, Math.floor(Date.now() / 1000 - p.sampled_at)) : null;
    return {
      live: live, percent: percent, label: percent.toFixed(1).replace(".", ",") + "%",
      state: state, phase: phase, volume: volume,
      file: job.status === "completed" ? "" : ((p && p.current_file) || job.current_file || ""),
      filePercent: job.status !== "completed" && volume && number(p.file_bytes_total) ? Math.min(100, Math.floor(number(p.file_bytes_done) / p.file_bytes_total * 1000) / 10) : null,
      doneBytes: volume ? (job.status === "completed" ? p.bytes_total : number(p.bytes_done)) : 0, totalBytes: volume ? p.bytes_total : 0,
      age: age,
      basis: volume ? "Percentual do volume descompactado lido; não é uma estimativa de tempo nem de registros já salvos." :
        "Percentual dos arquivos concluídos. A medição do volume aparece quando a leitura é iniciada."
    };
  }
  function render(ctx, job, task, running, compact) {
    var el = ctx.el, n = describe(job, task, running);
    var bar = el("div", { class: "import-progress-track", role: "progressbar",
      "aria-label": "Progresso do processamento de " + job.period,
      "aria-valuemin": "0", "aria-valuemax": "100", "aria-valuenow": String(n.percent),
      "aria-valuetext": n.label + " — " + n.state + ". " + n.basis
    }, [el("i", { "aria-hidden": "true" })]);
    bar.firstChild.style.transform = "scaleX(" + n.percent / 100 + ")";
    var detail = n.phase + (n.file ? " — " + n.file : "");
    var kids = [
      el("div", { class: "import-progress-head" }, [
        el("span", { class: "import-progress-state" }, [
          el("span", { class: "import-progress-dot", "aria-hidden": "true" }),
          el("strong", { class: "import-progress-label", text: n.state })
        ]),
        el("strong", { class: "import-progress-percent", text: n.label })
      ]),
      bar,
      el("div", { class: "import-progress-phase", text: detail })
    ];
    if (!compact) {
      if (n.volume) kids.push(el("div", { class: "meta", text:
        ctx.fmtSize(n.doneBytes) + " de " + ctx.fmtSize(n.totalBytes) + " lidos" +
        (n.filePercent == null ? "" : " · ZIP atual: " + n.filePercent.toFixed(1).replace(".", ",") + "%")
      }));
      if (n.live && n.age !== null) kids.push(el("div", { class: "meta", text: n.age < 10 ?
        "Leitura ou gravação atualizada há poucos segundos." :
        "Última medição há " + n.age + " s. O processo segue ativo; pode estar gravando no HD ou lendo o ZIP."
      }));
      kids.push(el("div", { class: "import-progress-note", text: n.basis }));
    }
    var box = el("div", { class: "import-progress" + (n.live ? " is-running" : "") }, kids);
    box.progressReceivedAt = Date.now();
    return box;
  }
  function offline(doc) {
    doc.querySelectorAll(".import-progress.is-running").forEach(function (box) {
      box.classList.remove("is-running");
      box.querySelector(".import-progress-label").textContent = "Sem confirmação do serviço local";
      box.querySelector(".import-progress-phase").textContent = "Aguardando reconexão. O percentual exibido é a última leitura recebida.";
    });
  }
  function expire(doc) {
    doc.querySelectorAll(".import-progress.is-running").forEach(function (box) {
      if (Date.now() - box.progressReceivedAt <= 12000) return;
      box.classList.remove("is-running");
      box.querySelector(".import-progress-label").textContent = "Aguardando atualização do serviço";
      box.querySelector(".import-progress-phase").textContent = "Sem nova resposta há mais de 12 s. O serviço pode estar ocupado; o percentual não será simulado.";
    });
  }
  var api = { describe: describe, render: render, offline: offline, expire: expire };
  if (typeof module === "object" && module.exports) module.exports = api;
  else {
    root.LocalImportProgress = api;
    root.setInterval(function () { expire(root.document); }, 2000);
  }
})(typeof window === "object" ? window : {});
