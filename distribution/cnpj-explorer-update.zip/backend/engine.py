"""Leitura sequencial de ZIPs locais, transações e pontos de recuperação."""
import csv
import hashlib
import io
import json
import re
import shutil
import threading
import time
import uuid
import zipfile
from datetime import datetime, timezone
from pathlib import Path

from fields import LAYOUTS, REFERENCE_NAMES
from store import codes, dumps, normalized

BATCH = 4000
MIN_FREE = 512 * 1024 * 1024
csv.field_size_limit(4 * 1024 * 1024)


def now():
    return datetime.now(timezone.utc).isoformat()


class Paused(Exception):
    pass


class Cancelled(Paused):
    pass


def classified(name):
    stem = Path(name).stem.lower()
    for reference in REFERENCE_NAMES:
        if stem == reference.lower() or (reference == "Cnaes" and stem == "cnae"):
            return reference + ".zip", "reference", 0
    for prefix, kind, order in (("estabelecimentos", "establishments", 1),
                                ("empresas", "companies", 2), ("socios", "partners", 3)):
        found = re.fullmatch(prefix + r"(\d)", stem)
        if found:
            return prefix.capitalize() + found[1] + ".zip", kind, order
    if stem == "simples":
        return "Simples.zip", "simple", 4
    return None


def manifest(source_dir):
    root = Path(source_dir).expanduser()
    if root.is_file() or root.suffix.lower() == ".zip":
        raise ValueError("Foi indicado um arquivo ZIP. Escolha a pasta que contém todos os ZIPs da competência, não o arquivo.")
    if not root.is_absolute() or not root.is_dir():
        raise ValueError("Informe uma pasta absoluta existente com os ZIPs de uma competência.")
    files, warnings, found = [], [], set()
    for path in root.iterdir():
        if not path.is_file() or path.suffix.lower() != ".zip":
            continue
        info = classified(path.name)
        if not info:
            if re.search(r"(empresas|estabelecimentos|socios|cnaes?|simples|municipios)", path.stem, re.I):
                warnings.append(f"Nome ambíguo: {path.name}. Separe os meses e use os nomes oficiais, sem sufixos de cópia.")
            continue
        canonical, kind, order = info
        if canonical in found:
            raise ValueError("Dois arquivos correspondem a " + canonical + ". Separe as competências.")
        found.add(canonical)
        stat = path.stat()
        try:
            with zipfile.ZipFile(path) as z:
                members = [m for m in z.infolist() if not m.is_dir()]
                if not members or any(m.flag_bits & 1 for m in members):
                    raise ValueError("ZIP vazio ou protegido por senha: " + path.name)
                signature = dumps([(m.filename, m.CRC, m.file_size) for m in members])
        except zipfile.BadZipFile as error:
            raise ValueError("ZIP inválido/incompleto: " + path.name) from error
        files.append({"name": canonical, "path": str(path.resolve()), "kind": kind, "order": order,
                      "size": stat.st_size, "mtime": stat.st_mtime_ns,
                      "signature": hashlib.sha256(signature.encode()).hexdigest()})
    required = {r + ".zip" for r in REFERENCE_NAMES} | {"Simples.zip"}
    required |= {prefix + str(i) + ".zip" for prefix in ("Estabelecimentos", "Empresas", "Socios") for i in range(10)}
    return sorted(files, key=lambda f: (f["order"], f["name"])), sorted(required - found), warnings


def uncompressed_size(file):
    # Central-directory metadata only: never decompress a ZIP just to count it.
    with zipfile.ZipFile(file["path"]) as z:
        return sum(m.file_size for m in z.infolist() if not m.is_dir())


def csv_rows(file, meter=None):
    # No extractall: zip-slip paths never reach the filesystem. Memory is bounded
    # to the decompressor and csv field limit. ZipFile verifies member CRC at EOF.
    with zipfile.ZipFile(file["path"]) as z:
        if meter is not None:
            meter.update(done=0, stream=None)
        for member in z.infolist():
            if member.is_dir():
                continue
            with z.open(member) as raw, io.TextIOWrapper(raw, encoding="latin1", newline="") as text:
                if meter is not None:
                    meter["stream"] = raw
                for row in csv.reader(text, delimiter=";", strict=True):
                    if row:
                        yield row
            if meter is not None:
                meter["done"] += member.file_size
                meter["stream"] = None


def inspect(source):
    files, missing, warnings = manifest(source)
    references = {"cnaes": [], "cities": []}
    for file in files:
        if file["name"] not in ("Cnaes.zip", "Municipios.zip"):
            continue
        key = "cnaes" if file["name"] == "Cnaes.zip" else "cities"
        for row in csv_rows(file):
            if len(row) != 2:
                raise ValueError("Layout desconhecido em " + file["name"])
            references[key].append({"code": row[0], "label": row[1]})
            if len(references[key]) > 100000:
                raise ValueError("Tabela auxiliar ultrapassa o tamanho esperado.")
    return {"files": [{k: f[k] for k in ("name", "kind", "size")} for f in files],
            "missing": missing, "warnings": warnings, "valid": not missing and not warnings, "references": references}


class Engine:
    def __init__(self, store):
        self.store = store
        self.lock = threading.RLock()
        self.stop = threading.Event()
        self.cancel_requested = threading.Event()
        self.task = None
        self.thread = None

    @property
    def running(self):
        return bool(self.thread and self.thread.is_alive())

    def launch(self, kind, action, job_id=None):
        with self.lock:
            if self.running:
                raise ValueError("Já existe uma tarefa em andamento. Aguarde ou pause.")
            self.stop.clear()
            self.cancel_requested.clear()
            self.task = {"kind": kind, "status": "running", "message": "Iniciando…"}
            if job_id:
                self.task["job_id"] = job_id

            def run():
                try:
                    result = action()
                    self.task.update(status="completed", message="Concluído.", result=result or {})
                except Cancelled:
                    self.task.update(status="cancelled", message="Processamento cancelado. ZIPs e outras bases preservados.")
                except Paused:
                    self.task.update(status="paused", message="Pausado. Os pontos já confirmados foram preservados.")
                except Exception as error:
                    self.task.update(status="failed", message=str(error))

            self.thread = threading.Thread(target=run, daemon=True)
            self.thread.start()

    def start(self, body):
        if self.running:
            raise ValueError("Aguarde a tarefa atual.")
        period, state, scope = str(body.get("period", "")), str(body.get("state", "")).upper(), body.get("scope")
        if not re.fullmatch(r"\d{4}-(0[1-9]|1[0-2])", period):
            raise ValueError("Informe uma competência válida (ano e mês).")
        if state not in "AC AL AP AM BA CE DF ES GO MA MT MS MG PA PB PR PE PI RJ RN RS RO RR SC SP SE TO".split():
            raise ValueError("Escolha uma UF válida.")
        if scope not in ("state", "selected"):
            raise ValueError("Escolha estado completo ou recorte selecionado.")
        cities = codes(body.get("cities", []), 4, "Municípios") if scope == "selected" else []
        cnaes = codes(body.get("cnaes", []), 7, "CNAEs") if scope == "selected" else []
        if scope == "selected" and not (cities or cnaes):
            raise ValueError("Selecione ao menos um município ou CNAE para preparar o recorte.")
        files, missing, warnings = manifest(body.get("source_dir", ""))
        if missing or warnings:
            raise ValueError("Conjunto incompleto ou ambíguo. " + "; ".join(missing + warnings))
        job = {"id": uuid.uuid4().hex, "period": period, "scope": scope, "state": state,
               "cities": cities, "cnaes": cnaes, "active_only": scope == "selected" and bool(body.get("active_only")),
               "status": "queued", "file_index": 0, "row_index": 0, "total_files": len(files),
               "current_file": "", "rows_scanned": 0, "rows_kept": 0, "created_at": now(),
               "error": "", "manifest": files, "source_dir": str(Path(body["source_dir"]).resolve()),
               "coverage": state + (" completo, todas as situações" if scope == "state" else " — recorte de municípios/CNAEs")}
        with self.store.session() as db:
            self.store.save(db, job)
        self.launch("import", lambda: self.process(job["id"]), job["id"])
        return {"id": job["id"]}

    def resume(self, ident):
        with self.lock:
            job = self.store.job(ident)
            if job["status"] not in ("failed", "paused"):
                raise ValueError("Somente bases pausadas ou com falha podem ser retomadas.")
            files, missing, warnings = manifest(job["source_dir"])
            if missing or warnings or files != job["manifest"]:
                raise ValueError("Os ZIPs foram alterados ou a pasta está incompleta. Reconecte a mesma pasta e mantenha os arquivos originais.")
            self.launch("import", lambda: self.process(ident), ident)
            return {"id": ident}

    def check_stop(self):
        if self.cancel_requested.is_set():
            raise Cancelled()
        if self.stop.is_set():
            raise Paused()

    def cancel(self, ident):
        with self.lock:
            job = self.store.job(ident)
            if job["status"] == "cancelled":
                return {"id": ident, "status": "cancelled"}
            if job["status"] not in ("running", "queued", "paused", "failed"):
                raise ValueError("Somente processamentos em andamento, pausados ou com falha podem ser cancelados.")
            if self.running:
                if not self.task or self.task.get("kind") != "import" or self.task.get("job_id") != ident:
                    raise ValueError("Há outra tarefa em andamento. Aguarde antes de cancelar esta base.")
                self.cancel_requested.set()
                self.stop.set()
                self.task["cancelling"] = True
                self.task["message"] = "Cancelando com segurança. Aguarde a gravação em andamento."
                return {"id": ident, "status": "cancelling"}
            with self.store.session() as db:
                job.update(status="cancelled", cancelled_at=now(), error="")
                self.store.save(db, job)
            return {"id": ident, "status": "cancelled"}

    def process(self, ident):
        db = self.store.connect()
        job = self.store.job(ident, db)
        cities, cnaes = set(job["cities"]), set(job["cnaes"])
        try:
            job.update(status="running", error="")
            self.store.save(db, job)
            db.commit()
            sizes = [uncompressed_size(f) for f in job["manifest"]]
            total_bytes = sum(sizes)
            last_progress = 0
            for index in range(job["file_index"], len(job["manifest"])):
                self.check_stop()
                file = job["manifest"][index]
                job["current_file"] = file["name"]
                self.task and self.task.update(message="Lendo " + file["name"])
                saved_row = job["row_index"]
                rows, last, last_saved = [], time.monotonic(), saved_row
                meter = {}
                completed_bytes = sum(sizes[:index])

                def report(phase, force=False):
                    nonlocal last_progress
                    if self.cancel_requested.is_set():
                        return  # Keep the acknowledgement visible until the writer stops.
                    if not self.task or (not force and time.monotonic() - last_progress < 1):
                        return
                    stream = meter.get("stream")
                    current = min(sizes[index], meter.get("done", 0) + (stream.tell() if stream else 0))
                    self.task["progress"] = {
                        "basis": "uncompressed_bytes", "bytes_done": completed_bytes + current,
                        "bytes_total": total_bytes, "file_bytes_done": current,
                        "file_bytes_total": sizes[index], "current_file": file["name"],
                        "phase": phase, "sampled_at": time.time(),
                    }
                    last_progress = time.monotonic()

                report("rereading" if saved_row else "reading", True)

                def flush(row_number):
                    nonlocal rows, last, last_saved
                    self.check_stop()
                    if shutil.disk_usage(self.store.root).free < MIN_FREE:
                        raise ValueError("Menos de 512 MiB livres no disco. Libere espaço e use Continuar.")
                    report("writing", True)
                    with db:
                        self.write(db, job, file, rows)
                        job["row_index"] = row_number
                        self.store.save(db, job)
                    rows = []
                    last, last_saved = time.monotonic(), row_number
                    report("reading", True)

                for number, row in enumerate(csv_rows(file, meter), 1):
                    tick = number % 1000 == 0
                    if tick:
                        self.check_stop()
                        report("rereading" if number <= saved_row else "reading")
                    if number <= saved_row:
                        if number % 10000 == 0 and self.stop.is_set():
                            raise Paused()
                        continue
                    expected = 2 if file["kind"] == "reference" else len(LAYOUTS[file["kind"]])
                    if len(row) != expected:
                        raise ValueError(f"Layout desconhecido em {file['name']}, linha {number}: {len(row)} campos; esperados {expected}.")
                    job["rows_scanned"] += 1
                    if file["kind"] == "establishments":
                        if (row[19] == job["state"] and (not cities or row[20] in cities)
                                and (not cnaes or row[11] in cnaes or cnaes.intersection(row[12].split(",")))
                                and (not job["active_only"] or row[5] == "02")):
                            rows.append((number, row))
                            job["rows_kept"] += 1
                    else:
                        rows.append((number, row))
                    if len(rows) >= BATCH or number - last_saved >= 50000 or (
                            tick and time.monotonic() - last >= 2):
                        flush(number)
                if "number" in locals() and number < saved_row:
                    raise ValueError("O ZIP tem menos linhas do que o ponto salvo.")
                flush(number if "number" in locals() else 0)
                with db:
                    job["file_index"], job["row_index"] = index + 1, 0
                    self.store.save(db, job)
                # Bound WAL growth while preserving concurrent reader snapshots.
                db.execute("PRAGMA wal_checkpoint(PASSIVE)")
                if "number" in locals():
                    del number
            with self.lock:
                self.check_stop()
                with db:
                    job.update(status="completed", current_file="", error="")
                    self.store.save(db, job)
            return {"job_id": ident, "companies": job["rows_kept"]}
        except Exception as error:
            db.rollback()
            # Restore durable counters/cursor, not speculative in-memory values.
            persisted = self.store.job(ident, db)
            persisted.update(status="cancelled" if isinstance(error, Cancelled) else
                             "paused" if isinstance(error, Paused) else "failed", error=str(error))
            if isinstance(error, Cancelled):
                persisted["cancelled_at"] = now()
            with db:
                self.store.save(db, persisted)
            raise
        finally:
            db.close()

    def write(self, db, job, file, rows):
        if not rows:
            return
        ident, kind = job["id"], file["kind"]
        if kind == "reference":
            db.executemany("INSERT OR REPLACE INTO refs VALUES(?,?,?,?)",
                           [(ident, file["name"][:-4], row[0], row[1]) for _, row in rows])
            return
        # Resolve matching bases through indexed SQL in small bounded chunks;
        # never hold millions of CNPJ bases in a Python set.
        bases = set()
        if kind != "establishments":
            wanted = list({r[0] for _, r in rows})
            for start in range(0, len(wanted), 400):
                chunk = wanted[start:start + 400]
                bases.update(r[0] for r in db.execute(
                    "SELECT DISTINCT base FROM establishments WHERE job=? AND base IN (" +
                    ",".join("?" for _ in chunk) + ")", [ident] + chunk))
        for number, row in rows:
            if kind != "establishments" and row[0] not in bases:
                continue
            data = dumps(dict(zip(LAYOUTS[kind], row)))
            if kind == "establishments":
                cnpj = "".join(row[:3])
                db.execute("INSERT INTO establishments VALUES(?,?,?,?,?,?,?,?,?,?)",
                           (ident, cnpj, row[0], row[19], row[20], normalized(row[17]),
                            row[11], row[5], normalized(row[4]), data))
                db.executemany("INSERT OR IGNORE INTO activities VALUES(?,?,?)",
                               [(ident, cnpj, code) for code in set([row[11]] + row[12].split(",")) if code])
            elif kind == "companies":
                db.execute("INSERT OR REPLACE INTO companies VALUES(?,?,?,?)", (ident, row[0], normalized(row[1]), data))
            elif kind == "partners":
                db.execute("INSERT OR REPLACE INTO partners VALUES(?,?,?,?,?)", (ident, file["name"], number, row[0], data))
            else:
                db.execute("INSERT OR REPLACE INTO simples VALUES(?,?,?)", (ident, row[0], data))
