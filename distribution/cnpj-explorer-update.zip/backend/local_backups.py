"""Cópias SQLite consistentes e recuperação para uma pasta NOVA, só no disco."""
from datetime import datetime, timezone
from contextlib import closing
import json
import os
from pathlib import Path
import shutil
import sqlite3
import threading
import time
import uuid

from engine import Paused

REQUIRED = {"jobs", "refs", "establishments", "companies", "partners", "simples",
            "exports", "export_items", "settings"}
DAY = 24 * 60 * 60


def stamp():
    return datetime.now(timezone.utc).isoformat()


def directory(value):
    text = str(value or "").strip()
    if not text:
        raise ValueError("Informe uma pasta de destino.")
    path = Path(text).expanduser()
    if not path.is_absolute() or path.is_file():
        raise ValueError("Informe o caminho absoluto de uma pasta, não de um arquivo.")
    if path.drive and not Path(path.anchor).is_dir():
        raise ValueError("A unidade de destino não está conectada.")
    path.mkdir(parents=True, exist_ok=True)
    return path.resolve()


def read_database(path):
    path = Path(path).expanduser()
    if not path.is_absolute() or not path.is_file():
        raise ValueError("Informe o caminho absoluto de uma cópia SQLite existente.")
    try:
        db = sqlite3.connect(path.resolve().as_uri() + "?mode=ro", uri=True, timeout=5)
        db.execute("PRAGMA trusted_schema=OFF")
        tables = {r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if not REQUIRED.issubset(tables):
            raise ValueError("Este arquivo não contém uma base compatível do CNPJ Explorer Local.")
        return db
    except Exception:
        if "db" in locals():
            db.close()
        raise


class Backups:
    def __init__(self, settings):
        self.path = Path(settings)
        self.lock = threading.RLock()
        self.config = {"directory": "", "automatic": False, "history": [], "last_error": ""}
        self.next_tick = 0
        self.retry_after = 0
        if self.path.exists():
            try:
                data = json.loads(self.path.read_text("utf-8"))
                if (not isinstance(data, dict) or not isinstance(data.get("directory"), str) or
                        not isinstance(data.get("automatic"), bool) or not isinstance(data.get("history"), list) or
                        any(not isinstance(x, dict) or not isinstance(x.get("path"), str) for x in data["history"])):
                    raise ValueError("Formato inválido")
                self.config.update({k: data[k] for k in self.config if k in data})
            except (OSError, ValueError, TypeError):
                self.config["last_error"] = "Não foi possível ler a configuração de cópias. O agendamento ficou desativado; confira e salve as opções novamente."

    def status(self):
        with self.lock:
            return json.loads(json.dumps(self.config))

    def save(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temp = self.path.with_suffix(".tmp")
        with temp.open("w", encoding="utf-8") as out:
            json.dump(self.config, out, ensure_ascii=False)
            out.flush()
            os.fsync(out.fileno())
        temp.replace(self.path)

    def settings(self, body):
        if not isinstance(body.get("automatic"), bool):
            raise ValueError("Informe se a cópia automática deve ficar ativa.")
        raw = str(body.get("directory", "")).strip()
        if body["automatic"] and not raw:
            raise ValueError("Informe a pasta de destino para ativar as cópias automáticas.")
        root = str(directory(raw)) if raw else ""
        with self.lock:
            previous = self.config.copy()
            self.config.update(directory=root, automatic=body["automatic"], last_error="")
            try:
                self.save()
            except Exception:
                self.config = previous
                raise
        return self.status()

    def start(self, store, engine, body, restore=False):
        if engine.running:
            raise ValueError("Aguarde ou pause a tarefa atual antes de copiar ou recuperar a base.")
        parent = directory(body.get("directory"))
        if restore:
            if body.get("confirm") is not True:
                raise ValueError("Confirme a recuperação para uma pasta nova. A base atual será preservada.")
            source = Path(str(body.get("path", "")).strip()).expanduser()
        else:
            source = store.path
        try:
            with closing(read_database(source)) as db:
                size = db.execute("PRAGMA page_count").fetchone()[0] * db.execute("PRAGMA page_size").fetchone()[0]
        except sqlite3.DatabaseError as error:
            raise ValueError("O arquivo não é uma cópia SQLite válida do CNPJ Explorer Local.") from error
        if shutil.disk_usage(parent).free < size + 128 * 1024 * 1024:
            raise ValueError("Espaço insuficiente para a cópia e a margem de segurança de 128 MB.")
        suffix = datetime.now().strftime("%Y%m%d-%H%M%S") + "-" + uuid.uuid4().hex[:8]
        destination = parent / ("cnpj-restaurado-" + suffix) if restore else parent
        final = destination / ("cnpj-local.sqlite3" if restore else "cnpj-backup-" + suffix + ".sqlite3")
        def action():
            try:
                return self.copy(source, final, store.root if store else None, engine, restore)
            except Exception as error:
                if not restore:
                    with self.lock:
                        self.config["last_error"] = ("Cópia interrompida; solicite uma nova cópia." if isinstance(error, Paused)
                                                     else "A última cópia falhou: " + str(error))
                raise
        engine.launch("restore" if restore else "backup", action)
        return {"started": True}

    def copy(self, source, final, source_dir, engine, restore):
        partial = final.with_name("." + final.name + ".partial")
        src = dst = None
        made_directory = False
        made_partial = False
        try:
            if restore:
                final.parent.mkdir(exist_ok=False)
                made_directory = True
            # Reserva exclusiva, sem truncar nenhum arquivo existente.
            with partial.open("xb"):
                pass
            made_partial = True
            src = read_database(source)
            dst = sqlite3.connect(partial)

            def progress(status, remaining, total):
                engine.check_stop()
                engine.task.update(message="Copiando páginas do banco local…",
                                   progress={"done": max(0, total - remaining), "total": total, "phase": "copying"})

            src.backup(dst, pages=256, progress=progress, sleep=0.05)
            engine.check_stop()
            engine.task.update(message="Verificando a integridade da cópia…")
            engine.task["progress"]["phase"] = "checking"
            dst.set_progress_handler(lambda: int(engine.stop.is_set()), 1000)
            result = dst.execute("PRAGMA quick_check(1)").fetchone()
            if not result or result[0] != "ok":
                raise ValueError("A cópia não passou na verificação de integridade. A base original foi preservada.")
            dst.set_progress_handler(None, 0)
            dst.execute("PRAGMA journal_mode=DELETE")
            dst.close()
            dst = None
            src.close()
            src = None
            engine.check_stop()
            engine.task["progress"]["phase"] = "saving"
            engine.task["message"] = "Confirmando a gravação da cópia no disco…"
            # Handle gravável: os.fsync em 'rb' falha no Windows.
            with partial.open("r+b") as out:
                out.flush()
                os.fsync(out.fileno())
            with engine.lock:
                engine.check_stop()
                engine.task["finishing"] = True
                if final.exists():
                    raise ValueError("O destino já existe; nenhum arquivo foi substituído.")
                partial.replace(final)
                size = final.stat().st_size
                if not restore:
                    with self.lock:
                        self.config["history"].insert(0, {"path": str(final), "created_at": stamp(),
                                                         "size": size, "source_dir": str(source_dir)})
                        self.config["history"] = self.config["history"][:50]
                        self.config["last_error"] = ""
                        try:
                            self.save()
                        except OSError as error:
                            raise ValueError("A cópia foi gravada em " + str(final) +
                                             ", mas não foi possível atualizar o histórico. Guarde esse caminho.") from error
            return {"directory": str(final.parent)} if restore else {"path": str(final), "size": size}
        except sqlite3.OperationalError as error:
            if engine.stop.is_set() and getattr(error, "sqlite_errorcode", None) == sqlite3.SQLITE_INTERRUPT:
                raise Paused() from error
            raise
        finally:
            if dst is not None:
                dst.close()
            if src is not None:
                src.close()
            if made_partial:
                partial.unlink(missing_ok=True)
            # Apenas a pasta vazia criada por ESTA tentativa, nunca o destino do usuário.
            if made_directory and not final.exists():
                for extra in (Path(str(partial) + "-journal"), Path(str(partial) + "-wal"), Path(str(partial) + "-shm")):
                    extra.unlink(missing_ok=True)
                try:
                    final.parent.rmdir()
                except OSError:
                    pass

    def tick(self, application):
        """Diariamente, apenas com programa aberto, opção ativa e serviço ocioso."""
        current = time.monotonic()
        if current < max(self.next_tick, self.retry_after):
            return
        self.next_tick = current + 30
        if not self.config["automatic"] or not self.config["directory"]:
            return
        if not application.operation_lock.acquire(blocking=False):
            return
        try:
            with application.activity_lock:
                if (application.updating or application.active_requests or not application.store or
                        application.engine.running or application.downloads.running):
                    return
                root = str(application.store.root)
                for entry in self.config["history"]:
                    if entry.get("source_dir") == root:
                        try:
                            if time.time() - datetime.fromisoformat(entry["created_at"]).timestamp() < DAY:
                                return
                        except (KeyError, ValueError, TypeError):
                            pass
                self.retry_after = current + 300
                self.start(application.store, application.engine, {"directory": self.config["directory"]})
        except Exception as error:
            with self.lock:
                self.config["last_error"] = "A cópia automática não foi iniciada: " + str(error)
        finally:
            application.operation_lock.release()
