"""Senha local: PBKDF2, recuperação sem nuvem e sessões por execução."""
import hashlib
import hmac
import json
import os
import secrets
import threading
import time
from pathlib import Path

ITERATIONS = 600_000
SESSION_SECONDS = 30 * 60


class PasswordGate:
    def __init__(self, path):
        self.path = Path(path)
        self.lock = threading.RLock()
        self.expires = 0
        self.failures = 0
        self.blocked_until = 0
        self.record = None
        if self.path.exists():
            self.record = json.loads(self.path.read_text("utf-8"))
            # Fail closed rather than silently recreating a damaged password.
            if self.record.get("version") != 1 or not all(
                    key in self.record for key in ("salt", "hash", "iterations", "recovery_hash")):
                raise ValueError("Arquivo de acesso inválido. Restaure a cópia de configuração; a base não foi apagada.")
            if not 100_000 <= int(self.record["iterations"]) <= 2_000_000:
                raise ValueError("Configuração de senha inválida.")

    def status(self):
        with self.lock:
            return {"configured": self.record is not None, "authenticated": time.monotonic() < self.expires,
                    "retry_after": max(0, int(self.blocked_until - time.monotonic() + 0.99))}

    def require(self, touch=False):
        with self.lock:
            if not self.status()["authenticated"]:
                raise PermissionError("Digite sua senha para acessar o programa.")
            if touch:
                self.expires = time.monotonic() + SESSION_SECONDS

    def attempt(self):
        if self.status()["retry_after"]:
            raise ValueError("Muitas tentativas. Aguarde antes de tentar novamente.")

    def failure(self):
        self.failures += 1
        if self.failures >= 5:
            self.blocked_until = time.monotonic() + min(300, 2 ** min(self.failures, 9))
        raise ValueError("Senha ou código de recuperação incorreto.")

    @staticmethod
    def digest(password, salt, iterations):
        return hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), bytes.fromhex(salt), iterations).hex()

    def verify(self, password):
        return isinstance(password, str) and len(password) <= 128 and self.record and hmac.compare_digest(
            self.digest(password, self.record["salt"], self.record["iterations"]), self.record["hash"])

    def save_password(self, body):
        password = body.get("password")
        if not isinstance(password, str) or not 10 <= len(password) <= 128:
            raise ValueError("Use uma senha com 10 a 128 caracteres.")
        if password != body.get("confirmation"):
            raise ValueError("A confirmação da senha não confere.")
        salt = secrets.token_hex(16)
        recovery = secrets.token_hex(20).upper()
        record = {"version": 1, "iterations": ITERATIONS, "salt": salt,
                  "hash": self.digest(password, salt, ITERATIONS),
                  "recovery_hash": hashlib.sha256(recovery.encode("ascii")).hexdigest()}
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix(".tmp")
        with tmp.open("w", encoding="utf-8") as output:
            json.dump(record, output)
            output.flush()
            os.fsync(output.fileno())
        if os.name != "nt":
            tmp.chmod(0o600)
        tmp.replace(self.path)
        self.record = record
        self.failures = self.blocked_until = 0
        self.expires = time.monotonic() + SESSION_SECONDS
        return {"authenticated": True, "recovery_code": "-".join(recovery[i:i+5] for i in range(0, 40, 5))}

    def handle(self, operation, body):
        with self.lock:
            if operation == "status":
                return self.status()
            if operation == "logout":
                self.expires = 0
                return {"authenticated": False}
            self.attempt()
            if operation == "setup":
                if self.record:
                    raise ValueError("Já existe uma senha. Entre ou use o código de recuperação.")
                return self.save_password(body)
            if not self.record:
                raise ValueError("Crie primeiro a senha local.")
            if operation == "login":
                if not self.verify(body.get("password")):
                    self.failure()
                self.failures = self.blocked_until = 0
                self.expires = time.monotonic() + SESSION_SECONDS
                return {"authenticated": True}
            if operation == "change":
                self.require()
                if not self.verify(body.get("current_password")):
                    self.failure()
                return self.save_password(body)
            if operation == "recover":
                code = body.get("recovery_code", "")
                if not isinstance(code, str) or len(code) > 100:
                    self.failure()
                clean = code.replace("-", "").replace(" ", "").upper()
                if not hmac.compare_digest(hashlib.sha256(clean.encode("utf-8")).hexdigest(),
                                           self.record["recovery_hash"]):
                    self.failure()
                return self.save_password(body)
            raise ValueError("Operação de acesso desconhecida.")
