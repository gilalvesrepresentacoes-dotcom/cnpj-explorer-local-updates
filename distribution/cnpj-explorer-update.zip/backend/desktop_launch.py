"""Entry point for isolated embedded Python and versioned backend directories."""
from pathlib import Path
import runpy
import sys

# The embedded distribution's _pth still references the original backend.
# Insert the directory selected/verified by the native bootstrap BEFORE imports.
# -I ignores PYTHONPATH and -B keeps immutable release folders free of pycache.
backend = Path(sys.argv.pop(1)).resolve(strict=True)
script = backend / "app.py"
if not backend.is_dir() or not script.is_file():
    raise SystemExit("Diretório da versão selecionada inválido.")
sys.path.insert(0, str(backend))
sys.argv[0] = str(script)
runpy.run_path(str(script), run_name="__main__")
