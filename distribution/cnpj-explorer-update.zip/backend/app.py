"""Servidor privado loopback: contas locais e envio SMTP opcional."""
import argparse
import hmac
import json
import mimetypes
import secrets
import sys
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlsplit

from engine import Engine, inspect
from exporter import Exporter
from store import Store
from accounts import Accounts, AccessDenied
from receita_downloads import Downloads
from local_backups import Backups
from export_options import ExportOptions

HERE = Path(__file__).resolve().parent


class LocalApplication:
    def __init__(self, settings=None):
        self.settings = Path(settings or HERE / "settings.json")
        self.settings.parent.mkdir(parents=True, exist_ok=True)
        self.auth = Accounts(self.settings.with_name("access.json"))
        self.token = secrets.token_urlsafe(32)
        self.store = self.engine = None
        self.operation_lock = threading.RLock()
        self.activity_lock = threading.Lock()
        self.active_requests = 0
        self.updating = False
        self.downloads = Downloads(self.settings.with_name("downloads.json"))
        self.backups = Backups(self.settings.with_name("backups.json"))
        self.export_options = ExportOptions(self.settings.with_name("export-options.json"))
        self.startup_error = ""
        if self.settings.exists():
            try:
                self.configure(json.loads(self.settings.read_text("utf-8"))["data_dir"], save=False)
            except Exception as error:
                self.startup_error = "Não foi possível abrir a pasta anterior: " + str(error)

    def configure(self, directory, save=True):
        if self.engine and self.engine.running:
            raise ValueError("Pause e aguarde a tarefa atual antes de trocar de pasta.")
        if self.store and Path(directory).expanduser() == self.store.root:
            return self.status()
        store = Store(directory)
        store.recover()
        if self.store:
            self.store.close()
        self.store, self.engine = store, Engine(store)
        self.startup_error = ""
        if save:
            tmp = self.settings.with_suffix(".tmp")
            tmp.write_text(json.dumps({"data_dir": str(store.root)}, ensure_ascii=False), "utf-8")
            tmp.replace(self.settings)
        return self.status()

    def status(self):
        jobs = self.store.jobs() if self.store else []
        # Do not expose the entire source manifest and its filesystem metadata.
        jobs = [{k: v for k, v in j.items() if k not in ("manifest", "source_dir", "row_index")} for j in jobs]
        return {"configured": bool(self.store), "data_dir": str(self.store.root) if self.store else "",
                "running": bool(self.engine and self.engine.running), "task": self.engine.task if self.engine else None,
                "jobs": jobs, "error": self.startup_error, "downloads": self.downloads.status(),
                "backup_error": self.backups.config.get("last_error", "")}

    def handle(self, path, body=None, session=""):
        if path == "/api/admin/update-prepare":
            self.auth.admin(session)
            with self.activity_lock:
                if getattr(self, "downloads", None) and self.downloads.running:
                    return {"ready": False, "reason": "Há um download de ZIPs em andamento. Interrompa o download e aguarde a confirmação antes de instalar a atualização."}
                if self.engine and self.engine.running and self.engine.task and self.engine.task.get("stopping"):
                    return {"ready": False, "reason": "A tarefa ainda está sendo interrompida. Aguarde aparecer Interrompida ou Pausada antes de instalar a atualização."}
                if self.active_requests or (self.engine and self.engine.running):
                    return {"ready": False, "reason": "Há consulta, importação, configuração ou exportação em andamento. Aguarde sua conclusão e tente novamente."}
                self.updating = True
                return {"ready": True}
        with self.activity_lock:
            if self.updating and path not in ("/api/auth/status", "/api/auth/logout"):
                raise ValueError("O programa está encerrando para atualizar. Aguarde a reabertura.")
            self.active_requests += 1
        try:
            return self._handle(path, body, session)
        finally:
            with self.activity_lock:
                self.active_requests -= 1

    def _handle(self, path, body=None, session=""):
        if path.startswith("/api/auth/"):
            preference = self.settings.with_name("login-preferences.json")
            body = body or {}
            if path == "/api/auth/forget-email":
                preference.unlink(missing_ok=True)
                return {"ok": True}
            result = self.auth.handle(path.rsplit("/", 1)[-1], body, session)
            if path == "/api/auth/status":
                result["remembered_email"] = ""
                if preference.exists():
                    try:
                        from local_mail import email_address
                        result["remembered_email"] = email_address(json.loads(preference.read_text("utf-8")).get("email", ""))
                    except (OSError, ValueError, TypeError, AttributeError):
                        pass  # A broken optional preference must never block login.
            if path == "/api/auth/login" and "remember_email" in body:
                # Save ONLY the verified account's e-mail after successful login.
                # Stable installation path, not origin-dependent browser storage:
                # the desktop backend uses a different localhost port on restart.
                try:
                    if body["remember_email"] is True and result.get("user", {}).get("email"):
                        from local_mail import atomic_json
                        atomic_json(preference, {"email": result["user"]["email"]})
                    else:
                        preference.unlink(missing_ok=True)
                except OSError:
                    result["preference_error"] = "Não foi possível guardar a preferência de e-mail neste computador."
            return result
        if path.startswith("/api/admin/"):
            return self.auth.handle_admin(path, body or {}, session)
        user = self.auth.require(session, touch=path not in ("/api/status", "/api/history", "/api/export-status"))
        if path in ("/api/configure", "/api/inspect", "/api/import", "/api/resume", "/api/pause", "/api/cancel"):
            self.auth.admin(session)
        if path.startswith("/api/backups"):
            self.auth.admin(session)
            if path == "/api/backups":
                return self.backups.status()
            if path == "/api/backups/settings":
                return self.backups.settings(body or {})
            if path in ("/api/backups/create", "/api/backups/restore"):
                restore = path.endswith("/restore")
                if not self.store and not restore:
                    raise ValueError("Escolha primeiro a pasta local da base.")
                if self.downloads.running:
                    raise ValueError("Aguarde ou interrompa o download antes de copiar ou recuperar a base.")
                if self.engine is None:
                    self.engine = Engine(None)
                return self.backups.start(self.store, self.engine, body or {}, restore=restore)
            raise ValueError("Operação de cópia desconhecida.")
        if path.startswith("/api/source/"):
            self.auth.admin(session)
            if path == "/api/source/periods":
                return {"periods": self.downloads.catalog.periods()}
            if path == "/api/source/files":
                period = (body or {}).get("period", "")
                return {"period": period, "files": self.downloads.catalog.files(period)}
            if path in ("/api/source/download", "/api/source/download-batch"):
                if self.engine and self.engine.running and self.engine.task and self.engine.task.get("kind") == "import":
                    job = self.store.job(self.engine.task["job_id"])
                    periods = [(body or {}).get("period", "")]
                    if path.endswith("-batch"):
                        raw = (body or {}).get("items", [])
                        periods = [i.get("period", "") for i in raw if isinstance(i, dict)] if isinstance(raw, list) else []
                    parent = Path(str((body or {}).get("directory", ""))).expanduser()
                    if any((parent / str(p)).resolve() == Path(job["source_dir"]).resolve() for p in periods):
                        raise ValueError("Esta pasta está sendo lida pelo processamento. Pause a importação ou escolha outra pasta para baixar os ZIPs.")
                if path.endswith("-batch"):
                    return self.downloads.start_batch(body or {})
                return self.downloads.start(body or {})
            if path == "/api/source/stop":
                return self.downloads.pause()
            raise ValueError("Operação de download desconhecida.")
        if path == "/api/status":
            return self.status()
        if path == "/api/filter-fields":
            from query_filters import FIELDS
            return {"fields": list(FIELDS.values()), "max_rules": 40}
        if path == "/api/configure":
            return self.configure(str(body.get("data_dir", "")).strip())
        if path == "/api/pause":
            return self.engine.request_pause() if self.engine else {"ok": True, "pending": False}
        if not self.store:
            raise ValueError("Escolha primeiro a pasta local para a base.")
        if path == "/api/workspace":
            if self.engine.running and (body.get("action") == "save_result" or
                                        (body.get("action") == "delete" and body.get("kind", "result") == "result")):
                raise ValueError("Aguarde ou pause a tarefa antes de salvar ou excluir um resultado.")
            return self.store.library.handle(body, user["id"])
        if path == "/api/selection-count":
            return self.store.library.count(body, user["id"])
        # Identity is server-owned, including export filters; client input cannot
        # access another local user's materialized results.
        if path == "/api/export-options":
            return self.export_options.get(user["id"])
        if path == "/api/export-options/save":
            return self.export_options.save(user["id"], body or {})
        body = dict(body or {}, _owner=user["id"])
        if path == "/api/export":
            body["filters"] = dict(body.get("filters") or {}, _owner=user["id"])
        if path == "/api/inspect":
            return inspect(body.get("source_dir", ""))
        if path == "/api/import":
            return self.engine.start(body)
        if path == "/api/resume":
            return self.engine.resume(body.get("id", ""))
        if path == "/api/cancel":
            return self.engine.cancel(body.get("id", ""))
        if path == "/api/companies":
            return self.store.search(body)
        if path == "/api/company":
            return self.store.detail(body)
        if path == "/api/references":
            return self.store.references(body.get("job_id", ""))
        if path == "/api/export":
            return Exporter(self.store, self.engine).request(body)
        if path == "/api/history":
            return self.store.history()
        if path == "/api/export-status":
            return self.store.export_status(body.get("cnpjs", []))
        if path == "/api/open-export":
            return self.store.open_export(body.get("id", ""))
        raise ValueError("Operação local desconhecida.")


def make_server(application, port=8765):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass  # Paths, CNPJs and tokens do not belong in console logs.

        def response(self, code, data, content_type="application/json; charset=utf-8"):
            if not isinstance(data, bytes):
                data = json.dumps(data, ensure_ascii=False).encode("utf-8")
            self.send_response(code)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Referrer-Policy", "no-referrer")
            self.send_header("Content-Security-Policy", "default-src 'self'; connect-src 'self'; style-src 'self'; script-src 'self'; img-src 'self' data:; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
            self.end_headers()
            self.wfile.write(data)

        def valid_host(self):
            port_value = self.server.server_address[1]
            return self.headers.get("Host", "") in (f"127.0.0.1:{port_value}", f"localhost:{port_value}")

        def dispatch(self):
            if not self.valid_host():
                return self.response(403, {"error": "Host local inválido."})
            parsed = urlsplit(self.path)
            if not parsed.path.startswith("/api/"):
                if self.command != "GET":
                    return self.response(405, {"error": "Método não permitido."})
                allowed = {"/": "index.html", "/app.js": "app.js", "/accounts.js": "accounts.js", "/progress.js": "progress.js",
                           "/search-progress.js": "search-progress.js", "/export-progress.js": "export-progress.js",
                           "/imports.js": "imports.js", "/imports.css": "imports.css",
                           "/web-theme.css": "web-theme.css", "/navigation.js": "navigation.js", "/safety.js": "safety.js",
                           "/source-workspace.css": "source-workspace.css", "/source-workspace.js": "source-workspace.js",
                           "/export-options.css": "export-options.css", "/export-options.js": "export-options.js",
                           "/style.css": "style.css"}
                filename = allowed.get(parsed.path)
                if not filename:
                    return self.response(404, {"error": "Página não encontrada."})
                file = HERE / "ui" / filename
                return self.response(200, file.read_bytes(), (mimetypes.guess_type(filename)[0] or "text/plain") + "; charset=utf-8")
            if not hmac.compare_digest(self.headers.get("X-Local-Token", "").encode("utf-8"), application.token.encode("utf-8")):
                return self.response(403, {"code": "LOCAL_TOKEN_INVALID", "error": "A conexão com o programa local mudou. Feche esta janela e abra novamente pelo ícone do CNPJ Explorer Local. O processamento não é cancelado por este aviso."})
            origin = self.headers.get("Origin")
            if origin and origin not in (f"http://127.0.0.1:{self.server.server_address[1]}",
                                         f"http://localhost:{self.server.server_address[1]}"):
                return self.response(403, {"error": "Origem não autorizada."})
            try:
                read_only = {"/api/status", "/api/companies", "/api/company", "/api/references",
                             "/api/history", "/api/filter-fields", "/api/auth/status",
                             "/api/admin/users", "/api/admin/mail"}
                read_only |= {"/api/source/periods", "/api/source/files"}
                read_only.add("/api/backups")
                read_only.add("/api/export-options")
                if (parsed.path in read_only) != (self.command == "GET"):
                    return self.response(405, {"error": "Método não permitido."})
                if self.command == "POST":
                    if "application/json" not in self.headers.get("Content-Type", ""):
                        raise ValueError("Envie um objeto JSON.")
                    length = int(self.headers.get("Content-Length", "0"))
                    if length <= 0 or length > 1024 * 1024:
                        raise ValueError("Requisição vazia ou muito grande.")
                    body = json.loads(self.rfile.read(length))
                    if not isinstance(body, dict):
                        raise ValueError("Envie um objeto JSON.")
                else:
                    body = {key: values[-1] for key, values in parse_qs(parsed.query).items()}
                if self.command == "POST" and parsed.path not in ("/api/pause", "/api/source/stop"):
                    with application.operation_lock:
                        result = application.handle(parsed.path, body, self.headers.get("X-Local-Session", ""))
                else:
                    result = application.handle(parsed.path, body, self.headers.get("X-Local-Session", ""))
                self.response(200, result)
            except AccessDenied as error:
                self.response(403, {"error": str(error), "forbidden": True})
            except PermissionError as error:
                self.response(401, {"error": str(error), "locked": True})
            except (ValueError, KeyError, TypeError) as error:
                retry = getattr(error, "retry_after", 0)
                self.response(429 if retry else 400, {"error": str(error), "retry_after": retry})
            except Exception as error:
                self.response(500, {"error": "Falha local: " + str(error)})

        do_GET = dispatch
        do_POST = dispatch

    class LocalServer(ThreadingHTTPServer):
        def service_actions(self):
            application.backups.tick(application)

    server = LocalServer(("127.0.0.1", port), Handler)
    server.daemon_threads = True
    application.auth.recovery_url = lambda token: (
        f"http://127.0.0.1:{server.server_address[1]}/#token={application.token}&reset={token}")
    return server


def main():
    if sys.version_info < (3, 11):
        raise SystemExit("Instale Python 3.11 ou superior.")
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--no-browser", action="store_true")
    parser.add_argument("--desktop", action="store_true")
    parser.add_argument("--settings", type=Path)
    args = parser.parse_args()
    application = LocalApplication(args.settings)
    try:
        server = make_server(application, args.port)
    except OSError:
        raise SystemExit("A porta local está ocupada. Feche outra execução ou inicie com --port 8766.")
    url = f"http://127.0.0.1:{server.server_address[1]}/#token={application.token}"
    if args.desktop:
        print(json.dumps({"ready": True, "url": url}), flush=True)
        def stop_from_parent():
            # The private stdin pipe belongs to the desktop parent, not the web renderer.
            for line in sys.stdin:
                if line.strip() == "stop":
                    break
            if application.engine and application.engine.running:
                application.engine.stop.set()
                application.engine.thread.join(timeout=15)
            if application.downloads.running:
                application.downloads.pause()
                application.downloads.thread.join(timeout=2)
            server.shutdown()
        threading.Thread(target=stop_from_parent, daemon=True).start()
    else:
        print("CNPJ Explorer Local — mantenha esta janela aberta.")
        print("ZIPs e consultas ficam neste computador. E-mails usam somente o SMTP configurado.")
        print("Use o endereço abaixo somente neste computador.")
        print(url)
    if not args.no_browser and not args.desktop:
        webbrowser.open(url)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        if application.engine and application.engine.running:
            application.engine.stop.set()
            application.engine.thread.join(timeout=15)
    finally:
        if application.downloads.running:
            application.downloads.pause()
            application.downloads.thread.join(timeout=2)
        server.server_close()
        if application.store:
            application.store.close()


if __name__ == "__main__":
    main()
