"""Servidor privado loopback: contas locais e envio SMTP opcional."""
import argparse
import hmac
import json
import mimetypes
import secrets
import sys
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlsplit

from engine import Engine, inspect
from exporter import Exporter
from store import Store
from accounts import Accounts, AccessDenied

HERE = Path(__file__).resolve().parent


class LocalApplication:
    def __init__(self, settings=None):
        self.settings = Path(settings or HERE / "settings.json")
        self.settings.parent.mkdir(parents=True, exist_ok=True)
        self.auth = Accounts(self.settings.with_name("access.json"))
        self.token = secrets.token_urlsafe(32)
        self.store = self.engine = None
        self.operation_lock = threading.RLock()
        self.activity_lock = threading.Lock()
        self.active_requests = 0
        self.updating = False
        self.startup_error = ""
        if self.settings.exists():
            try:
                self.configure(json.loads(self.settings.read_text("utf-8"))["data_dir"], save=False)
            except Exception as error:
                self.startup_error = "Não foi possível abrir a pasta anterior: " + str(error)

    def configure(self, directory, save=True):
        if self.engine and self.engine.running:
            raise ValueError("Pause e aguarde a tarefa atual antes de trocar de pasta.")
        if self.store and Path(directory).expanduser() == self.store.root:
            return self.status()
        store = Store(directory)
        store.recover()
        if self.store:
            self.store.close()
        self.store, self.engine = store, Engine(store)
        self.startup_error = ""
        if save:
            tmp = self.settings.with_suffix(".tmp")
            tmp.write_text(json.dumps({"data_dir": str(store.root)}, ensure_ascii=False), "utf-8")
            tmp.replace(self.settings)
        return self.status()

    def status(self):
        jobs = self.store.jobs() if self.store else []
        # Do not expose the entire source manifest and its filesystem metadata.
        jobs = [{k: v for k, v in j.items() if k not in ("manifest", "source_dir", "row_index")} for j in jobs]
        return {"configured": bool(self.store), "data_dir": str(self.store.root) if self.store else "",
                "running": bool(self.engine and self.engine.running), "task": self.engine.task if self.engine else None,
                "jobs": jobs, "error": self.startup_error}

    def handle(self, path, body=None, session=""):
        if path == "/api/admin/update-prepare":
            self.auth.admin(session)
            with self.activity_lock:
                if self.active_requests or (self.engine and self.engine.running):
                    return {"ready": False, "reason": "Há consulta, importação, configuração ou exportação em andamento. Aguarde sua conclusão e tente novamente."}
                self.updating = True
                return {"ready": True}
        with self.activity_lock:
            if self.updating and path not in ("/api/auth/status", "/api/auth/logout"):
                raise ValueError("O programa está encerrando para atualizar. Aguarde a reabertura.")
            self.active_requests += 1
        try:
            return self._handle(path, body, session)
        finally:
            with self.activity_lock:
                self.active_requests -= 1

    def _handle(self, path, body=None, session=""):
        if path.startswith("/api/auth/"):
            return self.auth.handle(path.rsplit("/", 1)[-1], body or {}, session)
        if path.startswith("/api/admin/"):
            return self.auth.handle_admin(path, body or {}, session)
        self.auth.require(session, touch=path not in ("/api/status", "/api/history", "/api/export-status"))
        if path in ("/api/configure", "/api/inspect", "/api/import", "/api/resume", "/api/pause"):
            self.auth.admin(session)
        if path == "/api/status":
            return self.status()
        if path == "/api/filter-fields":
            from query_filters import FIELDS
            return {"fields": list(FIELDS.values()), "max_rules": 40}
        if path == "/api/configure":
            return self.configure(str(body.get("data_dir", "")).strip())
        if not self.store:
            raise ValueError("Escolha primeiro a pasta local para a base.")
        if path == "/api/inspect":
            return inspect(body.get("source_dir", ""))
        if path == "/api/import":
            return self.engine.start(body)
        if path == "/api/resume":
            return self.engine.resume(body.get("id", ""))
        if path == "/api/pause":
            self.engine.stop.set()
            return {"ok": True}
        if path == "/api/companies":
            return self.store.search(body)
        if path == "/api/company":
            return self.store.detail(body)
        if path == "/api/references":
            return self.store.references(body.get("job_id", ""))
        if path == "/api/export":
            return Exporter(self.store, self.engine).request(body)
        if path == "/api/history":
            return self.store.history()
        if path == "/api/export-status":
            return self.store.export_status(body.get("cnpjs", []))
        if path == "/api/open-export":
            return self.store.open_export(body.get("id", ""))
        raise ValueError("Operação local desconhecida.")


def make_server(application, port=8765):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass  # Paths, CNPJs and tokens do not belong in console logs.

        def response(self, code, data, content_type="application/json; charset=utf-8"):
            if not isinstance(data, bytes):
                data = json.dumps(data, ensure_ascii=False).encode("utf-8")
            self.send_response(code)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Referrer-Policy", "no-referrer")
            self.send_header("Content-Security-Policy", "default-src 'self'; connect-src 'self'; style-src 'self'; script-src 'self'; img-src 'self' data:; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
            self.end_headers()
            self.wfile.write(data)

        def valid_host(self):
            port_value = self.server.server_address[1]
            return self.headers.get("Host", "") in (f"127.0.0.1:{port_value}", f"localhost:{port_value}")

        def dispatch(self):
            if not self.valid_host():
                return self.response(403, {"error": "Host local inválido."})
            parsed = urlsplit(self.path)
            if not parsed.path.startswith("/api/"):
                if self.command != "GET":
                    return self.response(405, {"error": "Método não permitido."})
                allowed = {"/": "index.html", "/app.js": "app.js", "/accounts.js": "accounts.js", "/progress.js": "progress.js", "/style.css": "style.css"}
                filename = allowed.get(parsed.path)
                if not filename:
                    return self.response(404, {"error": "Página não encontrada."})
                file = HERE / "ui" / filename
                return self.response(200, file.read_bytes(), (mimetypes.guess_type(filename)[0] or "text/plain") + "; charset=utf-8")
            if not hmac.compare_digest(self.headers.get("X-Local-Token", "").encode("utf-8"), application.token.encode("utf-8")):
                return self.response(403, {"error": "Sessão local inválida. Reabra o endereço mostrado na janela do programa."})
            origin = self.headers.get("Origin")
            if origin and origin not in (f"http://127.0.0.1:{self.server.server_address[1]}",
                                         f"http://localhost:{self.server.server_address[1]}"):
                return self.response(403, {"error": "Origem não autorizada."})
            try:
                read_only = {"/api/status", "/api/companies", "/api/company", "/api/references",
                             "/api/history", "/api/filter-fields", "/api/auth/status",
                             "/api/admin/users", "/api/admin/mail"}
                if (parsed.path in read_only) != (self.command == "GET"):
                    return self.response(405, {"error": "Método não permitido."})
                if self.command == "POST":
                    if "application/json" not in self.headers.get("Content-Type", ""):
                        raise ValueError("Envie um objeto JSON.")
                    length = int(self.headers.get("Content-Length", "0"))
                    if length <= 0 or length > 1024 * 1024:
                        raise ValueError("Requisição vazia ou muito grande.")
                    body = json.loads(self.rfile.read(length))
                    if not isinstance(body, dict):
                        raise ValueError("Envie um objeto JSON.")
                else:
                    body = {key: values[-1] for key, values in parse_qs(parsed.query).items()}
                if self.command == "POST":
                    with application.operation_lock:
                        result = application.handle(parsed.path, body, self.headers.get("X-Local-Session", ""))
                else:
                    result = application.handle(parsed.path, body, self.headers.get("X-Local-Session", ""))
                self.response(200, result)
            except AccessDenied as error:
                self.response(403, {"error": str(error), "forbidden": True})
            except PermissionError as error:
                self.response(401, {"error": str(error), "locked": True})
            except (ValueError, KeyError, TypeError) as error:
                retry = getattr(error, "retry_after", 0)
                self.response(429 if retry else 400, {"error": str(error), "retry_after": retry})
            except Exception as error:
                self.response(500, {"error": "Falha local: " + str(error)})

        do_GET = dispatch
        do_POST = dispatch

    server = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    server.daemon_threads = True
    application.auth.recovery_url = lambda token: (
        f"http://127.0.0.1:{server.server_address[1]}/#token={application.token}&reset={token}")
    return server


def main():
    if sys.version_info < (3, 11):
        raise SystemExit("Instale Python 3.11 ou superior.")
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--no-browser", action="store_true")
    parser.add_argument("--desktop", action="store_true")
    parser.add_argument("--settings", type=Path)
    args = parser.parse_args()
    application = LocalApplication(args.settings)
    try:
        server = make_server(application, args.port)
    except OSError:
        raise SystemExit("A porta local está ocupada. Feche outra execução ou inicie com --port 8766.")
    url = f"http://127.0.0.1:{server.server_address[1]}/#token={application.token}"
    if args.desktop:
        print(json.dumps({"ready": True, "url": url}), flush=True)
        def stop_from_parent():
            # The private stdin pipe belongs to the desktop parent, not the web renderer.
            for line in sys.stdin:
                if line.strip() == "stop":
                    break
            if application.engine and application.engine.running:
                application.engine.stop.set()
                application.engine.thread.join(timeout=15)
            server.shutdown()
        threading.Thread(target=stop_from_parent, daemon=True).start()
    else:
        print("CNPJ Explorer Local — mantenha esta janela aberta.")
        print("ZIPs e consultas ficam neste computador. E-mails usam somente o SMTP configurado.")
        print("Use o endereço abaixo somente neste computador.")
        print(url)
    if not args.no_browser and not args.desktop:
        webbrowser.open(url)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        if application.engine and application.engine.running:
            application.engine.stop.set()
            application.engine.thread.join(timeout=15)
    finally:
        server.server_close()
        if application.store:
            application.store.close()


if __name__ == "__main__":
    main()
