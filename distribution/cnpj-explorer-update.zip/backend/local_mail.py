"""Envio SMTP explícito; credencial cifrada pelo perfil Windows, nunca devolvida à UI."""
import base64
import ctypes
import json
import os
import re
import secrets
import smtplib
import ssl
import threading
from datetime import datetime, timezone
from email.message import EmailMessage
from pathlib import Path


def email_address(value):
    if not isinstance(value, str):
        raise ValueError("Informe um e-mail válido.")
    value = value.strip().lower()
    if len(value) > 254 or not re.fullmatch(r"[a-z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?\.[a-z]{2,63}", value):
        raise ValueError("Informe um e-mail válido.")
    return value


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    with tmp.open("w", encoding="utf-8") as output:
        json.dump(value, output, ensure_ascii=False)
        output.flush()
        os.fsync(output.fileno())
    if os.name != "nt":
        tmp.chmod(0o600)
    tmp.replace(path)


class WindowsSecret:
    """DPAPI current-user scope; not portable to another Windows profile."""
    @property
    def supported(self):
        return os.name == "nt"

    def transform(self, value, encrypt):
        if not self.supported:
            raise ValueError("Salvar credenciais SMTP com proteção do Windows só está disponível na versão Windows.")
        from ctypes import wintypes

        class Blob(ctypes.Structure):
            _fields_ = [("size", wintypes.DWORD), ("data", ctypes.POINTER(ctypes.c_ubyte))]

        buffer = ctypes.create_string_buffer(value)
        source = Blob(len(value), ctypes.cast(buffer, ctypes.POINTER(ctypes.c_ubyte)))
        target = Blob()
        crypt = ctypes.WinDLL("crypt32", use_last_error=True)
        kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel.LocalFree.argtypes = [ctypes.c_void_p]
        kernel.LocalFree.restype = ctypes.c_void_p
        if encrypt:
            method = crypt.CryptProtectData
            method.argtypes = [ctypes.POINTER(Blob), wintypes.LPCWSTR, ctypes.c_void_p,
                               ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(Blob)]
            result = method(ctypes.byref(source), "CNPJ Explorer Local SMTP", None, None, None, 1, ctypes.byref(target))
        else:
            method = crypt.CryptUnprotectData
            method.argtypes = [ctypes.POINTER(Blob), ctypes.c_void_p, ctypes.c_void_p,
                               ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(Blob)]
            result = method(ctypes.byref(source), None, None, None, None, 1, ctypes.byref(target))
        if not result:
            raise ValueError("O Windows não conseguiu proteger/abrir a credencial SMTP deste perfil. Reconfigure o envio.")
        try:
            return ctypes.string_at(target.data, target.size)
        finally:
            kernel.LocalFree(ctypes.cast(target.data, ctypes.c_void_p))

    def protect(self, text):
        return base64.b64encode(self.transform(text.encode("utf-8"), True)).decode("ascii")

    def unprotect(self, text):
        return self.transform(base64.b64decode(text, validate=True), False).decode("utf-8")


class LocalMailer:
    def __init__(self, path, protector=None, transport=None):
        self.path = Path(path)
        self.protector = protector or WindowsSecret()
        self.transport = transport or self.smtp_send
        self.lock = threading.RLock()
        self.config = json.loads(self.path.read_text("utf-8")) if self.path.exists() else {}
        if not isinstance(self.config, dict):
            raise ValueError("Configuração SMTP inválida; as bases não foram alteradas.")

    def available(self):
        with self.lock:
            return bool(self.config.get("enabled") and self.config.get("verified")
                        and self.config.get("password_cipher") and self.protector.supported)

    def public(self):
        with self.lock:
            return {**{key: self.config.get(key, default) for key, default in {
                "host": "", "port": 587, "security": "starttls", "username": "", "from_email": "",
                "sender_name": "CNPJ Explorer Local", "enabled": False, "verified": False,
                "last_result": ""}.items()},
                    "password_set": bool(self.config.get("password_cipher")), "supported": self.protector.supported}

    def save(self, body):
        with self.lock:
            host = str(body.get("host", "")).strip().lower()
            if not re.fullmatch(r"[a-zA-Z0-9](?:[a-zA-Z0-9.-]{0,251}[a-zA-Z0-9])?", host):
                raise ValueError("Informe apenas o servidor SMTP, sem https, porta ou caminho.")
            port = int(body.get("port", 587))
            if not 1 <= port <= 65535 or body.get("security") not in ("ssl", "starttls"):
                raise ValueError("Use porta válida e TLS (SSL ou STARTTLS).")
            username = str(body.get("username", "")).strip()
            name = str(body.get("sender_name", "CNPJ Explorer Local")).strip()
            if not username or len(username) > 254 or not name or len(name) > 100 or any(
                    ord(c) < 32 for c in username + name):
                raise ValueError("Usuário SMTP ou nome do remetente inválido.")
            secret = body.get("password", "")
            if not isinstance(secret, str) or len(secret) > 2048:
                raise ValueError("Credencial SMTP inválida.")
            if host == "smtp.gmail.com":
                secret = secret.replace(" ", "")  # Google displays its app passwords in groups.
            cipher = self.protector.protect(secret) if secret else self.config.get("password_cipher")
            if not cipher or not self.protector.supported:
                raise ValueError("Informe a credencial SMTP na versão Windows; ela não será salva em texto.")
            if type(body.get("enabled", True)) is not bool:
                raise ValueError("Ativação SMTP inválida.")
            config = {"host": host, "port": port, "security": body["security"], "username": username,
                      "sender_name": name, "from_email": email_address(body.get("from_email")),
                      "password_cipher": cipher, "enabled": body.get("enabled", True), "verified": False,
                      "revision": secrets.token_hex(12), "last_result": "Salvo. Envie um teste para habilitar a recuperação."}
            atomic_json(self.path, config)
            self.config = config
            return self.public()

    def send(self, recipient, subject, text, testing=False):
        with self.lock:
            config = dict(self.config)
            if not testing and not self.available():
                raise ValueError("Recuperação por e-mail indisponível. Peça ajuda ao administrador.")
            if not config.get("password_cipher") or not config.get("enabled"):
                raise ValueError("Configure e ative primeiro o servidor SMTP.")
        try:
            password = self.protector.unprotect(config["password_cipher"])
            message = EmailMessage()
            from email.headerregistry import Address
            message["From"] = Address(config["sender_name"], addr_spec=config["from_email"])
            message["To"] = email_address(recipient)
            message["Subject"] = subject
            message.set_content(text)
            self.transport(config, password, message)
        except Exception:
            self.record_result(config, False, testing)
            raise ValueError("O servidor de e-mail não confirmou o envio. O administrador deve revisar servidor, TLS, autenticação e permissões do provedor.") from None
        self.record_result(config, True, testing)
        return {"message": "O servidor SMTP aceitou o e-mail de teste. Confira a caixa de entrada e o spam." if testing else "Envio aceito."}

    def record_result(self, config, success, testing):
        with self.lock:
            if self.config.get("revision") != config.get("revision"):
                return
            result = dict(self.config)
            result["last_result"] = datetime.now(timezone.utc).isoformat(timespec="seconds") + (
                " — envio aceito pelo provedor." if success else " — falha de envio; revise a configuração.")
            if testing:
                result["verified"] = success
            atomic_json(self.path, result)
            self.config = result

    @staticmethod
    def smtp_send(config, password, message):
        context = ssl.create_default_context()
        cls = smtplib.SMTP_SSL if config["security"] == "ssl" else smtplib.SMTP
        kwargs = {"timeout": 15}
        if config["security"] == "ssl":
            kwargs["context"] = context
        with cls(config["host"], config["port"], **kwargs) as smtp:
            smtp.ehlo()
            if config["security"] == "starttls":
                smtp.starttls(context=context)
                smtp.ehlo()
            smtp.login(config["username"], password)
            refused = smtp.send_message(message)
            if refused:
                raise ValueError("Destinatário recusado.")
